
package com.erwin.dataflow.model;

public interface RelationElement<T> {

    public T getElement();
}
