
package com.erwin.dataflow.model;

public class IndirectImpactRelation extends AbstractRelation {

    @Override
    public RelationType getRelationType() {
        return RelationType.indirectimpact;
    }
}
