
package com.erwin.dataflow.model;

public enum RelationType {
    //fdd, fddi, frd, fdr, join
     lineage, indirectimpact,businessrule, impact, join, where, groupBy, orderBy
}
