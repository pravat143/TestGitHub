package com.erwin.dataflow.model;

public enum EffectType {
	select, insert, update, merge_update, merge_insert, create_view, create_table, merge, delete, function, rename_table, swap_table, cursor
}
