/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.erwin.sqlparser;

import java.io.File;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Scanner;
import java.util.Set;
import org.apache.commons.io.FileUtils;
import org.apache.commons.lang3.StringUtils;

/**
 *
 @author Prajna Surya
 */
public class Logics {
   
     public static String modifyInsertQuery(String sql) {
        try {
            Set<String> selectIntoQueries = ErwinSqlParserExtererFinancev1.getSelectIntoQueries(sql);
            for (String selectIntoQuerie : selectIntoQueries) {
                sql = sql.replace(selectIntoQuerie, modifySelectQueriesV1(selectIntoQuerie));
            }
            return sql;

        } catch (Exception e) {
            e.printStackTrace();
        }
        return "";
    }

    public static String modifySelectQueriesV1(String sql) {
        String addedQuery = "INSERT INTO ";
        String intoTable = "";
        int spaceIndex = 0;
        String returnQuery = "";
        try {
            if (sql.startsWith("(") && sql.endsWith(")")) {
                sql = sql.substring(1, sql.length() - 1);
            }
            int intoStartIndex = sql.toUpperCase().indexOf("INTO");
            int intoEndIndex = intoStartIndex + 4;
            String intoSubString = sql.substring(intoStartIndex, intoEndIndex).trim();
            String table = sql.split(intoSubString)[1].trim();
            spaceIndex = table.indexOf(" ");
            if (spaceIndex != -1) {
                intoTable = table.substring(0, spaceIndex).trim();
            } else {
                intoTable = table.substring(0, table.length());
            }
            if (intoTable.contains("\n")) {
                intoTable = intoTable.split("\n")[0].trim();
            }

            if (sql.toUpperCase().startsWith("SELECT")) {
                // sql = sql.replaceAll(intoSubString, "").replaceAll(intoTable, "");
                returnQuery = addedQuery + " " + intoTable + "\n " + sql;//.replace(intoTable, "");
            } else {
                String modifiedQuery = sql.split(intoSubString)[0];
                int selectStartLastIndex = modifiedQuery.toUpperCase().lastIndexOf("SELECT");
                String insertQuery = modifiedQuery.substring(selectStartLastIndex, modifiedQuery.length()) + intoSubString + sql.split(intoSubString)[1];
                String replaceQuery = addedQuery + " " + intoTable + "\n" + insertQuery;//.replace(intoSubString, "").replace(intoTable, "");
                returnQuery = sql.replace(insertQuery, replaceQuery);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return returnQuery;
    }
    
     public static String selectintowrapper(String selectintostr)
     {
       StringBuilder querysb=new StringBuilder();
      try
      {
       String addedQuery = "INSERT INTO ";
       String intoTable = "";
       int spaceIndex = 0;
       selectintostr=selectintostr.toUpperCase();
       String originalquery=selectintostr;
       selectintostr=selectintostr.replace("SELECT * ","#ERWININDIA# ");
       String queries[]=selectintostr.split("SELECT ");
       for (int i=1;i<queries.length;i++) {
             queries[i]="SELECT "+queries[i];
       }
       for (String query : queries) {
           
        if(query.contains("INTO ") && !query.contains("INSERT INTO ")){
        query=query.replace("#ERWININDIA# ","SELECT * ");
        int intoStartIndex =query.indexOf("INTO ");
            int intoEndIndex = intoStartIndex +4;
            String intoSubString = query.substring(intoStartIndex, intoEndIndex).trim();
            String table = query.split(intoSubString+" ")[1].trim();
            spaceIndex = table.indexOf(" ");
            if (spaceIndex != -1) {
                intoTable = table.substring(0, spaceIndex).trim();
            } else {
                intoTable = table.substring(0, table.length());
            }
            if (intoTable.contains("\n")) {
                intoTable = intoTable.split("\n")[0].trim();
            }
            query=query.replace("INTO "+intoTable,"");
            query=addedQuery+intoTable+" "+"\n"+query;
            querysb.append(query).append("\n");
          }
         else
        {
          query=query.replace("#ERWININDIA# ","SELECT * ");
          querysb.append(query).append("\n");  
        }
     }
       if(StringUtils.isBlank(querysb.toString()))
       {
         querysb.append(originalquery);
       }
    }
     catch(Exception e)
     {
       e.printStackTrace();
     }
       return querysb.toString();
   }
     public static void main(String[]args)
    {
        File listfile=new File("C:\\Users\\InkolluReddy\\Downloads\\tbsql15waginst2@@@BI_Sales_DM@@@dbo_sp_DailyLoad_Annuity.sql");
        String sql="";
        try
       {
         sql = FileUtils.readFileToString(listfile,"UTF-8");
       }
       catch(Exception e)
       {
           e.printStackTrace();
       }
        selectintowrapper(sql);
    }
}
