/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.erwin.sqlparser;

import java.io.File;
import java.nio.file.Paths;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import org.apache.commons.io.FileUtils;
import org.apache.commons.io.FilenameUtils;

/**
 *
 * @author sashikant D
 */
public class Cfxsqlfileseparator {

    public static void main(String[] args) {
        File sqlfiles = new File("E:\\Clients\\zovio\\zoviosql");
        writefiles(sqlfiles);
    }

    public static void writefiles(File sqlfiles) {
        try {
            Pattern commentPattern = Pattern.compile("/\\*.*?\\*/", Pattern.DOTALL);  //remove /* pattern in sql
            String sqlfileContent = "";
            File[] sqlfilearr = sqlfiles.listFiles();
            for (File fgh : sqlfilearr) {
                String extension = FilenameUtils.getExtension(fgh.getName());
               
                    sqlfileContent = FileUtils.readFileToString(fgh).trim();
                sqlfileContent = changesetquery(sqlfileContent);
                
                sqlfileContent = sqlfileContent.replaceAll("\\/\\*[\\s\\S]*?\\*\\/|([^:]|^)\\/\\/.*$", "");

                sqlfileContent = sqlfileContent.replaceAll("FOLDER = \'.*\'", "");
                 sqlfileContent = commentPattern.matcher(sqlfileContent).replaceAll("");
                     sqlfileContent=removeComments(sqlfileContent);

                //REPLACE FOLDER
                if (sqlfileContent.trim().split(";").length >= 1) {
                    String multiplesqlfiles[] = sqlfileContent.split(";");
                    int i = 0;
                    for (int j = 0; j < multiplesqlfiles.length; j++) {
                        String multiplesqlfile = multiplesqlfiles[j].trim();

                        File sqlfile = new File(fgh.getAbsolutePath().replace(extension, "") + "" + i + ".sql");
                        FileUtils.writeStringToFile(sqlfile, multiplesqlfile);
                        i++;
                         fgh.delete();
                    }
                   
                }
            }

        } catch (Exception e) {

        }

    }

    public static String removeVarying(String procedureFile) {

        try {
            if ((procedureFile.contains("varying"))) {
                procedureFile = procedureFile.replaceAll("varying\\(.*?\\)", "");
                procedureFile = procedureFile.replaceAll("varying", "");
            }

        } catch (Exception e) {
        }
        return procedureFile;
    }
    
    
    public static String changesetquery(String query){
    StringBuilder sb1 = new StringBuilder();
    
        try {
            String[] querylines = query.split("\n");
            for (String queryline : querylines) {
                if(queryline.startsWith("SET NOCOUNT")){
                    queryline = queryline.replace(";","");
                }
                sb1.append(queryline).append("\n");
                
            }
        } catch (Exception e) {
        }
    return sb1.toString();
    }
    public static String removeComments(String data) {
        try {
            Pattern pattern = Pattern.compile("/\\*(.|\\n)*?\\*/");
            Matcher matcher = pattern.matcher(data);
            return matcher.replaceAll("");
        } catch (Exception e) {
            e.printStackTrace();
        }
        return "";
    }

}
