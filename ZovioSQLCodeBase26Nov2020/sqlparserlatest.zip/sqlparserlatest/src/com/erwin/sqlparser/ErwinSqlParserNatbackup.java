package com.erwin.sqlparser;

import com.ads.api.beans.mm.Mapping;
import com.ads.api.beans.mm.MappingSpecificationRow;
import com.ads.edf.overview.updateforsource.v4.UpdateSpecsForSourceAndTarget_91EDF;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.sqlToJson.BindingPojo.Column;
import com.sqlToJson.BindingPojo.Dlineage;
import demos.*;
import demos.columnAnalyze.ColumnAnalyze;
import demos.dlineage.DataFlowAnalyzerv1;
import demos.visitors.XmlVisitorv1;
import demos.visitors.toXml;
import demos.visitors.xmlVisitor;
import gudusoft.gsqlparser.EDbVendor;
import gudusoft.gsqlparser.EExpressionType;
import gudusoft.gsqlparser.EJoinType;
import gudusoft.gsqlparser.TCustomSqlStatement;
import gudusoft.gsqlparser.TGSqlParser;
import gudusoft.gsqlparser.nodes.TExpression;
import gudusoft.gsqlparser.nodes.TJoin;
import gudusoft.gsqlparser.nodes.TJoinItem;
import gudusoft.gsqlparser.nodes.TObjectName;
import gudusoft.gsqlparser.nodes.TResultColumn;
import gudusoft.gsqlparser.nodes.TResultColumnList;
import gudusoft.gsqlparser.nodes.TTable;
import gudusoft.gsqlparser.nodes.TTableList;
import gudusoft.gsqlparser.nodes.TWhereClause;
import gudusoft.gsqlparser.pp.para.GFmtOpt;
import gudusoft.gsqlparser.pp.para.GFmtOptFactory;
import gudusoft.gsqlparser.pp.stmtformatter.FormatterFactory;
import gudusoft.gsqlparser.stmt.TAlterTableStatement;
import gudusoft.gsqlparser.stmt.TCreateIndexSqlStatement;
import gudusoft.gsqlparser.stmt.TCreateTableSqlStatement;
import gudusoft.gsqlparser.stmt.TCreateViewSqlStatement;
import gudusoft.gsqlparser.stmt.TDeleteSqlStatement;
import gudusoft.gsqlparser.stmt.TInsertSqlStatement;
import gudusoft.gsqlparser.stmt.TSelectSqlStatement;
import gudusoft.gsqlparser.stmt.TTruncateStatement;
import gudusoft.gsqlparser.stmt.TUpdateSqlStatement;
import gudusoft.gsqlparser.stmt.db2.TDb2CreateProcedure;
import gudusoft.gsqlparser.stmt.mssql.TMssqlCreateProcedure;
import gudusoft.gsqlparser.stmt.teradata.TTeradataLock;
import java.io.File;
import java.io.FileReader;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.ListIterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Objects;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.TimeUnit;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.Unmarshaller;
import org.apache.commons.io.FileUtils;
import org.apache.commons.io.IOUtils;
import org.apache.commons.lang3.StringUtils;

/**
 * Sy
 *
 * @author shashikanta
 */
public class ErwinSqlParserNatbackup {

    public static Map<String, String> sourceTargetMap = new LinkedHashMap<>();
    public static Map<String, LinkedHashMap<String, String>> sourcemap = new LinkedHashMap<String, LinkedHashMap<String, String>>();
    public static Map<String, LinkedHashMap<String, String>> target = new LinkedHashMap();
    public static LinkedHashMap<String, String> sorceinformation = new LinkedHashMap();
    public static LinkedHashMap<String, String> targetinformation = new LinkedHashMap();
    public static LinkedHashMap<String, String> sourcetarget = new LinkedHashMap();
    public static LinkedHashMap<String, String> tableAliasMap = new LinkedHashMap();
    public static List<String> filequerycontent = new LinkedList<>();
    public static ArrayList<MappingSpecificationRow> mapspeclist = new ArrayList<>();
    public static String sourceSystemNamegl = "";
    public static String sourceEnvironmentNamegl = "";
    public static String targetSystemNamegl = "";
    public static String targetEnvironmentNamegl = "";
    public static Map<String, List<String>> tableColRel = new LinkedHashMap();
    public static Map<String, List<String>> tableColforstar = new LinkedHashMap();
    public static EDbVendor dbVendor = null;
    public static TGSqlParser sqlparser = null;
    public static String updateTargetTableName = "";
    public static String deleteTargetTableName = "";
    public static boolean unionDelete;
    public static String unionTargetTableName = "";
    public static HashMap<String, ArrayList<String>> specTableColumnDetails = new HashMap<String, ArrayList<String>>();
    public static HashMap<String, String> sourceTableColumndeatilsWithBusinessRule = new HashMap<String, String>();
    public static Set<String> joinconditions = new HashSet<>();
    public static Map<String, String> keyvaluepair = new LinkedHashMap<>();
    public static Set<String> whereCondition = new HashSet<>();
    public static Map<String, String> ExpressionTarget = new LinkedHashMap();
    public static Map<String, String> systemEnvMap = new LinkedHashMap<>();
    public static Map<String, String> tableColMapWhenWeNotgettingAliasTable = new LinkedHashMap<>();
    public static Map<String, String> tableColMapWhenWeNotgettingAliasTablefdd = new LinkedHashMap<>();
    public static Map<String, String> forMapinfogettingsourcetableMapfdd = new LinkedHashMap<>();
    public static String dbName = "";

    public static void main(String[] args) throws Exception {
        // String xmlstr = FileUtils.readFileToString(new File("C:\\Users\\VinithChalla\\Desktop\\samplesql.sql"));
        // System.out.println(xmlstr);
        //getJavaObjectfromxmls(xmlstr);
        ErwinSqlParserNat erwinSqlParserNat = new ErwinSqlParserNat();
        File file = new File("C:\\Users\\VinithChalla\\Downloads\\Dash.sp_FA_Lifecycle.sql");
        String s = erwinSqlParserNat.sqlToDataflow(file.getAbsolutePath(), "Redshift", "EDFenv", "Redshift", "EdfEnv", "mssql", file.getName());
        //    System.out.println("###########################################################");
        //    System.out.println(s);
    }

    public String sqlToDataflow(String sqlfile, String sourceSystemName, String sourceEnvironmentName, String targetSystemName, String targetEnvironmentName, String dbvendor, String mapname) {
        sourceSystemNamegl = sourceSystemName;
        sourceEnvironmentNamegl = sourceEnvironmentName;
        targetSystemNamegl = targetSystemName;
        targetEnvironmentNamegl = targetEnvironmentName;
        String jsonMapping = null;
        tableColRel.toString();
        try {
            //remove js
            File sqlFilepath = new File(sqlfile);
            String sqlContent = FileUtils.readFileToString(sqlFilepath);
            jsonMapping = getJsonfromSqlstring(sqlContent, dbvendor, mapname);

            //  jsonMapping = getJsonfromSql(sqlfile, dbvendor, mapname);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return jsonMapping;
    }

    public static String getJsonfromSql(String sqlfile,
            String dbvendor,
            String mapname) {
        String json = "";
        Mapping mapping = null;
        FileReader reader = null;

        try {
            clearStaticvariable();
            ObjectMapper objectMapper = new ObjectMapper();
            List<String> querylist = null;
            List<String> querylistWithStar = null;
            Set<String> keyvaluepair = null;
            String lastSubselectQuery = "";
            //  toXml.getXml(sqlfile, dbvendor);
//            System.out.println("=== SQL File ======= > " + sqlfile);

//            System.out.println(dbvendor);
            sqlparser = new TGSqlParser(EDbVendor.dbvmssql);
            File filessql = new File(sqlfile);
            toXml.getXml2(filessql.getAbsolutePath());
            reader = new FileReader(filessql);
            // mapname = mapname.split("\\.")[0];
            sourceEnvironmentNamegl = mapname;
            targetEnvironmentNamegl = mapname;
            sourceSystemNamegl = dbvendor;
            targetSystemNamegl = dbvendor;
            String sqlfileContent = FileUtils.readFileToString(filessql);

            if (sqlfileContent.contains("~")) {
                sqlfileContent = sqlfileContent.replace("~", "tild");
            }
            if (sqlfileContent.contains("'~'")) {
                sqlfileContent = sqlfileContent.replace("'~'", "tild");
            }

            querylist = new LinkedList<>(XmlVisitorv1.subselectquery);

            querylistWithStar = new LinkedList<>(XmlVisitorv1.subselectquerywithStar);
            Map<String, String> childParentMap = new LinkedHashMap<>(XmlVisitorv1.childParentQuery);
            getgroupbyclause(querylist, dbvendor);
            querylist.add(sqlfileContent);
            getQueryType(sqlfileContent, dbvendor, querylist, sqlfile);
//            makelooplineage(sourceTargetMap);
            if (querylist.size() >= 2) {
                lastSubselectQuery = querylist.get(0);
            }
            if (childParentMap.size() == 0) {
                keyvaluepair = getJoinStatementsfromList(sqlfileContent, dbvendor);
                createkeyvalueMap(keyvaluepair);
            } else {
                keyvaluepair = getJoinStatementsfromList(childParentMap, dbvendor);
                createkeyvalueMap(keyvaluepair);

            }

            //getExpression(querylist, tableAliasMap, dbvendor);
            // ExpressionTarget.clear();
            childParentMap.clear();
            removebraces(mapspeclist);
            removeNullfromspec(mapspeclist);
            removeBlankSourceTableandColumn(mapspeclist);
            removeBlankTarget(mapspeclist);
            //removeHshTarget(mapspeclist); 
            removederivedTarget(mapspeclist);
            // removecommas(mapspeclist);
            targetcolumnNamekeptAsempty(mapspeclist);
            getExtremeSourceremoveNullTable(mapspeclist);
            //when temp tableName(#),sourcetableName same we kept the srctbl as a temptable
            appendHashforTable(mapspeclist);
            removeTheStringWithinBraces(mapspeclist);

            //       removeTheColumnsIfitisgoingMultipletimes(mapspeclist);
            //  rePlaceMiddleComponentWithMapName(mapspeclist, sourceSystemNamegl);
            if (mapspeclist.size() != 0) {
                List<Mapping> mappingfromjson = createmapfromrow(mapspeclist, mapname, sqlfileContent, querylist);

                //     objectMapper.writeValue(new File(jsonpath + "\\" + filessql.getName() + ".json"), mappingfromjson);
                json = objectMapper.writeValueAsString(mappingfromjson);
            }

        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            System.gc();

        }

        return json;
    }
    public static String getJsonfromSqlstring(String sqltext,
            String dbvendor,
            String mapname) {
        String json = "";
        Mapping mapping = null;
        FileReader reader = null;
        try {
            sqltext = sqltext.toUpperCase();

          if(sqltext.contains("SELECT *"))
          {
            sqltext=modifysqlquery(sqltext);
          }
          if(sqltext.contains("CREATE OR ALTER VIEW"))
          {
            sqltext=sqltext.replace("CREATE OR ALTER VIEW","CREATE VIEW");
          }
            clearStaticvariable();
            ObjectMapper objectMapper = new ObjectMapper();
            List<String> querylist = null;
            List<String> querylistWithStar = null;
            Set<String> keyvaluepair = null;
            String lastSubselectQuery = "";
            sqlparser = new TGSqlParser(EDbVendor.dbvmssql);
            toXml.getdbvenderforsqlstr(sqltext);
            String sqlfileContent = sqltext;
            mapname = mapname.replace(".sql", "");
            if(StringUtils.isBlank(sourceEnvironmentNamegl))
            {
            sourceEnvironmentNamegl = mapname;
            }
             if(StringUtils.isBlank(targetEnvironmentNamegl))
            {
            targetEnvironmentNamegl = mapname;
            }
             if(StringUtils.isBlank(sourceSystemNamegl))
            {
            sourceSystemNamegl = dbvendor;
            }
            if(StringUtils.isBlank(targetSystemNamegl))
            {
            targetSystemNamegl = dbvendor;
            }
            if (sqlfileContent.contains("~")) {
                sqlfileContent = sqlfileContent.replace("~", "tild");
            }
            if (sqlfileContent.contains("'~'")) {
                sqlfileContent = sqlfileContent.replace("'~'", "tild");
            }
            querylist = new LinkedList<>(XmlVisitorv1.selectqueries);
            querylistWithStar = new LinkedList<>(XmlVisitorv1.subselectquerywithStar);
            Map<String, String> childParentMap = new LinkedHashMap<>(XmlVisitorv1.childParentQuery);
            getgroupbyclause(querylist, dbvendor);
            querylist.add(sqlfileContent);
            getQueryType(sqlfileContent, dbvendor, querylist, sqltext);
//            makelooplineage(sourceTargetMap);
            if (querylist.size() >= 2) {
                lastSubselectQuery = querylist.get(0);
            }
            if (childParentMap.size() == 0) {
                keyvaluepair = getJoinStatementsfromList(sqlfileContent, dbvendor);
                createkeyvalueMap(keyvaluepair);
            } else {
                keyvaluepair = getJoinStatementsfromList(childParentMap, dbvendor);
                createkeyvalueMap(keyvaluepair);
                keyvaluepair.toString();
            }
            childParentMap.clear();
            ArrayList<MappingSpecificationRow> rowlist = updatespecrowforstar(mapspeclist);
            if (!rowlist.isEmpty()) {
                mapspeclist.addAll(rowlist);
            }
            removebraces(mapspeclist);  
            removeNullfromspec(mapspeclist);
//         Set<String> Extremesrctableset = ExtreamSourceAndExtreamTarget.getExtremesrcSet(mapspeclist);
//            for (String srcTab : Extremesrctableset) {
//                updateExtremesrcTabMapspecs(srcTab.toUpperCase(), mapName);
//                  }
//          Set<String> Extremetgttableset = ExtreamSourceAndExtreamTarget.getExtremeTargetSet(mapspeclist);
           
          addSchemaNameforOrphantables(mapspeclist);
            removeBlankSourceTableandColumn(mapspeclist);
            removeBlankTarget(mapspeclist);
            removederivedTarget(mapspeclist);
            targetcolumnNamekeptAsempty(mapspeclist);
            getExtremeSourceremoveNullTable(mapspeclist);
            //when temp tableName(#),sourcetableName same we kept the srctbl as a temptable
            appendHashforTable(mapspeclist);
            //remove with in braces string
            removeTheStringWithinBraces(mapspeclist);

            //addSchemaNameforOrphantables(mapspeclist);
            if (mapspeclist.size() != 0) {
                List<Mapping> mappingfromjson = createmapfromrow(mapspeclist, mapname, sqlfileContent, querylist);

                //     objectMapper.writeValue(new File(jsonpath + "\\" + filessql.getName() + ".json"), mappingfromjson);
                json = objectMapper.writeValueAsString(mappingfromjson);
            }

        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            System.gc();

        }

        return json;
    }

    public void getClear() {
        clearStaticvariable();

    }

    public static void getJavaObjectfromxmls(String xmlfile) {
        try {
            InputStream in = IOUtils.toInputStream(xmlfile, "UTF-8");
            JAXBContext jaxbContext
                    = JAXBContext.newInstance("com.sqlToJson.BindingPojo");
            Unmarshaller unmarshaller
                    = jaxbContext.createUnmarshaller();
            Dlineage dj = (Dlineage) unmarshaller.unmarshal(in);
            int i = 0;
            for (Object s : dj.getColumnOrTableOrResultset()) {
                LinkedHashMap<String, String> maps = new LinkedHashMap<>();
                List<String> columnsNameList = new LinkedList();
                if (s instanceof Dlineage.Relation) {
                    String sourcetableName = "";
                    String targetTableName = "";
                    String sourceColumnName = "";
                    String targetColumnName = "";
                    String sourceinfomore = "";
//                    if (((Dlineage.Relation) s).getType().equals("dataflow") || ((Dlineage.Relation) s).getType().equals("dataflow_recordset")) {
                    if (((Dlineage.Relation) s).getType().equals("fdd")) {
                        // System.out.println("----"+((Relation) s).getSource());
                        for (Dlineage.Relation.Source so : ((Dlineage.Relation) s).getSource()) {
                            if (((Dlineage.Relation) s).getSource().size() > 1) {
                                //System.out.println("Column names :------" + so.getColumn().trim());
                                if (so.getColumn().trim().toLowerCase().contains("case")) {
                                    continue;
                                }
                                if (so.getColumn() == null) {
                                    continue;
                                }
                                String sourceColumn = so.getColumn();

                                if (sourceColumn == null) {
                                    continue;
                                }
                                if ("".equals(sourceinfomore)) {

                                    sourceinfomore = so.getParentName() + "$" + sourceColumn;
                                } else {
                                    sourceinfomore = sourceinfomore + "~" + so.getParentName() + "$" + sourceColumn;
                                }

                                //              System.out.println("source-----" + sourceinfomore);
                            } else {
                                sourcetableName = so.getParentName();
                                sourceColumnName = so.getColumn();
                                //              System.out.println("sourc--tableName---" + sourcetableName + "source---columnName----" + sourceColumnName);
                            }
                            if ((sourcetableName == null || sourcetableName.equals("null") || "".equals(sourcetableName)) && so.getSourceName() != null) {
                                sourcetableName = so.getSourceName().toUpperCase();
                                if (sourcetableName == null) {
                                    sourcetableName = so.getParentName();
                                }
                                if (StringUtils.isNotBlank(sourcetableName)) {
                                    sourcetableName = sourcetableName.toUpperCase();
                                }

                            }
                        }
                        for (Dlineage.Relation.Target target : ((Dlineage.Relation) s).getTarget()) {

                            targetTableName = target.getParentName();
                            if (StringUtils.isNotBlank(targetTableName)) {
                                targetTableName = targetTableName.toUpperCase();
                            }

                            targetColumnName = target.getColumn();

                            if (targetColumnName == null) {
                                continue;
                            }
                        }
                        if (sourceColumnName != null && sourceColumnName.contains(":")) {
                            sourceColumnName = sourceColumnName.replace(":", "");

                        }

                        String source = sourcetableName + "$" + sourceColumnName;
                        String target = targetTableName + "$" + targetColumnName;
                        source = source.replace("[", "").replace("]", "");
                        target = target.replace("[", "").replace("]", "");
                        if (!"".equals(sourceinfomore)) {
                            maps.put(sourceinfomore, target);
                        } else {
                            maps.put(source, target);
                        }
                        if (!"".equals(sourceinfomore)) {
                            String[] sourcetabnamearr = sourceinfomore.split("~");
                            for (String multiplesource : sourcetabnamearr) {
                                String sourceta = multiplesource.split("\\$")[0];
                                sourceta = sourceta.replace("[", "").replace("]", "").toUpperCase();
                                sourceTargetMap.put(sourceta, targetTableName);
                            }

                        } else {
                            if (sourcetableName != null) {
                                sourcetableName = sourcetableName.replace("[", "").replace("]", "").toUpperCase();
                            }

                            sourceTargetMap.put(sourcetableName, targetTableName);
                        }

                        if (sourceinfomore != null && source != null) {
                            getAllmapp(maps);
                        }

                    }

                    if (((Dlineage.Relation) s).getType().equals("fdr")) {

                        // System.out.println("----"+((Relation) s).getSource());
                        for (Dlineage.Relation.Source so : ((Dlineage.Relation) s).getSource()) {
                            if (((Dlineage.Relation) s).getSource().size() > 1) {
                                //System.out.println("Column names :------" + so.getColumn().trim());
                                if (so.getColumn().trim().toLowerCase().contains("case")) {
                                    continue;
                                }
                                if (so.getColumn() == null) {
                                    continue;
                                }
                                String sourceColumn = so.getColumn();
                                if (sourceColumn == null) {
                                    continue;
                                }

                                if ("".equals(sourceinfomore)) {

                                    sourceinfomore = so.getParentName() + "$" + sourceColumn;
                                } else {
                                    sourceinfomore = sourceinfomore + "~" + so.getParentName() + "$" + sourceColumn;
                                }

                                //              System.out.println("source-----" + sourceinfomore);
                            } else {
                                sourcetableName = so.getParentName();
                                sourceColumnName = so.getColumn();
                                //              System.out.println("sourc--tableName---" + sourcetableName + "source---columnName----" + sourceColumnName);
                            }
                            if (sourcetableName == null || sourcetableName.equals("null") || "".equals(sourcetableName)) {
                                sourcetableName = so.getSourceName();
                                if (sourcetableName == null) {
                                    sourcetableName = so.getParentName();
                                }

                            }
                        }
                        for (Dlineage.Relation.Target target : ((Dlineage.Relation) s).getTarget()) {

                            targetTableName = target.getParentName();

                            targetColumnName = target.getColumn();

                            if (targetColumnName == null) {
                                continue;
                            }
                        }
                        if (sourceColumnName != null && sourceColumnName.contains(":")) {
                            sourceColumnName = sourceColumnName.replace(":", "");

                        }
//                        
                        String source = sourcetableName + "$" + sourceColumnName;
                        String target = targetTableName + "$" + targetColumnName;
                        source = source.replace("[", "").replace("]", "");
                        target = target.replace("[", "").replace("]", "");
                        if (!"".equals(sourceinfomore)) {
                            maps.put(sourceinfomore, target);
                        } else {
                            maps.put(source, target);
                        }

                        if (!"".equals(sourceinfomore)) {
                            String[] sourcetabnamearr = sourceinfomore.split("~");
                            for (String multiplesource : sourcetabnamearr) {
                                String sourceta = multiplesource.split("\\$")[0];
                                sourceta = sourceta.replace("[", "").replace("]", "").toUpperCase();
                                sourceTargetMap.put(sourceta, targetTableName);
                            }

                        } else {
                            if (sourcetableName != null) {
                                sourcetableName = sourcetableName.replace("[", "").replace("]", "").toUpperCase();
                            }

                            sourceTargetMap.put(sourcetableName, targetTableName);
                        }
                        if (sourceinfomore != null && source != null) {
                            getAllmapp(maps);
                        }

                    }

                    if (((Dlineage.Relation) s).getType().equals("frd")) {
                        // System.out.println("----"+((Relation) s).getSource());
                        for (Dlineage.Relation.Source so : ((Dlineage.Relation) s).getSource()) {
                            if (((Dlineage.Relation) s).getSource().size() > 1) {
                                //System.out.println("Column names :------" + so.getColumn().trim());
                                if (so.getColumn().trim().toLowerCase().contains("case")) {
                                    continue;
                                }
                                if (so.getColumn() == null) {
                                    continue;
                                }
                                String sourceColumn = so.getColumn();
                                if (sourceColumn == null) {
                                    continue;
                                }
                                if ("".equals(sourceinfomore)) {

                                    sourceinfomore = so.getParentName() + "$" + sourceColumn;
                                } else {
                                    sourceinfomore = sourceinfomore + "~" + so.getParentName() + "$" + sourceColumn;
                                }

                                //              System.out.println("source-----" + sourceinfomore);
                            } else {
                                sourcetableName = so.getParentName();
                                sourceColumnName = so.getColumn();
                                //              System.out.println("sourc--tableName---" + sourcetableName + "source---columnName----" + sourceColumnName);
                            }
                            if (sourcetableName == null || sourcetableName.equals("null") || "".equals(sourcetableName)) {
                                sourcetableName = so.getSourceName();
                                if (sourcetableName == null) {
                                    sourcetableName = so.getParentName();
                                }
                                if (StringUtils.isNotBlank(sourcetableName)) {
                                    sourcetableName = sourcetableName.toUpperCase();
                                }

                            }
                        }
                        for (Dlineage.Relation.Target target : ((Dlineage.Relation) s).getTarget()) {

                            targetTableName = target.getParentName();
                            if (StringUtils.isNotBlank(targetTableName)) {
                                targetTableName = targetTableName.toUpperCase();
                            }

                            targetColumnName = target.getColumn();
                            if (targetColumnName == null) {
                                continue;
                            }
                        }
                        if (sourceColumnName != null && sourceColumnName.contains(":")) {
                            sourceColumnName = sourceColumnName.replace(":", "");

                        }
//                        
                        String source = sourcetableName + "$" + sourceColumnName;
                        String target = targetTableName + "$" + targetColumnName;
                        source = source.replace("[", "").replace("]", "");
                        target = target.replace("[", "").replace("]", "");

                        if (!"".equals(sourceinfomore)) {
                            String[] sourcetabnamearr = sourceinfomore.split("~");
                            for (String multiplesource : sourcetabnamearr) {
                                String sourceta = multiplesource.split("\\$")[0];
                                sourceta = sourceta.replace("[", "").replace("]", "").toUpperCase();
                                sourceTargetMap.put(sourceta, targetTableName);
                            }

                        } else {
                            if (sourcetableName != null) {
                                sourcetableName = sourcetableName.replace("[", "").replace("]", "").toUpperCase();
                            }

                            sourceTargetMap.put(sourcetableName, targetTableName);
                        }

                    }
                    if (s instanceof Dlineage.Relation) {
                        if (((Dlineage.Relation) s).getType().equals("frd")) {

                            for (Dlineage.Relation.Target target : ((Dlineage.Relation) s).getTarget()) {

                                String targetTable = target.getParentName();

                                String targetColumn = target.getColumn();
                                if (targetColumnName == null) {
                                    continue;
                                }
                                targetColumn = targetColumn.replace("[", "").replace("]", "");
                                targetTable = targetTable.replace("[", "").replace("]", "");
                                if (!tableColMapWhenWeNotgettingAliasTable.containsKey(targetColumn.toUpperCase())) {
                                    tableColMapWhenWeNotgettingAliasTable.put(targetColumn.toUpperCase(), targetTable.toUpperCase());
                                }
                            }
                        }
                    }
                    if (s instanceof Dlineage.Relation) {
                        if (((Dlineage.Relation) s).getType().equals("fdd")) {

                            for (Dlineage.Relation.Target target : ((Dlineage.Relation) s).getTarget()) {

                                String targetTable = target.getParentName();

                                String targetColumn = target.getColumn();
                                if (targetColumn == null) {
                                    continue;
                                }
                                targetColumn = targetColumn.replace("[", "").replace("]", "");
                                targetTable = targetTable.replace("[", "").replace("]", "");
                                if (!tableColMapWhenWeNotgettingAliasTablefdd.containsKey(targetColumn.toUpperCase())) {
                                    tableColMapWhenWeNotgettingAliasTablefdd.put(targetColumn.toUpperCase(), targetTable.toUpperCase());
                                }
                            }

                        }
                    }
                    if (s instanceof Dlineage.Relation) {
                        if (((Dlineage.Relation) s).getType().equals("fdd")) {
                            for (Dlineage.Relation.Source source : ((Dlineage.Relation) s).getSource()) {

                                String sourceTable = source.getParentName();
                                if (StringUtils.isNotBlank(sourceTable)) {
                                    sourceTable = sourceTable.toUpperCase();
                                }
                                if (sourceTable == null) {
                                    continue;
                                }
                                String sourceColumn = source.getColumn();
                                if (sourceColumn == null) {
                                    continue;
                                }
                                if (StringUtils.isNotBlank(sourceColumn)) {
                                    sourceColumn = sourceColumn.replace("[", "").replace("]", "");
                                }
                                if (StringUtils.isNotBlank(sourceTable)) {
                                    sourceTable = sourceTable.replace("[", "").replace("]", "");
                                }
                                if (!forMapinfogettingsourcetableMapfdd.containsKey(sourceColumn.toUpperCase())) {
                                    forMapinfogettingsourcetableMapfdd.put(sourceColumn.toUpperCase(), sourceTable.toUpperCase());
                                }
                            }

                        }
                    }

                    i++;
                }
                if (s instanceof Dlineage.Table) {
                    String tableName = ((Dlineage.Table) s).getName();
                    if (StringUtils.isNotBlank(tableName)) {
                        tableName = tableName.toUpperCase();
                    }
                    String schemaName = ((Dlineage.Table) s).getSchema();
                    if (StringUtils.isNotBlank(schemaName)) {
                        schemaName = schemaName.toUpperCase();
                    }
                    String database = ((Dlineage.Table) s).getdatabase();
                    if (StringUtils.isNotBlank(database)) {
                        database = database.toUpperCase();
                    }
                    List<Column> columnList = ((Dlineage.Table) s).getColumn();
                    String tablealias = ((Dlineage.Table) s).getAlias();
                    for (Column column : columnList) {
                        columnsNameList.add(column.getName());
                    }
                    if (database != null && schemaName != null) {
                        tableColRel.put(database.toUpperCase() + "." + schemaName.toUpperCase() + "." + tableName.toUpperCase(), columnsNameList);

                        tableColforstar.put(database.toUpperCase() + "." + schemaName.toUpperCase() + "." + tableName.toUpperCase(), columnsNameList);
                    } else if (database != null && schemaName == null) {
                        tableColRel.put(database.toUpperCase() + ".." + tableName.toUpperCase(), columnsNameList);
                        tableColforstar.put(database.toUpperCase() + ".." + tableName.toUpperCase(), columnsNameList);
                    } else if (database == null && schemaName != null) {
                        tableColRel.put(schemaName.toUpperCase() + "." + tableName.toUpperCase(), columnsNameList);
                        tableColforstar.put(schemaName.toUpperCase() + "." + tableName.toUpperCase(), columnsNameList);
                    } else {
                        tableColRel.put(tableName.toUpperCase(), columnsNameList);
                        String tableN = tableName.toUpperCase();
                        if (tableColforstar.containsKey(tableN)) {
                            tableColforstar.get(tableN).addAll(columnsNameList);
                        } else {
                            tableColforstar.put(tableName.toUpperCase(), columnsNameList);
                        }

                    }

                    //  if(tablealias.contains(",")&&tablealias!=null)
                    //  {
                    //       tablealias=tablealias.split(",")[0];
                    //   }
                    if (database != null && schemaName != null) {
                        tableAliasMap.put(tablealias, database + "." + schemaName + "." + tableName.toUpperCase());
                    } else if (schemaName != null) {
                        tableAliasMap.put(tablealias, schemaName + "." + tableName.toUpperCase());
                    } else {
                        tableAliasMap.put(tablealias, tableName.toUpperCase());
                    }
                }
                if (s instanceof Dlineage.View) {

                    String tableName = ((Dlineage.View) s).getName();
                    if (StringUtils.isNotBlank(tableName)) {
                        tableName = tableName.toUpperCase();
                    }
                    String schemaName = ((Dlineage.View) s).getSchema();
                    if (StringUtils.isNotBlank(schemaName)) {
                        schemaName = schemaName.toUpperCase();
                    }
                    String database = ((Dlineage.View) s).getdatabase();
                    if (StringUtils.isNotBlank(database)) {
                        database = database.toUpperCase();
                    }
                    List<Column> columnList = ((Dlineage.View) s).getColumn();
                    String tablealias = ((Dlineage.View) s).getAlias();
                    for (Column column : columnList) {
                        columnsNameList.add(column.getName());
                    }
                    if (database != null && schemaName != null) {
                        tableColRel.put(database + "." + schemaName + "." + tableName.toUpperCase(), columnsNameList);

                        tableColforstar.put(database + "." + schemaName + "." + tableName.toUpperCase(), columnsNameList);
                    } else if (database != null && schemaName == null) {
                        tableColRel.put(database + ".." + tableName.toUpperCase(), columnsNameList);
                        tableColforstar.put(database + ".." + tableName.toUpperCase(), columnsNameList);
                    } else if (schemaName != null) {
                        tableColRel.put(schemaName + "." + tableName.toUpperCase(), columnsNameList);
                        tableColforstar.put(schemaName + "." + tableName.toUpperCase(), columnsNameList);
                    } else {
                        tableColRel.put(tableName.toUpperCase(), columnsNameList);
                        String tableN = tableName.toUpperCase();
                        if (tableColforstar.containsKey(tableN)) {
                            tableColforstar.get(tableN).addAll(columnsNameList);
                        } else {
                            tableColforstar.put(tableName.toUpperCase(), columnsNameList);
                        }

                    }

                    //  if(tablealias.contains(",")&&tablealias!=null)
                    //  {
                    //       tablealias=tablealias.split(",")[0];
                    //   }
                    if (database != null && schemaName != null) {
                        tableAliasMap.put(tablealias, database + "." + schemaName + "." + tableName.toUpperCase());
                    } else if (schemaName != null) {
                        tableAliasMap.put(tablealias, schemaName + "." + tableName.toUpperCase());
                    } else {
                        tableAliasMap.put(tablealias, tableName.toUpperCase());
                    }
                }
//                if (sourceTargetMap.size() == 0) {
//
//                    createMapSpecForOnly();
//                }

                if (s instanceof Dlineage.Resultset) {
                    String rsultsetTableName = ((Dlineage.Resultset) s).getName();
                    List<Column> resultcolumnList = ((Dlineage.Resultset) s).getColumn();
                    List<String> resultcolumnsNameList = new LinkedList();
                    for (Column column : resultcolumnList) {
                        resultcolumnsNameList.add(column.getName());
                    }
                    tableColRel.put(rsultsetTableName.toUpperCase().replace("[", "").replace("]", ""), resultcolumnsNameList);
                }

            }
            int tesr = 0;
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    public static void getAllmapp(LinkedHashMap<String, String> sourcetarget) {
        try {
            MappingSpecificationRow mapspec = new MappingSpecificationRow();
            for (Map.Entry<String, String> entry : sourcetarget.entrySet()) {
                String key = entry.getKey();
                String value = entry.getValue();
                if (key.contains("~")) {
                    String[] arrayforUnion = key.split("~");

                    for (String unionsource : arrayforUnion) {
                        MappingSpecificationRow mapspec1 = new MappingSpecificationRow();
                        mapspec1.setSourceSystemEnvironmentName(sourceEnvironmentNamegl);
                        mapspec1.setTargetSystemEnvironmentName(targetEnvironmentNamegl);
                        mapspec1.setSourceSystemName(sourceSystemNamegl);
                        mapspec1.setTargetSystemName(targetSystemNamegl);
                        mapspec1.setSourceTableName(unionsource.split("\\$")[0]);
//                    if (unionsource.split("\\$")[1].equals("null")) {
//                        mapspec1.setSourceColumnName(" ");
////                        continue;
//                    } else {
//                        mapspec1.setSourceColumnName(unionsource.split("\\$")[1]);
//                    }
                        if (unionsource.split("\\$").length > 1) {
                            mapspec1.setSourceColumnName(unionsource.split("\\$")[1]);
                        }

                        mapspec1.setSourceColumnIdentityFlag(true);
                        mapspec1.setTargetTableName(value.split("\\$")[0]);
                        //  System.out.println("-----------" + value);
                        if (value.split("\\$").length > 1) {
                            mapspec1.setTargetColumnName(value.split("\\$")[1]);
                        }
                        mapspec1.setSourceSystemEnvironmentName(sourceEnvironmentNamegl);
                        mapspec1.setTargetSystemEnvironmentName(targetEnvironmentNamegl);
                        mapspec1.setSourceSystemName(sourceSystemNamegl);
                        mapspec1.setTargetSystemName(targetSystemNamegl);
                        mapspeclist.add(mapspec1);
                    }
                } else {
                    mapspec.setSourceSystemEnvironmentName(sourceEnvironmentNamegl);
                    mapspec.setTargetSystemEnvironmentName(targetEnvironmentNamegl);
                    mapspec.setSourceSystemName(sourceSystemNamegl);
                    mapspec.setTargetSystemName(targetSystemNamegl);

//                if (key.split("\\$")[1].equals("null")) {
//                    mapspec.setSourceColumnName(" ");
////                    continue;
//                } else {
//                    mapspec.setSourceColumnName(key.split("\\$")[1]);
//                }
                    if (key.split("\\$").length > 1) {
                        mapspec.setSourceColumnName(key.split("\\$")[1]);
                        mapspec.setSourceTableName(key.split("\\$")[0]);
                    }

                    mapspec.setSourceColumnIdentityFlag(true);
                    if (value.split("\\$").length > 1) {
                        mapspec.setTargetTableName(value.split("\\$")[0]);
                        mapspec.setTargetColumnName(value.split("\\$")[1]);
                    }

                    mapspeclist.add(mapspec);

                }

            }

        } catch (Exception e) {

            e.printStackTrace();
        }

    }

    public static void clearStaticvariable() {
        sourcemap.clear();

        target.clear();
        sorceinformation.clear();
        targetinformation.clear();
        sourcetarget.clear();
        filequerycontent.clear();
        mapspeclist.clear();

        XmlVisitorv1.subselectquery.clear();
        XmlVisitorv1.selectqueries.clear();
        XmlVisitorv1.childParentQuery.clear();
        tableColRel.clear();
        tableAliasMap.clear();
        updateTargetTableName = "";
        deleteTargetTableName = "";
        unionTargetTableName = "";
        specTableColumnDetails.clear();
        sourceTableColumndeatilsWithBusinessRule.clear();
        tableColMapWhenWeNotgettingAliasTable.clear();
        tableColMapWhenWeNotgettingAliasTablefdd.clear();
        forMapinfogettingsourcetableMapfdd.clear();
        joinconditions.clear();
        whereCondition.clear();
        keyvaluepair.clear();
        unionDelete = false;

    }

    public static List<Mapping> createmapfromrow(ArrayList<MappingSpecificationRow> specrowlist, String mapfileName, String query, List<String> subselectquery) {
        List<Mapping> mappinglist = new LinkedList();
        Mapping mmapingsqlobj = new Mapping();
        List<String> subselectQuery = new LinkedList<>(subselectquery);
        String subSelectQuery = org.apache.commons.lang3.StringUtils.join(subselectQuery, "---------------------\n");
        //  mmapingsqlobj.setSourceExtractDescription(subSelectQuery);
        mmapingsqlobj.setMappingName(mapfileName);
        mmapingsqlobj.setMappingSpecifications(specrowlist);
        mmapingsqlobj.setSourceExtractQuery(query);
        mmapingsqlobj.setUpdateSourceMetadata(true);
        mmapingsqlobj.setUpdateTargetMetadata(true);
//        mmapingsqlobj.setProjectId(projid);
//        mmapingsqlobj.setSubjectId(subid);
        mappinglist.add(mmapingsqlobj);
        return mappinglist;
    }

    public static List<String> cahngelatindexoflist(List<String> querylist) {
        List<String> appndedlist = new LinkedList<>();
        String Query = querylist.get(querylist.size() - 1);
        StringBuffer sb1 = new StringBuffer();
        int i = 0;
        Matcher m = Pattern.compile("\\(([^)]+)\\)").matcher(Query);
        while (m.find()) {
            if (i == 0) {
                sb1.append(m.group(1));
            }
            i++;
        }
        String splittingquery = Query.split("\\)")[1].trim().split(" ")[1];
        if (splittingquery.contains("*")) {
            if (splittingquery.contains(".")) {
                String replacedString = Query.replace(splittingquery, sb1.toString());
                querylist.set(querylist.size() - 1, replacedString);
            } else {
                String replacedString = Query.replaceFirst("\\" + Query.split("\\)")[1].split(" ")[1], sb1.toString());
                querylist.set(querylist.size() - 1, replacedString);
            }

        }
        appndedlist.addAll(querylist);
        return appndedlist;
    }

    public static List<String> getAppendedstatement(List<String> queryList) {
        String querycontent = queryList.get(queryList.size() - 1);
        StringBuffer sb = new StringBuffer();
        String[] filessqlstr = querycontent.split("\n");
        int i = 0;
        for (String sqlf : filessqlstr) {
            if (i == 0) {
                String sqlf2 = sqlf.replace((sqlf.substring(sqlf.lastIndexOf(" "), sqlf.length() - 1)), (sqlf.substring(sqlf.lastIndexOf(" "), sqlf.length() - 1) + "_1"));
                sb.append(sqlf2).append("\n");
            } else {
                sb.append(sqlf).append("\n");
            }
            i++;
        }
        String sqlcontent = queryList.get(queryList.size() - 1);
        if (sqlcontent.startsWith("UPDATE")) {
            queryList.remove(queryList.size() - 1);
        } else {
            queryList.set(queryList.size() - 1, sb.toString());
        }
        return queryList;
    }

    public static Dlineage getDataflowObject(String sqlquery, String dbvendor) {
        Dlineage dataflow = null;
        try {
            String dataflowAnalyzerxml = DataFlowAnalyzerv1.getanalyzeXmlfromString(sqlquery, dbvendor);
            InputStream in = IOUtils.toInputStream(dataflowAnalyzerxml);
            JAXBContext jaxbContext
                    = JAXBContext.newInstance("com.sqlToJson.BindingPojo");
            Unmarshaller unmarshaller
                    = jaxbContext.createUnmarshaller();
            dataflow = (Dlineage) unmarshaller.unmarshal(in);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return dataflow;
    }

    public static void getLineageforUpdate(String lastselectQuery, String UpdateQuery, String dbVendor) {
        Map<String, String> updatelineage = new LinkedHashMap<>();
        Map<String, String> selectLineage = new LinkedHashMap<>();
        String targetforUpdateset = "";

        String sourceDetails = "";
        String upDateset = "UPDATE-SET";
        Dlineage source = getDataflowObject(lastselectQuery, dbVendor);
        for (Object Dlineageobject : source.getColumnOrTableOrResultset()) {

            if (Dlineageobject instanceof Dlineage.Relation) {
                if (((Dlineage.Relation) Dlineageobject).getType().equals("dataflow")) {

                    for (Dlineage.Relation.Target subselectsource : ((Dlineage.Relation) Dlineageobject).getTarget()) {
                        if (subselectsource.getParentName().equals("RESULT_OF_SELECT-QUERY") || subselectsource.getParentName().equals("RESULT_OF_SELECT-QUERY-1") || subselectsource.getParentName().equals("RESULT_OF_SELECT-QUERY-2") || subselectsource.getParentName().equals("RESULT_OF_SELECT-QUERY-3")) {

                            String resultofselectquery = "RESULT_OF_SELECT-QUERY";
                            if (selectLineage.get(subselectsource.getParentName()) == null) {
                                selectLineage.put(subselectsource.getParentName(), subselectsource.getColumn());
                            } else {
                                String value = selectLineage.get(subselectsource.getParentName());
                                selectLineage.put(subselectsource.getParentName(), value + "#" + subselectsource.getColumn());

                            }
                            if ("".equals(sourceDetails)) {
                                sourceDetails = resultofselectquery + "#" + subselectsource.getColumn();
                                targetforUpdateset = upDateset + "#" + subselectsource.getColumn();
                            } else {

                                sourceDetails = sourceDetails + "$" + resultofselectquery + "#" + subselectsource.getColumn();
                                targetforUpdateset = targetforUpdateset + "$" + upDateset + "#" + subselectsource.getColumn();
                            }
                        }

                    }

                }
            }
            int g = 0;
        }
        Dlineage target = getDataflowObject(UpdateQuery, dbVendor);
        String updatesettarget = "";
        String updatetarget = "";
        String targetTableName = "";
        String targetside = "";
        for (Object Dlineageobject : target.getColumnOrTableOrResultset()) {
            if (Dlineageobject instanceof Dlineage.Relation) {
                if (((Dlineage.Relation) Dlineageobject).getType().equals("dataflow")) {
                    for (Dlineage.Relation.Source updatequery : ((Dlineage.Relation) Dlineageobject).getSource()) {
                        //  if (updatequery.getParentName().equals("UPDATE-SET")) {
                        if (updatequery.getParentName().contains("UPDATE-SET")) {
                            for (Dlineage.Relation.Target updatequerytgt : ((Dlineage.Relation) Dlineageobject).getTarget()) {
                                targetTableName = updatequerytgt.getParentName();
                                break;
                            }
                            String updateset = "UPDATE-SET";
                            if ("".equals(updatesettarget)) {
                                updatesettarget = updateset + "#" + updatequery.getColumn();

                            } else {
                                updatesettarget = updatesettarget + "$" + updateset + "#" + updatequery.getColumn();

                            }

                        } else if ("".equals(updatetarget)) {
                            updatetarget = updatequery.getParentName() + "#" + updatequery.getColumn();
                            updateTargetTableName = updatequery.getParentName();

                        } else {
                            updatetarget = updatetarget + "$" + updatequery.getParentName() + "#" + updatequery.getColumn();

                        }
                    }

                    for (Dlineage.Relation.Target updatequerytgt : ((Dlineage.Relation) Dlineageobject).getTarget()) {
                        if (updatequerytgt.getParentName().equals(targetTableName)) {
                            if ("".equals(targetside)) {
                                targetside = updatequerytgt.getParentName() + "#" + updatequerytgt.getColumn();
                            } else {
                                targetside = targetside + "$" + updatequerytgt.getParentName() + "#" + updatequerytgt.getColumn();
                            }
                        }

                    }
                }
            }

        }

        updatelineage.put(sourceDetails, targetforUpdateset);
        updatelineage.put(updatesettarget, targetside);
        addUpdatemapspecrowForUpdate(updatelineage);
    }

    public static void addUpdatemapspecrow(Map<String, String> updateLineageMap) {
        try {

            for (Map.Entry<String, String> entry : updateLineageMap.entrySet()) {
                String key = entry.getKey();
                String value = entry.getValue();
                String[] source = key.split("\\$");
                String[] target = value.split("\\$");
                Set<String> sourcelist = new LinkedHashSet<>(Arrays.asList(source));
                Set<String> targetlist = new LinkedHashSet<>(Arrays.asList(target));
                List<String> uniquetargetlist = new LinkedList<>(targetlist);
                int i = 0;
                for (String src : sourcelist) {
                    MappingSpecificationRow mapspec = new MappingSpecificationRow();
                    mapspec.setSourceSystemEnvironmentName(sourceEnvironmentNamegl);
                    mapspec.setTargetSystemEnvironmentName(targetEnvironmentNamegl);
                    mapspec.setSourceSystemName(sourceSystemNamegl);
                    mapspec.setTargetSystemName(targetSystemNamegl);
                    mapspec.setSourceTableName(src.split("#")[0]);
                    if (src.split("#").length > 1) {

                        mapspec.setSourceColumnName(src.split("#")[1]);
                    }

                    if (targetlist.size() <= i) {
                        mapspec.setTargetTableName(" ");
                        mapspec.setTargetColumnName(" ");
                    } else {
                        mapspec.setTargetTableName(uniquetargetlist.get(i).split("#")[0]);
                        if (uniquetargetlist.get(i).split("#").length > 1) {
                            mapspec.setTargetColumnName(uniquetargetlist.get(i).split("#")[1]);
                        }

                    }
                    i++;
                    mapspeclist.add(mapspec);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    public static void addUpdatemapspecrow(Map<String, String> updateLineageMap, Set<String> insertlist) {
        try {
            List<String> uniquetargetlist = null;
            for (Map.Entry<String, String> entry : updateLineageMap.entrySet()) {
                String key = entry.getKey();
                String value = entry.getValue();
                String[] source = key.split("\\$");
                String[] target = value.split("\\$");

                Set<String> sourcelist = new LinkedHashSet<>(Arrays.asList(source));
                Set<String> targetlist = new LinkedHashSet<>(Arrays.asList(target));

                uniquetargetlist = new LinkedList<>(targetlist);
                if (value.contains("INSERT-SELECT")) {
                    uniquetargetlist = new LinkedList<>(insertlist);
                }
                int i = 0;
                for (String src : sourcelist) {
                    MappingSpecificationRow mapspec = new MappingSpecificationRow();
                    mapspec.setSourceSystemEnvironmentName(sourceEnvironmentNamegl);
                    mapspec.setTargetSystemEnvironmentName(targetEnvironmentNamegl);
                    mapspec.setSourceSystemName(sourceSystemNamegl);
                    mapspec.setTargetSystemName(targetSystemNamegl);
                    mapspec.setSourceTableName(src.split("#")[0]);
                    if (src.split("#").length > 1) {

                        mapspec.setSourceColumnName(src.split("#")[1]);
                    }

                    if (targetlist.size() <= i) {
                        mapspec.setTargetTableName(" ");
                        mapspec.setTargetColumnName(" ");
                    } else {
                        mapspec.setTargetTableName(uniquetargetlist.get(i).split("#")[0]);
                        mapspec.setTargetColumnName(uniquetargetlist.get(i).split("#")[1]);
                    }
                    i++;
                    mapspeclist.add(mapspec);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    public static void addUpdatemapspecrowForUpdate(Map<String, String> updateLineageMap) {
        for (Map.Entry<String, String> entry : updateLineageMap.entrySet()) {
            String key = entry.getKey();
            String value = entry.getValue();
            String[] source = key.split("\\$");
            String[] target = value.split("\\$");
            int i = 0;
            for (String src : source) {
                MappingSpecificationRow mapspec = new MappingSpecificationRow();
                mapspec.setSourceSystemEnvironmentName(sourceEnvironmentNamegl);
                mapspec.setTargetSystemEnvironmentName(targetEnvironmentNamegl);
                mapspec.setSourceSystemName(sourceSystemNamegl);
                mapspec.setTargetSystemName(targetSystemNamegl);
                if (src.split("#")[0].contains("RESULT_OF_SELECT-QUERY")) {
                    String tableName = "RESULT_OF_SELECT-QUERY";
                    mapspec.setSourceTableName(tableName);
                } else {
                    mapspec.setSourceTableName(src.split("#")[0]);

                }
                if (src.split("#").length > 1) {
                    mapspec.setSourceColumnName(src.split("#")[1]);

                }
                if (target.length <= i) {
                    mapspec.setTargetTableName(" ");
                    mapspec.setTargetColumnName(" ");
                } else {
                    if (value.split("\\$")[i].split("#")[0].equalsIgnoreCase("OUTPUT-OF-SELECT-QUERY-1")) {
                        String tableName = "OUTPUT-OF-SELECT-QUERY";
                        mapspec.setTargetTableName(tableName);
                    } else {
                        mapspec.setTargetTableName(value.split("\\$")[i].split("#")[0]);

                    }
                    if (value.split("\\$")[i].split("#").length > 1) {
                        mapspec.setTargetColumnName(value.split("\\$")[i].split("#")[1]);

                    }
                }
                i++;
                mapspeclist.add(mapspec);
            }
        }

    }

    public static void getLineageForDelete(String lastselectQuery, String deletequery, String dbvendor) {
        String targetTableName = deletequery.split("\n")[0].trim().substring(deletequery.split("\n")[0].trim().lastIndexOf(" ")).trim();
        deleteTargetTableName = targetTableName;
        Dlineage resultofselectQuery = getDataflowObject(lastselectQuery, dbvendor);
        String resultquery = "";
        String deletestmt = "";
        String trgtstmt = "";
        Map<String, String> deletelineageMap = new LinkedHashMap<>();
        String deletestatement = "DELETE-SELECT";
        for (Object Dlineageobject : resultofselectQuery.getColumnOrTableOrResultset()) {
            if (Dlineageobject instanceof Dlineage.Relation) {
                if (((Dlineage.Relation) Dlineageobject).getType().equals("dataflow")) {
                    for (Dlineage.Relation.Target resultofselectquery : ((Dlineage.Relation) Dlineageobject).getTarget()) {
                        if (resultofselectquery.getParentName().equals("RESULT_OF_SELECT-QUERY")) {
                            if ("".equals(resultquery)) {
                                resultquery = resultofselectquery.getParentName() + "#" + resultofselectquery.getColumn();
                                deletestmt = deletestatement + "#" + resultofselectquery.getColumn();
                                trgtstmt = targetTableName + "#" + resultofselectquery.getColumn();

                            } else {
                                deletestmt = deletestmt + "$" + deletestatement + "#" + resultofselectquery.getColumn();
                                resultquery = resultquery + "$" + resultofselectquery.getParentName() + "#" + resultofselectquery.getColumn();
                                trgtstmt = trgtstmt + "$" + targetTableName + "#" + resultofselectquery.getColumn();
                            }

                        }

                    }
                }
            }

        }
        deletelineageMap.put(resultquery, deletestmt);
        deletelineageMap.put(deletestmt, trgtstmt);
        addUpdatemapspecrow(deletelineageMap);
    }

    public static void getLineageFordeleteunion(String lastselectQuery, String deletequery, String dbvendor) {
        try {
            String targetTableName = deletequery.split("\n")[0].substring(deletequery.split("\n")[0].lastIndexOf(" "));
            deleteTargetTableName = targetTableName;
            Dlineage resultofselectQuery = getDataflowObject(lastselectQuery, dbvendor);
            Dlineage deleteunion = getDataflowObject(deletequery, dbvendor);
            String targetunion = "";
            String resultquery = "";
            String targettableName = "";
            String targetvale = "";
            String sourcetableName = "";
            Map<String, String> deletelineageMap = new LinkedHashMap<>();
            String deletestatement = "DELETE_SELECT";
            String deleteselect = "";
            for (Object Dlineageobject : resultofselectQuery.getColumnOrTableOrResultset()) {
                if (Dlineageobject instanceof Dlineage.Relation) {
                    if (((Dlineage.Relation) Dlineageobject).getType().equals("dataflow")) {
                        for (Dlineage.Relation.Target resultofselectquery : ((Dlineage.Relation) Dlineageobject).getTarget()) {

                            if (resultofselectquery.getParentName().equals("RESULT_OF_SELECT-QUERY") || resultofselectquery.getParentName().equals("RESULT_OF_SELECT-QUERY-1")) {
                                if ("".equals(resultquery)) {
                                    resultquery = resultofselectquery.getParentName() + "#" + resultofselectquery.getColumn();

                                    targetvale = targetTableName + "#" + resultofselectquery.getColumn();
                                    deleteselect = deletestatement + "#" + resultofselectquery.getColumn();
                                } else {
                                    resultquery = resultquery + "$" + resultofselectquery.getParentName() + "#" + resultofselectquery.getColumn();
                                    targetvale = targetvale + "$" + targetTableName + "#" + resultofselectquery.getColumn();
                                    deleteselect = deleteselect + "$" + deletestatement + "#" + resultofselectquery.getColumn();
                                }

                            }

                        }

                    }
                }

            }
            for (Object Dlineageobject : deleteunion.getColumnOrTableOrResultset()) {
                if (Dlineageobject instanceof Dlineage.Relation) {
                    if (((Dlineage.Relation) Dlineageobject).getType().equals("dataflow")) {
                        for (Dlineage.Relation.Target resultofselectquery : ((Dlineage.Relation) Dlineageobject).getTarget()) {
                            if (resultofselectquery.getParentName().equals("RESULT_OF_UNION")) {
                                targettableName = resultofselectquery.getParentName();

                                for (Dlineage.Relation.Source updatequery : ((Dlineage.Relation) Dlineageobject).getSource()) {
                                    if ("".equals(targetunion)) {
                                        targetunion = targettableName + "#" + updatequery.getColumn();
//                                        sourcetableName = updatequery.getParentName() + "#" + updatequery.getColumn();

                                    } else {
                                        sourcetableName = sourcetableName + "$" + updatequery.getParentName() + "#" + updatequery.getColumn();
                                        targetunion = targetunion + "$" + targettableName + "#" + updatequery.getColumn();
                                    }
                                }

                            }

                        }
                    }

                }
            }

            String sourceside = resultquery + "$" + sourcetableName;
            deletelineageMap.put(sourceside, targetunion);
            deletelineageMap.put(targetunion, deleteselect);

            deletelineageMap.put(deleteselect, targetvale);
            addUpdatemapspecrow(deletelineageMap);
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    public static void updatespecrow(ArrayList<MappingSpecificationRow> mapspeclist, String tablename) {
        Iterator<MappingSpecificationRow> iter = mapspeclist.iterator();
        while (iter.hasNext()) {
            MappingSpecificationRow row = iter.next();
            if (row.getTargetTableName().equals(tablename)) {
                iter.remove();
            }
        }
    }

    public static void updatespecrowforselectQuery(ArrayList<MappingSpecificationRow> mapspeclist) {
        Iterator<MappingSpecificationRow> iter = mapspeclist.iterator();
        while (iter.hasNext()) {
            MappingSpecificationRow row = iter.next();
            if (row.getTargetTableName().contains("RESULT_OF_SELECT-QUERY")) {
                row.setTargetTableName("RESULT_OF_SELECT-QUERY");
            }
        }
    }

    public static ArrayList<MappingSpecificationRow> updatespecrowforstar(ArrayList<MappingSpecificationRow> mapspeclist) {
        ArrayList<MappingSpecificationRow> rowlist = new ArrayList();
        try {
            Iterator<MappingSpecificationRow> iter = mapspeclist.iterator();
            while (iter.hasNext()) {
                MappingSpecificationRow row = iter.next();
                if (row.getSourceColumnName().equalsIgnoreCase("*")) {
                    boolean columnflag = false;
                    String sourceTableName = row.getSourceTableName();
                    String targetTableName = row.getTargetTableName();
                    if (!"".equals(sourceTableName) && !"".equals(targetTableName)) {
                        List<String> columns = new LinkedList();
                        if (tableColforstar.get(sourceTableName) != null) {
                            columns = tableColforstar.get(sourceTableName);
                            columnflag = true;
                        }
                        //
                        Set<String> columnset = new LinkedHashSet(columns);
                        if(columnset.size()!=1)
                        {
                          columnset.remove("*");
                        }
                        for (String column : columnset) {
                            MappingSpecificationRow row1 = new MappingSpecificationRow();
                            row1.setSourceSystemEnvironmentName(sourceEnvironmentNamegl);
                            row1.setTargetSystemEnvironmentName(targetEnvironmentNamegl);
                            row1.setSourceSystemName(sourceSystemNamegl);
                            row1.setTargetSystemName(targetSystemNamegl);
                            row1.setSourceTableName(sourceTableName);
                            row1.setTargetTableName(targetTableName);
                            row1.setSourceColumnName(column);
                            row1.setTargetColumnName(column);
                            rowlist.add(row1);
                        }
                        tableColforstar.remove(sourceTableName);
                        if (columnflag) {
                            iter.remove();
                        }
                    }
                }
            }
        } catch (Exception e) {
        }

        return rowlist;
    }

    public static void removeNullfromspec(ArrayList<MappingSpecificationRow> mapspeclist) {
        Iterator<MappingSpecificationRow> iter = mapspeclist.iterator();
        while (iter.hasNext()) {
            MappingSpecificationRow row = iter.next();
            if (row.getTargetColumnName().equals("null") || row.getSourceColumnName().equals("null")) {
                iter.remove();
            }
            if (((row.getSourceTableName().equals("") || row.getSourceTableName().equalsIgnoreCase("NULL")) && (row.getSourceColumnName().equals("") || row.getSourceColumnName().equalsIgnoreCase("NULL"))) && ((row.getTargetTableName().equals("") || row.getTargetTableName().equalsIgnoreCase("NULL")) && (row.getTargetColumnName().equals("") || row.getTargetColumnName().equalsIgnoreCase("NULL")))) {
                iter.remove();
            }
        }
    }

    public static void updateMiddleComponent(ArrayList<MappingSpecificationRow> mapspeclist, String mapname) {
        Iterator<MappingSpecificationRow> iter = mapspeclist.iterator();
        while (iter.hasNext()) {
            MappingSpecificationRow row = iter.next();
            if (row.getTargetColumnName().contains(dbName) || row.getSourceColumnName().equals("null")) {
                iter.remove();
            }
        }
    }

    public static String getcolumnName(TResultColumnList resultcolumnlist, String tableName) {
        String sourceInfo = "";
        for (int i = 0; i < resultcolumnlist.size(); i++) {
            TResultColumn column = resultcolumnlist.getResultColumn(i);
            TExpression expr = column.getExpr();
            String expression = expr.toString();
            String sourcecolumnName = column.getColumnNameOnly();

        }
        return sourceInfo;
    }

    public static String getcolumnAliasName(TResultColumnList resultcolumnlist, String tableName) {
        String sourceInfo = "";

        for (int i = 0; i < resultcolumnlist.size(); i++) {
            TResultColumn column = resultcolumnlist.getResultColumn(i);
            TExpression expr = column.getExpr();
            String expretion = expr.toString();
            String sourcecolumnName = column.getColumnNameOnly();

            if ("".equals(sourcecolumnName)) {
                sourcecolumnName = column.getColumnAlias();
                if ("".equals(sourcecolumnName)) {
                    int j = 0;
                    Matcher m = Pattern.compile("\\(([^)]+)\\)").matcher(expretion);
                    while (m.find()) {
                        if (j == 0) {
                            sourcecolumnName = m.group(1);
                        }
                        j++;
                    }
                }
            }

            if ("".equals(sourceInfo)) {
                sourceInfo = tableName + "#" + expretion + "#" + sourcecolumnName;
            } else {
                sourceInfo = sourceInfo + "$" + tableName + "#" + expretion + "#" + sourcecolumnName;
            }
        }
        return sourceInfo;
    }

    public static List<String> changelastselectquery(List<String> queryaliasnamelist) {
        List<String> appendedList = new LinkedList<>();
        String lastquery = queryaliasnamelist.get(queryaliasnamelist.size() - 1);
        String aliasName = lastquery.substring(lastquery.lastIndexOf(" "));
        String selectquery = "(" + lastquery + ")";

        queryaliasnamelist.set(queryaliasnamelist.size() - 1, selectquery);
        appendedList.addAll(queryaliasnamelist);
        return appendedList;
    }

    private static void getExpression(List<String> querylist, HashMap<String, String> tableAliasMap, String dbVender) {

        dbVendor = EDbVendor.dbvoracle;
        sqlparser = new TGSqlParser(dbVendor);

        for (String query : querylist) {
            sqlparser.sqltext = query.toUpperCase();
            int ret = sqlparser.parse();
            if (ret == 0) {
                TCustomSqlStatement stmnt = sqlparser.sqlstatements.get(0);
                TTableList list = stmnt.getTables();
                for (int i = 0; i < list.size(); i++) {
                    TTable table = list.getTable(i);
                    String tablename = table.getFullName();
                    String tableAliasName = table.getAliasName();
                    if ("".equals(tablename)) {
                        tablename = tableAliasName;
                    }

                    TResultColumnList resultlist = stmnt.getResultColumnList();
                    if (resultlist == null) {
                        continue;
                    }

                    for (int j = 0; j < resultlist.size(); j++) {
                        TResultColumn column = resultlist.getResultColumn(j);
                        TExpression expr = column.getExpr();
                        getSourceTableDetailsfrorExpression(column.getExpr().toString(), tableAliasMap);

                    }
                }
            }

        }

    }

    public static void getSourceTableDetailsfrorExpression(String expression, HashMap<String, String> tableAliasMap) {
        ArrayList<String> columnsinExpression = new ArrayList<String>();
        Set<String> keyset = specTableColumnDetails.keySet();
        //    specTableColumnDetails.get(keyset);
        for (String key : keyset) {
            ArrayList<String> colList = specTableColumnDetails.get(key);
            for (String colName : colList) {
                String als = getKeyFromValue(tableAliasMap, key + "#" + colName, expression);
                if (als == null) {
                    continue;
                }
                String[] expSp = expression.split("\\b" + als + "." + colName + "\\b");
                if (expSp.length > 1) {
                    sourceTableColumndeatilsWithBusinessRule.put(tableAliasMap.get(als) + "#" + colName, expression);
                }

            }

        }

    }

    public static String getKeyFromValue(HashMap<String, String> hm, String value, String expression) {
        for (String al : hm.keySet()) {
            if (hm.get(al) != null) {
                if (hm.get(al).toUpperCase().equals(value.split("#")[0])) {
                    return al;
                }
            }
        }
        return null;
    }

    public static Map<String, String> getsourcebrMap(Map<String, String> childParentMap, String dbvender) {
        getBrFromParentChildMap(childParentMap);

        Map<String, String> sourceExpressionTarget = new LinkedHashMap();
        Map<String, List<String>> parentMap = new LinkedHashMap<>();
        try {
            for (Map.Entry<String, String> entry : childParentMap.entrySet()) {
                String key = entry.getKey();
                String value = entry.getValue();
                if (value.startsWith("(")) {
                    value = value.substring(1, value.length() - 1);

                }
                if (key.trim().startsWith("(") && key.trim().endsWith(")")) {
                    key = key.substring(1, key.length() - 1);
                }
                if (value != null && value.trim().toUpperCase().startsWith("INSERT")) {
                    continue;
                }
                if (value.contains("UNION") && !value.startsWith("INSERT") && !value.startsWith("UPDATE")) {
                    value = value.split("UNION")[0];
                    if (value.startsWith("(")) {
                        value = value.substring(1, value.length());
                        key = value;
                    }
                }

                if (value.toUpperCase().startsWith("DELETE")) {
                    TCustomSqlStatement stmt = getselectstatement(value, dbvender);
                    if (stmt == null) {
                        continue;
                    }
                    value = stmt.toString();
                }
                if (value.toUpperCase().startsWith("UPDATE")) {
                    TCustomSqlStatement stmt = getselectstatement(value, dbvender);
                    value = stmt.toString();
                }
                List<String> TargetqueryList = getsourceMap(value, dbvender);
                List<String> columnString = new LinkedList();
                dbVendor = getEDbVendorType(dbvender);

                sqlparser = new TGSqlParser(dbVendor);
                sqlparser.sqltext = key;
                int ret = sqlparser.parse();
                if (ret == 0) {
                    TCustomSqlStatement stmnt = sqlparser.sqlstatements.get(0);

                    TResultColumnList rsltstatement = stmnt.getResultColumnList();
                    if (stmnt.getFirstPhysicalTable() == null || rsltstatement == null) {

                        continue;
                    }
                    for (int j = 0; j < rsltstatement.size(); j++) {
                        if (TargetqueryList.size() == 0) {
                            continue;
                        }

                        String tableName = stmnt.getFirstPhysicalTable().getName();
                        String tableAliasName = stmnt.getTables().getTable(0).getAliasName();// code for alias name
                        if (!"".equals(tableAliasName)) {
                            tableName = "RESULT_OF_" + tableAliasName.toUpperCase();
                        }
                        TResultColumn column = rsltstatement.getResultColumn(j);
                        String columnName = column.getColumnNameOnly();
                        String ColumnAliasname = column.getColumnAlias();
                        String targettablecolumnName = "";
                        if (TargetqueryList.size() == 1 && TargetqueryList.get(0).contains("*")) {
                            String targettableName = TargetqueryList.get(0).split("\\$")[0];
                            if ("".equals(columnName)) {
                                String colalias = ColumnAliasname;
                                targettablecolumnName = targettableName + "$" + colalias;
                            } else {
                                targettablecolumnName = targettableName + "$" + columnName;
                            }
                        } else if (TargetqueryList.get(0).split("\\$").length == 1) {
                            String targettableName = TargetqueryList.get(0).split("\\$")[0];
                            if ("".equals(columnName)) {
                                String colalias = ColumnAliasname;
                                targettablecolumnName = targettableName + "$" + colalias;
                            }
                        } else if (TargetqueryList.size() == j) {
                            targettablecolumnName = TargetqueryList.get(TargetqueryList.size() - 1);
                        } else {
                            targettablecolumnName = TargetqueryList.get(j);

                        }
                        String Expr = column.getExpr().toString();
                        TExpression expression = column.getExpr();
                        EExpressionType type = expression.getExpressionType();
                        if (type == type.parenthesis_t) {
                            if (Expr.startsWith("(") && Expr.endsWith(")")) {
                                Expr = Expr.substring(1, Expr.length() - 1);
                            }
                        } else if (Expr.contains("case")) {
                            if (!Expr.contains("(")) {
                                String temp = Expr.split("then")[0].split("when")[1];
                                String temp1 = "(" + temp + ")";
                                Expr = Expr.replace(temp, temp1);
                                if (Expr.startsWith("(") && Expr.endsWith(")")) {
                                    Expr = Expr.substring(1, Expr.length() - 1);
                                }
                            }

                        }
                        if ("".equals(columnName)) {
                            columnName = getColumnNameFromBr(Expr);
                        }
                        String sourcetableInfor = tableName + "$" + columnName + "#" + Expr;
                        if (type == type.simple_object_name_t) {
                            continue;
                        } else if (sourceExpressionTarget.get(sourcetableInfor) != null) {
                            sourceExpressionTarget.put(sourcetableInfor, sourceExpressionTarget.get(sourcetableInfor) + "##" + targettablecolumnName);
                        } else {
                            sourceExpressionTarget.put(sourcetableInfor, targettablecolumnName);
                        }

                    }
                }

            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return sourceExpressionTarget;

    }

    public static List<String> getsourceMap(String valueFromchildParentMap, String dbvendor) {
        Map<String, List<String>> ParentSideMap = new LinkedHashMap<>();
        List<String> targetColumnList = new LinkedList();
        try {
            dbVendor = getEDbVendorType(dbvendor);
            sqlparser = new TGSqlParser(dbVendor);
            sqlparser.sqltext = valueFromchildParentMap;
            int ret = sqlparser.parse();
            if (ret == 0) {
                TCustomSqlStatement stmnt = sqlparser.sqlstatements.get(0);
                if (stmnt.getFirstPhysicalTable() == null || stmnt.getResultColumnList() == null) {

                    return targetColumnList;
                }
                String tableName = stmnt.getFirstPhysicalTable().getName();
                String AliasName = stmnt.getTables().getTable(0).getAliasName();
                if (!"".equals(AliasName) && !"".equals(tableName)) {
                    if (!tableName.equalsIgnoreCase(AliasName)) {
                        if (AliasName.contains(tableName)) {
                            tableName = AliasName;
                        }
                    }
                }
                if (!"".equals(AliasName) && (tableName != null && tableName.trim().equals(""))) {
                    tableName = "RESULT_OF_" + AliasName.toUpperCase();
                }
                TResultColumnList rsltstatement = stmnt.getResultColumnList();

                for (int j = 0; j < rsltstatement.size(); j++) {
                    if (stmnt.getJoins().size() == 0) {
                        continue;
                    }
                    for (int join_cond = 0; join_cond < stmnt.getJoins().size(); join_cond++) {
                        TJoin joincond = stmnt.getJoins().getJoin(join_cond);
                        for (int j_cond = 0; j_cond < joincond.getJoinItems().size(); j_cond++) {
                            TJoinItem joinitem = joincond.getJoinItems().getJoinItem(j_cond);
                            joinconditions.add(joinitem.toString());
                            EJoinType jointype = joinitem.getJoinType();
//                            System.out.println("jointypes----" + jointype);
                        }

                    }
                    if (stmnt.getWhereClause() != null) {
                        String wherecondition = stmnt.getWhereClause().toString();

                        whereCondition.add(wherecondition);
                    }

                    TResultColumn column = rsltstatement.getResultColumn(j);
                    String columnName = column.getColumnNameOnly();
                    String columnAliasName = column.getColumnAlias();

                    // stmnt.getResultColumnList().getResultColumn(j).getAliasClause().getAliasName()
//               String srcColumnalias = stmnt.getResultColumnList().getResultColumn(j).getColumnAlias();
                    if (!"".equals(columnAliasName)) {
                        columnName = columnAliasName;
                    }

                    String Expr = column.getExpr().toString();
                    targetColumnList.add(tableName + "$" + columnName);

                }

            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return targetColumnList;
    }

    public static String getColumnNameFromBr(String businesRule) {
        Matcher m = Pattern.compile("\\(([^)]+)\\)").matcher(businesRule);
        StringBuilder sb = new StringBuilder();
        int i = 0;
        while (m.find()) {
            if (i == 0) {
                if (businesRule.contains("case") || businesRule.contains("isnull")) {
                    if (businesRule.contains("isnull")) {
                        String columnName = m.group(1).split("\\.")[1].split(",")[0];
                        sb.append(columnName);
                    } else if (m.group(1).contains("=")) {
                        if (m.group(1).contains("case")) {
                            String columnName = m.group(1).split("=")[0].split("\\.")[1];
                            sb.append(columnName);
                        }
                        if (m.group(1).contains("_")) {
                            String columnName = m.group(1).split("=")[0];
                            sb.append(columnName);
                        } else {
                            String columnName = m.group(1).split("=")[0].split("\\.")[1];
                            sb.append(columnName);
                        }

                    } else if (m.group(1).contains(",")) {
                        String columnName = m.group(1).split(",")[0].split("\\.")[1];
                        sb.append(columnName);
                    } else if (m.group(1).contains("cast")) {

                        String columnName = m.group(1).split("\\(")[1].substring(0, m.group(1).split("\\(")[1].indexOf(" "));
                        sb.append(columnName);
                    } else {
                        String columnName = m.group(1).split("\\.")[1].substring(0, m.group(1).split("\\.")[1].indexOf(" "));
                        sb.append(columnName);
                    }

                } else {
                    String columnName = m.group(1);
                    sb.append(columnName);
                }

            }
            i++;
        }
        return sb.toString();
    }

    public static TCustomSqlStatement getselectstatement(String statement, String dbvendor) {
        dbVendor = getEDbVendorType(dbvendor);
        TCustomSqlStatement stmt2 = null;
        TCustomSqlStatement statement2 = null;
        sqlparser = new TGSqlParser(dbVendor);
        sqlparser.sqltext = statement;
        int ret = sqlparser.parse();
        if (ret == 0) {
            for (int i = 0; i < sqlparser.sqlstatements.size(); i++) {
                statement2 = sqlparser.sqlstatements.get(i);
                if ((statement2 instanceof TDeleteSqlStatement)) {
                    for (int j = 0; j < statement2.getStatements().size(); j++) {
                        stmt2 = (TSelectSqlStatement) statement2.getStatements().get(j);
                    }

                }
                if ((statement2 instanceof TUpdateSqlStatement)) {
                    for (int j = 0; j < statement2.getStatements().size(); j++) {
                        stmt2 = (TSelectSqlStatement) statement2.getStatements().get(j);
                    }

                }
                if ((statement2 instanceof TDeleteSqlStatement)) {
                    for (int j = 0; j < statement2.getStatements().size(); j++) {
                        stmt2 = (TSelectSqlStatement) statement2.getStatements().get(j);
                    }

                }
                if ((statement2 instanceof TInsertSqlStatement)) {
                    for (int j = 0; j < statement2.getStatements().size(); j++) {
                        stmt2 = (TSelectSqlStatement) statement2.getStatements().get(j);
                    }

                }
                if ((statement2 instanceof TCreateViewSqlStatement)) {
                    for (int j = 0; j < statement2.getStatements().size(); j++) {
                        stmt2 = (TSelectSqlStatement) statement2.getStatements().get(j);
                    }

                }
            }

        }
        if (stmt2 == null && statement2 != null) {
            return statement2;
        }
        return stmt2;
    }

    public static void updatebusinessRule(Map<String, String> expressionMap, ArrayList<MappingSpecificationRow> speclist) {
        for (Map.Entry<String, String> entry : expressionMap.entrySet()) {
            String key = entry.getKey();
            String value = entry.getValue();
            String sourceTableName = key.split("#")[0].split("\\$")[0];
            String sourceColumnName = "";
            if (key.split("#")[0].split("\\$").length <= 1) {
                sourceColumnName = "";
            } else {
                sourceColumnName = key.split("#")[0].split("\\$")[1];
            }
            String targetTableName = "";
            String targetColumnName = "";
//            String sourceColumnName = key.split("#")[0].split("\\$")[1];
            String businessRule = key.split("#")[1];
            if (businessRule.contains("%")) {
                businessRule = businessRule.replaceAll("%", "");
            }
            boolean updateValue = false;
            if (value.split("##").length >= 2) {
                Set<String> setOfColumns = new LinkedHashSet<>(Arrays.asList(value.split("##")));
                List<String> listofColumns = new LinkedList(setOfColumns);
                for (int target_i = 0; target_i < listofColumns.size(); target_i++) {
                    targetTableName = listofColumns.get(target_i).split("\\$")[0];

                    targetColumnName = listofColumns.get(target_i).split("\\$")[1];
                    if (targetColumnName.contains("*")) {
                        targetColumnName = listofColumns.get(target_i).split("\\$")[2];
                    }
                    updateValue = rowupdate(speclist, sourceTableName, targetTableName, sourceColumnName, targetTableName, targetColumnName, businessRule);
                    if (sourceTableName.equalsIgnoreCase(targetTableName) && sourceColumnName.equalsIgnoreCase(targetColumnName)) {
                        targetTableName = "RESULT_OF_SELECT-QUERY";

                    }

                    if (sourceTableName.equalsIgnoreCase(targetTableName) && !sourceColumnName.equalsIgnoreCase(targetColumnName)) {
                        targetTableName = "RESULT_OF_SELECT-QUERY";

                    }

                    if (!updateValue) {
                        MappingSpecificationRow row1 = new MappingSpecificationRow();
                        if ("".equals(sourceColumnName)) {
                            row1.setTargetSystemName(targetSystemNamegl);
                            row1.setTargetSystemEnvironmentName(targetEnvironmentNamegl);
                            row1.setTargetTableName(targetTableName);
                            row1.setTargetColumnName(targetColumnName);
                            row1.setBusinessRule(businessRule);
                            speclist.add(row1);
                        } else {
                            row1.setSourceSystemEnvironmentName(sourceEnvironmentNamegl);
                            row1.setTargetSystemEnvironmentName(targetEnvironmentNamegl);
                            row1.setSourceSystemName(sourceSystemNamegl);
                            row1.setTargetSystemName(targetSystemNamegl);
                            row1.setSourceTableName(sourceTableName);

                            row1.setSourceColumnName(sourceColumnName);
                            row1.setTargetTableName(targetTableName);
                            row1.setTargetColumnName(targetColumnName);
                            row1.setBusinessRule(businessRule);
                            speclist.add(row1);
                        }
                    }
                }

            } else {
                targetTableName = value.split("\\$")[0];
//                targetColumnName = value.split("\\$")[1];
                if (value.split("\\$").length <= 2) {
                    if (value.split("\\$").length == 1) {
                        targetColumnName = sourceColumnName;
                    } else {
                        targetColumnName = value.split("\\$")[1];
                        if (targetColumnName.contains("*")) {
                            continue;
                        } else {
                            targetColumnName = value.split("\\$")[1];
                        }
                    }
                } else {
                    targetColumnName = value.split("\\$")[2];
                }
                if (targetColumnName.contains("*")) {
                    targetColumnName = value.split("\\$")[0].split("\\$")[2];
                }
                updateValue = rowupdate(speclist, sourceTableName, targetTableName, sourceColumnName, targetTableName, targetColumnName, businessRule);
                if (sourceTableName.equalsIgnoreCase(targetTableName) && sourceColumnName.equalsIgnoreCase(targetColumnName)) {
                    targetTableName = "RESULT_OF_SELECT-QUERY";

                }
                if (sourceTableName.equalsIgnoreCase(targetTableName) && !sourceColumnName.equalsIgnoreCase(targetColumnName)) {
                    targetTableName = "RESULT_OF_SELECT-QUERY";

                }
                if (!updateValue) {
                    MappingSpecificationRow row1 = new MappingSpecificationRow();
                    if ("".equals(sourceColumnName)) {
                        row1.setTargetSystemName(targetSystemNamegl);
                        row1.setTargetSystemEnvironmentName(targetEnvironmentNamegl);
                        row1.setTargetTableName(targetTableName);
                        row1.setTargetColumnName(targetColumnName);
                        row1.setBusinessRule(businessRule);
                        speclist.add(row1);
                    } else {
                        row1.setSourceSystemEnvironmentName(sourceEnvironmentNamegl);
                        row1.setTargetSystemEnvironmentName(targetEnvironmentNamegl);
                        row1.setSourceSystemName(sourceSystemNamegl);
                        row1.setTargetSystemName(targetSystemNamegl);
                        row1.setSourceTableName(sourceTableName);

                        row1.setSourceColumnName(sourceColumnName);
                        row1.setTargetTableName(targetTableName);
                        row1.setTargetColumnName(targetColumnName);
                        row1.setBusinessRule(businessRule);
                        speclist.add(row1);
                    }
                }
            }
        }
    }

    public static boolean rowupdate(ArrayList<MappingSpecificationRow> speclist, String sourceTableName, String TargetTableName, String sourcecolumnName, String targetTableName, String targetColumnName, String businessrule) {
        Iterator<MappingSpecificationRow> iter = speclist.iterator();
        while (iter.hasNext()) {
            MappingSpecificationRow row = iter.next();

            if (row.getSourceTableName().equalsIgnoreCase(sourceTableName) && row.getSourceColumnName().equalsIgnoreCase(sourcecolumnName) && row.getTargetTableName().equalsIgnoreCase(TargetTableName) && row.getTargetColumnName().equalsIgnoreCase(targetColumnName)) {
                row.setBusinessRule(businessrule);
                return true;
            }

        }
        return false;
    }

    public static void getlineageforDelete(ArrayList<MappingSpecificationRow> speclist, String targettableName, String sqlfilecontent, String dbvender) {
        String targetcolumns = getcolumnsFromDeletestatement(sqlfilecontent, dbvender);
        String[] targetcolumnarr = targetcolumns.split(",");
        String selectQuery = "";
        String deleteSelect = "DELETE-SELECT";
        String selectDelete = "";
        String targetlineage = "";
        List<String> columns = new LinkedList<>();
        Set<String> sourcesystem = new LinkedHashSet<>();
        Map<String, String> deleteLineage = new LinkedHashMap<>();
        Iterator<MappingSpecificationRow> iter = speclist.iterator();
        while (iter.hasNext()) {
            MappingSpecificationRow row = iter.next();
            if (!unionDelete) {
                if (row.getTargetTableName().equalsIgnoreCase("RESULT_OF_SELECT-QUERY") || row.getTargetTableName().equalsIgnoreCase("RESULT_OF_SELECT-QUERY-1")) {
                    String tableName = row.getTargetTableName();
                    String columnName = row.getTargetColumnName();
                    if (getcolumns(targetcolumnarr, columnName)) {
                        if ("".equals(selectQuery)) {
                            selectQuery = tableName + "#" + columnName;
                            selectDelete = deleteSelect + "#" + columnName;
                            targetlineage = targettableName + "#" + columnName;
                        } else {
                            selectQuery = selectQuery + "$" + tableName + "#" + columnName;
                            selectDelete = selectDelete + "$" + deleteSelect + "#" + columnName;
                            targetlineage = targetlineage + "$" + targettableName + "#" + columnName;
                        }
                    }
                }
            } else if (row.getTargetTableName().equalsIgnoreCase("RESULT_OF_UNION")) {

                String tableName = row.getTargetTableName();
                String columnName = row.getTargetColumnName();

                if ("".equals(selectQuery)) {
                    selectQuery = tableName + "#" + columnName;
                    selectDelete = deleteSelect + "#" + columnName;
                    targetlineage = targettableName + "#" + columnName;
                } else {
                    selectQuery = selectQuery + "$" + tableName + "#" + columnName;
                    selectDelete = selectDelete + "$" + deleteSelect + "#" + columnName;
                    targetlineage = targetlineage + "$" + targettableName + "#" + columnName;

                }

            }

        }

        deleteLineage.put(selectQuery, targetlineage);

        deleteLineage.put(selectQuery, selectDelete);
        deleteLineage.put(selectDelete, targetlineage);

        addUpdatemapspecrow(deleteLineage);
    }

    public static EDbVendor getEDbVendorType(String dbVender) {
        EDbVendor dbVendor = EDbVendor.dbvpostgresql;

        if (dbVender != null) {
            if (dbVender.equalsIgnoreCase("mssql")) {
                dbVendor = EDbVendor.dbvmssql;
            } else if (dbVender.equalsIgnoreCase("sybase")) {
                dbVendor = EDbVendor.dbvsybase;
            } else if (dbVender.equalsIgnoreCase("mysql")) {
                dbVendor = EDbVendor.dbvmysql;
            } else if (dbVender.equalsIgnoreCase("postgresql")) {
                dbVendor = EDbVendor.dbvpostgresql;
            } else if (dbVender.equalsIgnoreCase("oracle")) {
                dbVendor = EDbVendor.dbvoracle;
            } else if (dbVender.equalsIgnoreCase("db2")) {
                dbVendor = EDbVendor.dbvdb2;
            } else if (dbVender.equalsIgnoreCase("teradata")) {
                dbVendor = EDbVendor.dbvteradata;
            }
        }
        return dbVendor;
    }

    public static Set<String> getJoinStatementsfromList(Map<String, String> parentchildmap, String dbvender) {
        Set<String> jointypes = new LinkedHashSet<>();
        List<TCustomSqlStatement> statementList = getJoinStatementsfromMap(parentchildmap, dbvender);

        for (TCustomSqlStatement stmt : statementList) {
            if (stmt == null) {
                continue;
            }
            for (int join_cond = 0; join_cond < stmt.getJoins().size(); join_cond++) {
                if (stmt.getJoins().size() == 0) {
                    continue;
                }
                TJoin joincond = stmt.getJoins().getJoin(join_cond);
                for (int j_cond = 0; j_cond < joincond.getJoinItems().size(); j_cond++) {
                    TJoinItem joinitem = joincond.getJoinItems().getJoinItem(j_cond);
                 if(StringUtils.isNotBlank(joinitem.toString()))
                 {
                    joinconditions.add(joinitem.toString());
                    EJoinType jointype = joinitem.getJoinType();
                    //  System.out.println("jointypes----" + jointype+"join cond"+joinitem.toString());
                    if (joinitem.toString().length() > 490) {
                        jointypes.add(jointype + "#" + joinitem.toString().substring(0, 490));
                    } else {
                        jointypes.add(jointype + "#" + joinitem.toString());
                    }
                 }
                }
            }
            if (stmt.getWhereClause() != null) {
                String wherecondition = stmt.getWhereClause().toString();
                whereCondition.add(wherecondition);
            }
            if (stmt.getAncestorStmt().getWhereClause() != null) {
                String wherecondition = stmt.getAncestorStmt().getWhereClause().toString();
                whereCondition.add(wherecondition);
            }
        }
        return jointypes;
    }

    public static Set<String> getJoinStatementsfromList(String sqlstatement, String dbvender) {
        Set<String> jointypes = new LinkedHashSet<>();
        try {

            TCustomSqlStatement stmt = (TCustomSqlStatement) getselectstatementfromquery(sqlstatement, dbvender);

            if (stmt != null) {
                for (int join_cond = 0; join_cond < stmt.getJoins().size(); join_cond++) {
                    if (stmt.getJoins().size() == 0) {
                        continue;
                    }
                    TJoin joincond = stmt.getJoins().getJoin(join_cond);
                    for (int j_cond = 0; j_cond < joincond.getJoinItems().size(); j_cond++) {
                        TJoinItem joinitem = joincond.getJoinItems().getJoinItem(j_cond);
                        joinconditions.add(joinitem.toString());
                        EJoinType jointype = joinitem.getJoinType();
                        //  System.out.println("jointypes----" + jointype+"join cond"+joinitem.toString());
                        if (joinitem.toString().length() > 490) {
                            jointypes.add(jointype + "#" + joinitem.toString().substring(0, 490));
                        } else {
                            jointypes.add(jointype + "#" + joinitem.toString());
                        }
                    }
                }
                if (stmt.getWhereClause() != null) {
                    String wherecondition = stmt.getWhereClause().toString();

                    whereCondition.add(wherecondition);
                }

                if (stmt instanceof TTeradataLock) {
                    TCustomSqlStatement stmt2 = stmt.getAncestorStmt();
                    String wherecondition = stmt2.getWhereClause().toString();
                }

                if (stmt.getAncestorStmt().getWhereClause() != null) {
                    String wherecondition = stmt.getAncestorStmt().getWhereClause().toString();
                    whereCondition.add(wherecondition);
                }
            }
            return jointypes;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return jointypes;
    }

    public static List<TCustomSqlStatement> getJoinStatementsfromMap(Map<String, String> parentchildmap, String dbvender) {
        List<TCustomSqlStatement> joinstatementsquery = new LinkedList<>();
        for (Entry<String, String> entry : parentchildmap.entrySet()) {
            String key = entry.getKey();
            String value = entry.getValue();
            if (key.trim().startsWith("(") && key.trim().endsWith(")")) {
                key = key.substring(1, key.length() - 1);
            }
            if (value.startsWith("(")) {
                value = value.substring(1, value.length() - 1);

            }

            TCustomSqlStatement keystatement = getselectstatementfromquery(key, dbvender);
            TCustomSqlStatement valuestatement = getselectstatementfromquery(value, dbvender);
            joinstatementsquery.add(keystatement);
            joinstatementsquery.add(valuestatement);

        }
        return joinstatementsquery;
    }

    public static TCustomSqlStatement getselectstatementfromquery(String sqlquery, String dbvender) {

        dbVendor = getEDbVendorType(dbvender);
        TCustomSqlStatement stmt2 = null;
        sqlparser = new TGSqlParser(dbVendor);
        sqlparser.sqltext = sqlquery;
        int ret = sqlparser.parse();
        if (ret == 0) {
            stmt2 = sqlparser.sqlstatements.get(0);
        }

        return stmt2;
    }

    public static void createkeyvalueMap(Set<String> keysmap) {
        try {
            List<String> extendedproperties = new LinkedList<>(keysmap);
            int i = 1;
            String value = "";
            for (String val : extendedproperties) {
                String key = val.split("#")[0];
                String value1[] = val.split("#");
                if (value1.length > 2) {
                    value = value1[2];
                } else {
                    value = value1[1];
                }

                if (key.contains("WHERE_CONDITION")) {
                    keyvaluepair.put(key, value);
                } else if (keyvaluepair.get(key + " Join") == null) {
                    keyvaluepair.put(key + " Join", value);
                } else {
                    keyvaluepair.put(key + i + " Join", value);
                    i++;
                }
            }
            List<String> extendedpropertieswherecondition = new LinkedList<>(whereCondition);

            int j = 0;
            int k = 0;
            int h = 0;
            for (String whereclause : extendedpropertieswherecondition) {
                if (whereclause.contains("group_by")) {

                    keyvaluepair.put(whereclause.split("#")[0] + k, whereclause.split("#")[1]);
                    k++;
                } else if (whereclause.contains("order_by")) {
                    keyvaluepair.put(whereclause.split("#")[0] + h, whereclause.split("#")[1]);
                    h++;
                } else {
                    keyvaluepair.put("WHERE_CONDITION_" + j, whereclause);
                    j++;
                }

            }
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    public static String getcolumnsFromDeletestatement(String sql, String dbvender) {
        String columns = "";
        dbVendor = getEDbVendorType(dbvender);
        TCustomSqlStatement stmt2 = null;
        sqlparser = new TGSqlParser(dbVendor);
        sqlparser.sqltext = sql;
        int ret = sqlparser.parse();
        if (ret == 0) {
            TCustomSqlStatement stmnt = sqlparser.sqlstatements.get(0);
            TWhereClause listcolumns = stmnt.getWhereClause();
            TExpression expr = listcolumns.getCondition();
            columns = getcolumnsfromwhereClause(expr.toString());
//            System.out.println("columnsss" + columns);

        }

        return columns;
    }

    public static String getcolumnsfromwhereClause(String whereclause) {

        Matcher m = Pattern.compile("\\(([^)]+)\\)").matcher(whereclause);
        StringBuilder sb = new StringBuilder();
        int i = 0;
        while (m.find()) {
            if (i == 0) {
                sb.append(m.group(1));
            }
            i++;
        }

        return sb.toString();
    }

    public static boolean getcolumns(String[] columnarr, String columnName) {
        boolean flag = false;
        for (String trgtcolumn : columnarr) {
            if (trgtcolumn.toLowerCase().trim().equals(columnName.toLowerCase())) {
                flag = true;

            }

        }
        return flag;
    }

    public static Map<String, List<String>> getresultquerymap(String query, String dbVender) {
        Map<String, List<String>> resultsetcolumns = new LinkedHashMap<>();
        try {
            Dlineage resultset = getDataflowObject(query, dbVender);
            for (Object s : resultset.getColumnOrTableOrResultset()) {

                if (s instanceof Dlineage.Resultset) {

                    String rsultsetTableName = ((Dlineage.Resultset) s).getName();
                    if (rsultsetTableName.contains("RESULT_OF_SELECT-QUERY")) {
                        List<Column> resultcolumnList = ((Dlineage.Resultset) s).getColumn();
                        List<String> resultcolumnsNameList = new LinkedList();
                        for (Column column : resultcolumnList) {
                            resultcolumnsNameList.add(column.getName());
                        }
                        resultsetcolumns.put(rsultsetTableName, resultcolumnsNameList);
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return resultsetcolumns;
    }

    public static String getresultselecttable(Map<String, List<String>> resultsetMap, String columnName) {

        String tabvalue = "";
        for (Entry<String, List<String>> entry : resultsetMap.entrySet()) {
            String key = entry.getKey();
            List<String> value = entry.getValue();
            if (getcolumnsfromlist(value, columnName)) {
                if ("".equals(tabvalue)) {
                    tabvalue = key;
                } else {

                    tabvalue = tabvalue + "#" + key;
                }

            }
        }
        return tabvalue;
    }

    public static boolean getcolumnsfromlist(List<String> columnarr, String columnName) {
        boolean flag = false;
        for (String trgtcolumn : columnarr) {
            if (trgtcolumn.toLowerCase().trim().equals(columnName.toLowerCase())) {
                flag = true;

            }

        }
        return flag;
    }

    public static void updatebusinessRuleforUnionn(Map<String, String> expressionMap, ArrayList<MappingSpecificationRow> speclist, Map<String, List<String>> resultqueryMap) {
        for (Map.Entry<String, String> entry : expressionMap.entrySet()) {
            String key = entry.getKey();
            String value = entry.getValue();
            String sourceTableName = key.split("#")[0].split("\\$")[0];
            String sourceColumnName = "";
            boolean updateValue = false;

            if (key.split("#")[0].split("\\$").length <= 1) {
                sourceColumnName = "";
            } else {
                sourceColumnName = key.split("#")[0].split("\\$")[1];
            }

            String businessRule = key.split("#")[1];
            if (businessRule.contains("%")) {
                businessRule = businessRule.replaceAll("%", "");
            }
            if (value.contains("##")) {

                Set<String> setOfColumns = new LinkedHashSet<>(Arrays.asList(value.split("##")));
                List<String> listofColumns = new LinkedList(setOfColumns);
                for (String val : listofColumns) {
                    String targetTableName = val.split("\\$")[0];
                    String targetcolumnName = val.split("\\$")[1];
                    if (targetcolumnName.contains("*")) {
                        targetcolumnName = val.split("\\$")[2];
                    }
                    if (sourceTableName.equalsIgnoreCase(targetTableName) && sourceColumnName.equalsIgnoreCase(targetcolumnName)) {
                        String tablename = getresultselecttable(resultqueryMap, targetcolumnName);
                        String[] resultquery = tablename.split("#");
                        for (String tables : resultquery) {
                            targetTableName = tables;
                            addmapspec(sourceTableName, sourceColumnName, targetcolumnName, targetTableName, businessRule, speclist);

                        }

                    } else if (sourceTableName.equalsIgnoreCase(targetTableName) && !sourceColumnName.equalsIgnoreCase(targetcolumnName)) {
                        String tablename = getresultselecttable(resultqueryMap, targetcolumnName);
                        String[] resultquery = tablename.split("#");
                        for (String tables : resultquery) {
                            targetTableName = tables;
                            addmapspec(sourceTableName, sourceColumnName, targetcolumnName, targetTableName, businessRule, speclist);

                        }

                    } else {
                        addmapspec(sourceTableName, sourceColumnName, targetcolumnName, targetTableName, businessRule, speclist);

                    }

                }
            } else {
                String targetTableName = value.split("\\$")[0];
                String targetcolumnName = "";
                if (value.split("\\$").length <= 2) {
                    if (value.split("\\$").length == 1) {
                        targetcolumnName = sourceColumnName;
                    } else {
                        targetcolumnName = value.split("\\$")[1];
                        if (targetcolumnName.contains("*")) {
                            continue;
                        } else {
                            targetcolumnName = value.split("\\$")[1];
                        }
                    }
                } else {
                    targetcolumnName = value.split("\\$")[2];
                    if (targetcolumnName.contains("*")) {
                        targetcolumnName = value.split("\\$")[0].split("\\$")[2];
                    }
                }

                if (sourceTableName.equalsIgnoreCase(targetTableName) && sourceColumnName.equalsIgnoreCase(targetcolumnName)) {
                    String tablename = getresultselecttable(resultqueryMap, targetcolumnName);
                    String[] resultquery = tablename.split("#");
                    for (String tables : resultquery) {
                        targetTableName = tables;
                        addmapspec(sourceTableName, sourceColumnName, targetcolumnName, targetTableName, businessRule, speclist);

                    }
                } else if (sourceTableName.equalsIgnoreCase(targetTableName) && !sourceColumnName.equalsIgnoreCase(targetcolumnName)) {
                    String tablename = getresultselecttable(resultqueryMap, targetcolumnName);
                    String[] resultquery = tablename.split("#");
                    for (String tables : resultquery) {
                        targetTableName = tables;
                        addmapspec(sourceTableName, sourceColumnName, targetcolumnName, targetTableName, businessRule, speclist);
                    }

                } else {
                    addmapspec(sourceTableName, sourceColumnName, targetcolumnName, targetTableName, businessRule, speclist);

                }
            }

        }
    }

    public static void addmapspec(String sourcetablename, String sourcecolumnName, String targetcolumnName, String targettableName, String Businessrule, ArrayList<MappingSpecificationRow> speclist) {
        MappingSpecificationRow row1 = new MappingSpecificationRow();

        row1.setSourceSystemEnvironmentName(sourceEnvironmentNamegl);
        row1.setTargetSystemEnvironmentName(targetEnvironmentNamegl);
        row1.setSourceSystemName(sourceSystemNamegl);
        row1.setTargetSystemName(targetSystemNamegl);
        row1.setSourceTableName(sourcetablename);

        row1.setSourceColumnName(sourcecolumnName);
        row1.setTargetTableName(targettableName);
        row1.setTargetColumnName(targetcolumnName);
        row1.setBusinessRule(Businessrule);
        speclist.add(row1);

    }

    public static void getBrFromParentChildMap(Map<String, String> prentChild) {
        dbVendor = getEDbVendorType("teradata");
        for (Entry<String, String> entry : prentChild.entrySet()) {
            String key = entry.getKey();
            String value = entry.getValue();
            if (key.startsWith("(") && key.endsWith(")")) {
                key = key.substring(1, key.length() - 1);

            }
            if (value.startsWith("(") && value.endsWith(")")) {
                value = value.substring(1, value.length() - 1);

            }
            getBrfromSelectquery(key);
            getBrfromSelectquery(value);

        }

    }

    public static void getBrfromSelectquery(String selectsqlquery) {

        sqlparser = new TGSqlParser(dbVendor);
        sqlparser.sqltext = selectsqlquery;
        int ret = sqlparser.parse();
        if (ret == 0) {
            TCustomSqlStatement stmnt = sqlparser.sqlstatements.get(0);
            TResultColumnList rsltstatement = stmnt.getResultColumnList();
            if (rsltstatement == null) {
                return;
            }
            for (int j = 0; j < rsltstatement.size(); j++) {
                TResultColumn column = rsltstatement.getResultColumn(j);
                String Expr = column.getExpr().toString();
                //System.out.println("----" + Expr);
                String columnName = column.getColumnNameOnly();
                String columnwithAliasName = "";
                columnwithAliasName = getBrfromselectquery(Expr);
//                if ("".equals(columnwithAliasName)) {
//                    columnwithAliasName = getBrfromselectquerynew(Expr);
//                }
                String aliasName = column.getColumnAlias();
                EExpressionType type = column.getExpr().getExpressionType();
                if (type == type.simple_object_name_t) {
                    continue;
                }
                if (!columnwithAliasName.contains(".")) {
//                    columnwithAliasName = column.getColumnAlias();
                    TTableList list = stmnt.getTables();
                    for (int i = 0; i < list.size(); i++) {
                        TTable table = list.getTable(i);
                        String tablename = table.getFullName();
                        String tableAliasName = table.getAliasName();
                        tableAliasName = tableAliasName.replace("1", "");
                        if ("".equals(tableAliasName)) {
                            tableAliasName = tablename;
                        }
                        if (!columnwithAliasName.contains(".")) {
                            columnwithAliasName = tableAliasName + "." + columnwithAliasName;
                        }
                    }
                }

                ExpressionTarget.put(columnwithAliasName + "#" + aliasName, Expr);
                //System.out.println("brrr" + Expr);

                //System.out.println("aliasss" + aliasName);
                //System.out.println("columns" + getColumnNameFromBr(Expr));
            }
        }
        int i = 0;
    }

    public static Map<String, String> getBrfromOnlySelectquery(String selectsqlquery, Map<String, String> tableAliasMap) {
        Map<String, String> aliasWithBr = new LinkedHashMap();
        sqlparser = new TGSqlParser(dbVendor);
        sqlparser.sqltext = selectsqlquery;
        int ret = sqlparser.parse();
        if (ret == 0) {
            TCustomSqlStatement stmnt = sqlparser.sqlstatements.get(0);
            TResultColumnList rsltstatement = stmnt.getResultColumnList();
            if (rsltstatement == null) {
                return aliasWithBr;
            }
            for (int j = 0; j < rsltstatement.size(); j++) {
                TResultColumn column = rsltstatement.getResultColumn(j);
                String Expr = column.getExpr().toString();
                if (Expr.equals("NULL")) {
                    continue;
                }

                //System.out.println("----" + Expr);
                for (int join_cond = 0; join_cond < stmnt.getJoins().size(); join_cond++) {
                    TJoin joincond = stmnt.getJoins().getJoin(join_cond);
                    for (int j_cond = 0; j_cond < joincond.getJoinItems().size(); j_cond++) {
                        TJoinItem joinitem = joincond.getJoinItems().getJoinItem(j_cond);
//                            joinconditions.add(joinitem.toString());
                        EJoinType jointype = joinitem.getJoinType();
//                            System.out.println("jointypes----" + jointype);
                        joinconditions.add(jointype + "#" + joinitem.toString());
                    }

                }
                if (stmnt.getWhereClause() != null) {
                    String wherecondition = stmnt.getWhereClause().toString();

                    whereCondition.add(wherecondition);
                }

                String columnwithAliasName = getBrfromselectquery(Expr, tableAliasMap);
                columnwithAliasName = columnwithAliasName.replace("(", "");
                if ("".equals(columnwithAliasName)) {
                    columnwithAliasName = column.getColumnAlias();
                    TTableList list = stmnt.getTables();
                    for (int i = 0; i < list.size(); i++) {
                        TTable table = list.getTable(i);
                        String tablename = table.getFullName();
                        String tableAliasName = table.getAliasName();
                        if ("".equals(tableAliasName)) {
                            tableAliasName = tablename;
                        }
                        columnwithAliasName = tableAliasName + "." + columnwithAliasName;
                    }
                }
                //System.out.println("expressionnn" + Expr + "columnwithAliasName" + columnwithAliasName);
//                String columnAliasName = column.getColumnAlias();
                EExpressionType type = column.getExpr().getExpressionType();
                if (type == type.simple_object_name_t) {
                    continue;
                }
                if (aliasWithBr.get(columnwithAliasName) == null) {
                    if (Expr != null) {
                        aliasWithBr.put(columnwithAliasName, Expr);
                    }
                } else {
                    String value = aliasWithBr.get(columnwithAliasName);
                    if (value != null) {
                        aliasWithBr.put(columnwithAliasName, value + "~~" + Expr);
                    }
                }
//
//                System.out.println("brrr" + Expr);
//
//                System.out.println("aliasss" + columnAliasName);
//                System.out.println("columns" + getColumnNameFromBr(Expr));
            }

        }
        int i = 0;
        return aliasWithBr;
    }

    public static String getBrfromselectquery(String businessRule, Map<String, String> tableAliasMap) {
        businessRule = businessRule.toUpperCase();
        Matcher m = Pattern.compile("\\(([^)]+)\\)").matcher(businessRule);
        String aliaswithcolumnName = "";
        StringBuilder sb = new StringBuilder();
        int i = 0;
        while (m.find()) {
            if (i == 0) {
                if (m.group(1).toUpperCase().contains("CASE")) {
                    if (m.group(1).contains("=")) {
                        aliaswithcolumnName = m.group(1).split("=")[0].trim().substring(m.group(1).split("=")[0].trim().lastIndexOf(" "));
                        //System.out.println("0000" + aliaswithcolumnName);
                    }
                    if ("".equals(aliaswithcolumnName.trim())) {
                        List<String> keySet = new LinkedList(tableAliasMap.keySet());
                        for (String tblAlias : keySet) {
                            tblAlias = tblAlias.toUpperCase();
                            if (businessRule != null && businessRule.contains(tblAlias + ".")) {
                                aliaswithcolumnName = businessRule.substring(businessRule.indexOf(tblAlias + "."));
                                if (aliaswithcolumnName.contains(" ")) {
                                    aliaswithcolumnName = aliaswithcolumnName.split(" ")[0];
                                }
                            }
                        }

                    }

                }
            }

        }
        return aliaswithcolumnName;
    }

    public static String getBrfromselectquery(String businessRule) {
        Matcher m = Pattern.compile("\\(([^)]+)\\)").matcher(businessRule);
        String aliaswithcolumnName = "";
        String secondColumn = "";
        StringBuilder sb = new StringBuilder();
        int i = 0;
        String temp = "";
        while (m.find()) {
            if (i == 0) {
                if (m.group(1).toUpperCase().contains("CASE")) {
                    if (m.group(1).contains("=") && m.group(1).contains("THEN") && !m.group(1).contains("IN") && !m.group(1).contains("AND")) {
                        aliaswithcolumnName = m.group(1).split("=")[0].trim().substring(m.group(1).split("=")[0].trim().lastIndexOf(" "));
                        if (businessRule.contains("ELSE")) {
                            secondColumn = businessRule.substring(businessRule.indexOf("THEN") + 4, businessRule.indexOf("ELSE")).trim();
                        }

                        aliaswithcolumnName = aliaswithcolumnName + "\n" + secondColumn;
                        //System.out.println("0000" + aliaswithcolumnName);
                    }
                    if (m.group(1).contains("=") && m.group(1).contains("THEN") && !m.group(1).contains("AND")) {
                        aliaswithcolumnName = m.group(1).split("=")[0].trim().substring(m.group(1).split("=")[0].trim().lastIndexOf(" "));
                        if (businessRule.contains("ELSE")) {
                            secondColumn = m.group(1).substring(m.group(1).indexOf("THEN") + 4, m.group(1).indexOf("ELSE")).trim();
                        }
                        aliaswithcolumnName = aliaswithcolumnName + "\n" + secondColumn;
                        //System.out.println("0000" + aliaswithcolumnName);
                    }
//                    if (m.group(1).contains("=") && m.group(1).contains("THEN")&&m.group(1).contains("AND")) {
//                        aliaswithcolumnName = m.group(1).split("=")[0].trim().substring(m.group(1).split("=")[0].trim().lastIndexOf(" "));
//                           if(businessRule.contains("ELSE")){
//                         secondColumn = m.group(1).substring(m.group(1).indexOf("THEN") + 4, m.group(1).indexOf("ELSE")).trim();
//                        }
//                        aliaswithcolumnName = aliaswithcolumnName + "\n" + secondColumn;
//                        //System.out.println("0000" + aliaswithcolumnName);
//                    }

                } else {
                    aliaswithcolumnName = m.group(1);
                }
            }
            if (aliaswithcolumnName.contains(",")) {
                aliaswithcolumnName = aliaswithcolumnName.split(",")[0];
            }
            aliaswithcolumnName = aliaswithcolumnName.replace("NVL(", "");
            temp = temp + aliaswithcolumnName + "\n";
        }
        if (aliaswithcolumnName.contains("from")) {
            aliaswithcolumnName = aliaswithcolumnName.split("from")[1];
        }

        return temp.trim();
    }

    public static String getBrfromselectquerynew(String businessRule) {
        Matcher m = Pattern.compile("\\(([^)]+)\\)").matcher(businessRule);
        String aliaswithcolumnName = "";
        StringBuilder sb = new StringBuilder();
        int i = 0;
        while (m.find()) {
            if (i == 0) {
                if (m.group(1).toUpperCase().contains("CASE")) {
                    if (m.group(1).contains("=")) {
                        aliaswithcolumnName = m.group(1).split("=")[0].trim().substring(m.group(1).split("=")[0].trim().lastIndexOf(" "));
                        // System.out.println("0000" + aliaswithcolumnName);
                    }

                }
            }

        }
        return aliaswithcolumnName;
    }

    public static String getTargetTableNamefrommapspec(String tablename) {
        String targettableName = "";
        try {
            sourceTargetMap.values().removeIf(Objects::isNull);
            targettableName = sourceTargetMap.get(tablename);

            if (targettableName == null) {
                if (sourceTargetMap.get(tablename.toUpperCase()) != null) {
                    targettableName = sourceTargetMap.get(tablename.toUpperCase());
                }

            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        return targettableName;
    }

    public static void addmapspecforBRforNab(Map<String, String> expressiontarget) {
        String sourcetab = " ";
        String columnNames = "";
        for (Entry<String, String> entry : expressiontarget.entrySet()) {
            MappingSpecificationRow row = new MappingSpecificationRow();
            String key = entry.getKey();
            String value = entry.getValue();
//            if (key.equals("#")) {
//                continue;
//            }
            if (key.split("#")[0] == null || "".equals(key.split("#")[0])) {
                continue;
            }
            if (key.contains(".")) {
                sourcetab = "RESULT_OF_" + key.split("#")[0].split("\\.")[0].trim();
            } else {
                sourcetab = "RESULT_OF_";
            }
//            sourcetab = key.split("#")[0].split("\\.")[0].trim();
            //System.out.println("Tab------------" + sourcetab);
            String targetTableName = getTargetTableNamefrommapspec(sourcetab);
            //System.out.println("tttttt" + targetTableName);
            if (targetTableName == null) {
                continue;
            }
            row.setSourceSystemEnvironmentName(sourceEnvironmentNamegl);
            row.setTargetSystemEnvironmentName(targetEnvironmentNamegl);
            row.setSourceSystemName(sourceSystemNamegl);
            row.setTargetSystemName(targetSystemNamegl);
            row.setSourceTableName(sourcetab);
            if (key.contains("#") && key.contains(".")) {
                if (key.split("#")[0].contains("\n")) {
                    String temp = "";
                    String[] columnsarr = key.split("#")[0].split("\n");
                    for (String carr : columnsarr) {
                        if (carr.contains(".")) {
                            temp = temp + "\n" + carr.split("\\.")[1];
                        } else {
                            temp = temp + "\n" + carr;
                        }

                    }
                    row.setSourceColumnName(temp);
                }

                if (key.split("#").length == 2) {
                    row.setTargetColumnName(key.split("#")[1]);
                }
            }

            row.setTargetTableName(targetTableName);
            row.setBusinessRule(value);
            mapspeclist.add(row);
        }
    }

    public static void addmapspecforBRforNabselectquery(Map<String, String> expressiontarget, Map<String, String> tableAlias) {
        String sourcetab = " ";
        String columnNames = "";
        for (Entry<String, String> entry : expressiontarget.entrySet()) {
            MappingSpecificationRow row = new MappingSpecificationRow();
            String key = entry.getKey();
            String value = entry.getValue();
//            if (key.equals("#")) {
//                continue;
//            }
            if (key == null) {
                continue;
            }
            if (key.split("#")[0] == null || "".equals(key.split("#")[0])) {
                continue;
            }
            if (key.contains(".")) {
                sourcetab = tableAlias.get(key.split("#")[0].split("\\.")[0].trim());
                if (sourcetab == null) {
                    continue;
                }
            } else {
                sourcetab = "RESULT_OF_";
            }
//            sourcetab = key.split("#")[0].split("\\.")[0].trim();
            //System.out.println("Tab------------" + sourcetab);
            String targetTableName = getTargetTableNamefrommapspec(sourcetab);
            //System.out.println("tttttt" + targetTableName);
            if (targetTableName == null) {
                targetTableName = "RESULT_OF_SELECT-QUERY";
            }
            row.setSourceSystemEnvironmentName(sourceEnvironmentNamegl);
            row.setTargetSystemEnvironmentName(targetEnvironmentNamegl);
            row.setSourceSystemName(sourceSystemNamegl);
            row.setTargetSystemName(targetSystemNamegl);
            row.setSourceTableName(sourcetab);
            if (key.contains("#") && key.contains(".")) {
                if (key.split("#")[0].contains("\n")) {
                    String temp = "";
                    String[] columnsarr = key.split("#")[0].split("\n");
                    for (String carr : columnsarr) {
                        if (carr.contains(".")) {
                            temp = temp + "\n" + carr.split("\\.")[1];
                        } else {
                            temp = temp + "\n" + carr;
                        }

                    }
                    row.setSourceColumnName(temp);
                }

                if (key.split("#").length == 2) {
                    row.setTargetColumnName(key.split("#")[1]);
                }
            }

            row.setTargetTableName(targetTableName);
            row.setBusinessRule(value);
            mapspeclist.add(row);
        }
    }

    public static void getcolumnsfromBr(Map<String, List<String>> tablecolumnListFromXml, String expr, String columnName, String columnAliasName) {

        for (Entry<String, List<String>> entry : tablecolumnListFromXml.entrySet()) {
            String key = entry.getKey();
            List<String> value = entry.getValue();
            Set<String> valueset = new LinkedHashSet<>(value);
            List<String> values = new LinkedList<>(valueset);
            if (values.contains(columnName)) {

            }

        }

    }

    private static void updateBrForOnlySelectQuery(Map<String, String> tableAlias, Map<String, String> aliasWithBr) {

        for (Entry<String, String> entry : aliasWithBr.entrySet()) {
            MappingSpecificationRow row = new MappingSpecificationRow();
            String columnAndTabAlias = entry.getKey();
            String expression = entry.getValue();

            if (expression.contains("~~")) {
                String[] expArr = expression.split("~~");
                for (String exp : expArr) {
                    row = new MappingSpecificationRow();
                    if (columnAndTabAlias.contains(".")) {
                        String tableAliasName = columnAndTabAlias.split("\\.")[0].trim();
                        String sourceTableName = tableAlias.get(tableAliasName);
                        String sourceColumnName = columnAndTabAlias.split("\\.")[1];
                        row.setSourceTableName(sourceTableName);
                        row.setSourceColumnName(sourceColumnName);
                    }
                    row.setSourceSystemEnvironmentName(sourceEnvironmentNamegl);
                    row.setTargetSystemEnvironmentName(targetEnvironmentNamegl);
                    row.setSourceSystemName(sourceSystemNamegl);
                    row.setTargetSystemName(targetSystemNamegl);
                    row.setTargetTableName("");
                    row.setTargetColumnName("");
                    row.setBusinessRule(exp);
                    mapspeclist.add(row);
                }

            } else {
                if (columnAndTabAlias.contains(".")) {
                    String tableAliasName = columnAndTabAlias.split("\\.")[0].trim();
                    String sourceTableName = tableAlias.get(tableAliasName);
                    String sourceColumnName = columnAndTabAlias.split("\\.")[1];
                    row.setSourceTableName(sourceTableName);
                    row.setSourceColumnName(sourceColumnName);

                }
                row.setSourceSystemEnvironmentName(sourceEnvironmentNamegl);
                row.setTargetSystemEnvironmentName(targetEnvironmentNamegl);
                row.setSourceSystemName(sourceSystemNamegl);
                row.setTargetSystemName(targetSystemNamegl);
                row.setTargetTableName("");
                row.setTargetColumnName("");
                row.setBusinessRule(expression);
                mapspeclist.add(row);
            }
        }

    }

    private static void getMapfromSelectquery(List<String> querylist, String dbvender) {
        try {
            long starttime = System.currentTimeMillis();
            Map<List<Map<String, List<String>>>, String> brInfoMap = new LinkedHashMap<>();
            Set<String> uniquequery = new LinkedHashSet<>(querylist);
            List<String> uniquequerylist = new LinkedList(uniquequery);
            List<Map<String, List<String>>> tableMap = null;
            List< List<Map<String, List<String>>>> tablemaptest = null;

            tablemaptest = new LinkedList<>();
            for (String query : uniquequerylist) {
                try {
                    String parentquery = "";
                    if (XmlVisitorv1.childParentQuery.get(query) != null) {
                        parentquery = XmlVisitorv1.childParentQuery.get(query);
                        if (parentquery.startsWith("(") && parentquery.endsWith(")")) {
                            parentquery = query.substring(1, query.length() - 1);

                        }
                    }
                    List<String> tableList = null;
                    if (!"".equalsIgnoreCase(parentquery)) {
                        //System.out.println("----parentquery------" + parentquery);
                        Map<String, List<String>> Tablecolmap = tableColRel;
                        if (Tablecolmap != null) {
                            tableList = new LinkedList<>(Tablecolmap.keySet());
                        }

                    }
                    if (tableList == null) {
                        tableList = new LinkedList<>();
                    }
                    if (query.startsWith("(") && query.endsWith(")")) {
                        query = query.substring(1, query.length() - 1);
                    }
                    dbVendor = getEDbVendorType(dbvender);
                    sqlparser = new TGSqlParser(dbVendor);
                    sqlparser.sqltext = query;
                    int ret = sqlparser.parse();
                    if (ret == 0) {
                        TCustomSqlStatement stmnt = sqlparser.sqlstatements.get(0);
                        TResultColumnList rsltstatement = stmnt.getResultColumnList();
                        TCustomSqlStatement targetStatement = getselectstatement(parentquery, dbvender);
                        if (targetStatement instanceof TCreateTableSqlStatement) {
                            tableList = new LinkedList<>();
                            TCreateTableSqlStatement createtable = (TCreateTableSqlStatement) targetStatement;
                            TObjectName objName = createtable.getTableName();
                            String tableName = objName.toString();
                            tableList.add(tableName);
                        }
                        if (targetStatement instanceof TInsertSqlStatement) {
                            tableList = new LinkedList<>();
                            TInsertSqlStatement createtable = (TInsertSqlStatement) targetStatement;
                            TObjectName objName = createtable.getTargetTable().getTableName();
                            String tableName = objName.toString();
                            tableList.add(tableName);
                        }
                        for (int j = 0; rsltstatement != null && j < rsltstatement.size(); j++) {
                            TResultColumn column = rsltstatement.getResultColumn(j);
                            TExpression expr = column.getExpr();
                            String columnaliasName = column.getColumnAlias();
                            String targetcolumnName = column.getColumnNameOnly();
                            EExpressionType type = expr.getExpressionType();
                            if (type == type.simple_object_name_t) {
                                continue;
                            }

                            String expression = column.getExpr().toString();
                            if (expression.contains("~")) {
                                expression = expression.replace("~", "tild");
                            }

                            tableMap = new LinkedList<>();
                            Map<String, List<String>> mapinfo = new LinkedHashMap(getbusinessrule(expr, stmnt));

                            if (mapinfo.size() != 0) {
                                tableMap = new LinkedList();
                                tableMap.add(mapinfo);

                            }

                            if (tableMap.size() == 0 && !"".equals(expr)) {
                                addmapspecificationorphantargetBr(columnaliasName, expression);
                                continue;
                            }
                            brInfoMap.put(tableMap, expression + "~" + columnaliasName);
                            if (querylist.size() == 1) {
                                addmappingspecificationforselectqueryBr(brInfoMap, tableAliasMap);
                            } else {
                                addmappingspecificationforBr(brInfoMap, tableList);
                            }

                            brInfoMap.clear();
                            // System.out.println("-----" + tableMap);
                        }

                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
            //  System.out.println("-----" + tablemaptest);

            long endtime = System.currentTimeMillis();
            long stat = endtime - starttime;
            long statsec = TimeUnit.MILLISECONDS.toSeconds(stat);
//      
        } catch (Exception e) {

            e.printStackTrace();
        }

    }

    private static void addmappingspecificationforBr(Map<List<Map<String, List<String>>>, String> sourcetargetInfo, List<String> tablelist) {
        String sourceTableName = "";
        String columnName = "";
        String targetColumnName = "";
        String businessRule = "";
        String targetTableName = "";
        int temptab = 0;
        Map<String, List<String>> temptablecolumn = new LinkedHashMap<>();
        MappingSpecificationRow row = new MappingSpecificationRow();
        String tableLevelTemp = "";
        for (Entry<List<Map<String, List<String>>>, String> entry : sourcetargetInfo.entrySet()) {

//            List<Map<String, List<String>>> key = entry.getKey();
            String value = entry.getValue();
            for (Map<String, List<String>> tablecolumn : entry.getKey()) {
                for (Entry<String, List<String>> entry1 : tablecolumn.entrySet()) {
                    if (!"".equals(entry1.getKey())) {
                        sourceTableName = entry1.getKey();//sourcetablename from tree
                    }

                    Set<String> columnValues = new HashSet<>(entry1.getValue());// list of columns from tree

                    if ("".equals(columnName)) {
                        columnName = StringUtils.join(columnValues, "\n");
                    } else {
                        columnName = columnName + "\n" + StringUtils.join(columnValues, "\n");
                    }
                    if (columnName.contains("(COLUMN IN DERIVED TABLE)")) {
                        columnName = columnName.replace("(COLUMN IN DERIVED TABLE)", "");
                    }
                    String tblAlias = sourceTableName;
                    sourceTableName = tableAliasMap.get(sourceTableName);

                    if (sourceTableName == null) {
                        //  sourceTableName = "RESULT_OF_" + tblAlias;
                        sourceTableName = tblAlias;
                    }
                    if (checktableNameforsource(mapspeclist, sourceTableName)) {

                        sourceTableName = "RESULT_OF_" + sourceTableName;
                    }

                    List<String> columnValue = new LinkedList<>(columnValues);
                    temptablecolumn.put(sourceTableName, columnValue);
                    targetTableName = getTargetTableNamefrommapspec(sourceTableName);
                    if (targetTableName == null) {
//                        targetTableName = "RESULT_OF_SELECT-QUERY";
                        targetTableName = "";

                    }

                    if (!"".equals(tableLevelTemp)) {
                        tableLevelTemp = tableLevelTemp + "\n" + sourceTableName;
                    } else {
                        tableLevelTemp = sourceTableName;
                    }
                    if (value.split("~").length > 1) {
                        targetColumnName = value.split("~")[1];
                    }

                    businessRule = value.split("~")[0];

                    targetTableName = getTargetTableNamefrommapspec(sourceTableName);
                    if (targetTableName == null) {
//                        targetTableName = "RESULT_OF_SELECT-QUERY";
                        targetTableName = "";
                    }
                    String tempsourcetab = "";
                    for (int i = 0; i < columnValues.size(); i++) {
                        if (i == 0) {
                            tempsourcetab = sourceTableName;
//                            tableLevelTemp = sourceTableName;                            
                        } else if (!"".equals(tableLevelTemp)) {
                            tableLevelTemp = tableLevelTemp + "\n" + tempsourcetab;
                        }
                    }

                }
                deleteduplicaterow(mapspeclist, temptablecolumn, targetTableName, targetColumnName);
            }
            row.setSourceSystemEnvironmentName(sourceEnvironmentNamegl);
            row.setTargetSystemEnvironmentName(targetEnvironmentNamegl);
            row.setSourceSystemName(sourceSystemNamegl);
            row.setTargetSystemName(targetSystemNamegl);
            String[] distincttable = tableLevelTemp.split("\n");
            //Set<String> distinctable = new LinkedHashSet<>(Arrays.asList(distincttable));
            tableLevelTemp = StringUtils.join(distincttable, "\n");
            if (tableLevelTemp.contains("$")) {
                tableLevelTemp.replaceAll("$", "");
            }
            row.setSourceTableName(tableLevelTemp.toUpperCase().replace("[", "").replace("]", ""));
            String[] distinctcolumn = columnName.split("\n");

            // Set<String> distinccolumnset = new LinkedHashSet<>(Arrays.asList(distinctcolumn));
            columnName = StringUtils.join(distinctcolumn, "\n");
            row.setSourceColumnName(columnName.toUpperCase().replace("[", "").replace("]", ""));
            if ("".equalsIgnoreCase(targetTableName) && !tablelist.isEmpty()) {
                targetTableName = tablelist.get(0);
            }
            row.setTargetTableName(targetTableName.toUpperCase().replace("[", "").replace("]", ""));
            row.setTargetColumnName(targetColumnName.toUpperCase().replace("[", "").replace("]", ""));
            if (businessRule.contains("tild")) {
                businessRule = businessRule.replace("tild", "~");
            }
            if (businessRule.contains("\'")) {
                businessRule = businessRule.replaceAll("\'", "\"");
            }
            row.setBusinessRule(businessRule);
            mapspeclist.add(row);

        }

    }

    private static void addmappingspecificationforselectqueryBr(Map<List<Map<String, List<String>>>, String> sourcetargetInfo, Map<String, String> tablealiasMap) {
        String sourceTableName = "";
        String columnName = "";
        String targetColumnName = "";
        String businessRule = "";
        String targetTableName = "";
        Map<String, List<String>> temptablecolumn = new LinkedHashMap<>();
        MappingSpecificationRow row = new MappingSpecificationRow();
        String tableLevelTemp = "";
        for (Entry<List<Map<String, List<String>>>, String> entry : sourcetargetInfo.entrySet()) {

//            List<Map<String, List<String>>> key = entry.getKey();
            String value = entry.getValue();
            for (Map<String, List<String>> tablecolumn : entry.getKey()) {
                for (Entry<String, List<String>> entry1 : tablecolumn.entrySet()) {

                    sourceTableName = entry1.getKey();//sourcetablename from tree

                    List<String> columnValues = entry1.getValue();// list of columns from tree

                    if ("".equals(columnName)) {
                        columnName = StringUtils.join(columnValues, "\n");
                    } else {
                        columnName = columnName + "\n" + StringUtils.join(columnValues, "\n");
                    }
                    if (tablealiasMap.get(sourceTableName) != null) {
                        sourceTableName = tablealiasMap.get(sourceTableName);
                    }

                    temptablecolumn.put(sourceTableName, columnValues);
                    if (!"".equals(tableLevelTemp)) {
                        tableLevelTemp = tableLevelTemp + "\n" + sourceTableName;
                    } else {
                        tableLevelTemp = sourceTableName;
                    }
                    if (value.split("~").length > 1) {
                        targetColumnName = value.split("~")[1];
                    }

                    businessRule = value.split("~")[0];
                    targetTableName = getTargetTableNamefrommapspec(sourceTableName);
                    if (targetTableName == null) {
//                        targetTableName = "RESULT_OF_SELECT-QUERY";
                        targetTableName = "";
                    }

                    String tempsourcetab = "";
                    for (int i = 0; i < columnValues.size(); i++) {
                        if (i == 0) {
                            tempsourcetab = sourceTableName;
//                            tableLevelTemp = sourceTableName;                            
                        } else if (!"".equals(tableLevelTemp)) {
                            tableLevelTemp = tableLevelTemp + "\n" + tempsourcetab;
                        }
                    }

                }
                deleteduplicaterow(mapspeclist, temptablecolumn, targetTableName, targetColumnName);
            }

            row.setSourceSystemEnvironmentName(sourceEnvironmentNamegl);
            row.setTargetSystemEnvironmentName(targetEnvironmentNamegl);
            row.setSourceSystemName(sourceSystemNamegl);
            row.setTargetSystemName(targetSystemNamegl);
            String[] distincttable = tableLevelTemp.split("\n");
            Set<String> distinctable = new LinkedHashSet<>(Arrays.asList(distincttable));
            tableLevelTemp = StringUtils.join(distinctable, "\n");
            if (tableLevelTemp.contains("$")) {
                tableLevelTemp.replaceAll("$", "");
            }
            row.setSourceTableName(tableLevelTemp.toUpperCase().replace("[", "").replace("]", ""));
            String[] distinctcolumn = columnName.split("\n");
            Set<String> distinccolumnset = new LinkedHashSet<>(Arrays.asList(distinctcolumn));
            columnName = StringUtils.join(distinccolumnset, "\n");
            row.setSourceColumnName(columnName.toUpperCase().replace("[", "").replace("]", ""));
            row.setTargetTableName(targetTableName.toUpperCase().replace("[", "").replace("]", ""));
            row.setTargetColumnName(targetColumnName.toUpperCase().replace("[", "").replace("]", ""));
            if (businessRule.contains("tild")) {
                businessRule = businessRule.replace("tild", "~");
            }
            if (businessRule.contains("\'")) {
                businessRule = businessRule.replaceAll("\'", "\"");
            }
            row.setBusinessRule(businessRule);
            mapspeclist.add(row);

        }

    }

    private static void addmapspecificationorphantargetBr(String columnAliasName, String businessRule) {
        String targetTableName = "";
        MappingSpecificationRow row = new MappingSpecificationRow();
        row.setSourceSystemEnvironmentName(sourceEnvironmentNamegl);
        row.setTargetSystemEnvironmentName(targetEnvironmentNamegl);
        row.setSourceSystemName(sourceSystemNamegl);
        row.setTargetSystemName(targetSystemNamegl);
        row.setTargetTableName(targetTableName);
        if ("".equalsIgnoreCase(columnAliasName)) {
        } else {
            row.setTargetColumnName(columnAliasName);
        }

        row.setBusinessRule(businessRule);
        mapspeclist.add(row);
    }

    public static Map<String, String> getKeyvaluemap(Set<String> joinconditionslist) {

        if (joinconditionslist.toString().trim().contains("#")) {

            String joinconditionslist1 = joinconditionslist.toString().replaceAll("#", "");

            joinconditionslist.add(joinconditionslist1);

//            joinconditions = (Set<String>)joinconditionslist1;
        }

        return keyvaluepair;
    }

    public Map<String, String> getKeyvalueJson() {
        Map<String, String> extendedProp = new LinkedHashMap();
        try {
            extendedProp = getKeyvaluemap(joinconditions);

        } catch (Exception e) {
            e.printStackTrace();
        }

        return extendedProp;

    }

    public static void getgroupbyclause(List<String> querylist, String dbvender) {

        dbVendor = getEDbVendorType(dbvender);
        for (String sql : querylist) {
            if (sql.trim().startsWith("(") && sql.trim().endsWith(")")) {
                sql = sql.substring(1, sql.length() - 1);
            }
            TCustomSqlStatement stmt2 = null;
            sqlparser = new TGSqlParser(dbVendor);
            sqlparser.sqltext = sql;
            int ret = sqlparser.parse();
            if (ret == 0) {

                TCustomSqlStatement stmnt = sqlparser.sqlstatements.get(0);
                if (stmnt instanceof TSelectSqlStatement) {
                    TSelectSqlStatement selectstatement = (TSelectSqlStatement) stmnt;
                    selectstatement.toString();
                    if (selectstatement.getGroupByClause() != null) {
                        String groupbyclause = selectstatement.getGroupByClause().toString();
                        whereCondition.add("group_by" + "#" + groupbyclause);
                    }
                    if (selectstatement.getOrderbyClause() != null) {
                        String ordeerbyclause = selectstatement.getOrderbyClause().toString();
                        whereCondition.add("order_by" + "#" + ordeerbyclause);
                    }
                }

            }
        }

    }

    public static void getQueryType(String sqltext, String dbvender, List<String> querylist, String sqlfile) {
        dbVendor = getEDbVendorType(dbvender);
        String lastSubselectQuery = "";
        if (querylist.size() >= 2) {
            lastSubselectQuery = querylist.get(querylist.size() - 2);
        } else {
            lastSubselectQuery = querylist.get(0);
        }
        TCustomSqlStatement stmt2 = null;

        sqlparser.sqltext = sqltext;
        int ret = sqlparser.parse();
        if (ret != 0) {
            sqlparser.sqlfilename = sqlfile;
            ret = sqlparser.parse();
        }
        try {
            if (ret == 0) {
                TCustomSqlStatement stmnt = (TCustomSqlStatement) sqlparser.sqlstatements.get(0);
                if (stmnt instanceof TInsertSqlStatement) {
                    String Insertxml = DataFlowAnalyzerv1.getanalyzeXmlfromString(sqltext, dbvender);
                    getJavaObjectfromxmls(Insertxml);
                    Map<String, String> columnIdMap = getColumnIdMap(Insertxml);
                    Map<String, String> sourceandtarget = analyzeSourceandtarget(Insertxml, columnIdMap);
                    List<String> columnLineageMap = getlineageMap(columnIdMap, sourceandtarget);
                    Set<String> businessrulelist = getBusinessRuleList(querylist, sqlparser);
                    querylist = removequeryfromquerylist(businessrulelist, querylist);
                    Map<Integer, String> brMap = getBusinessRuleFromMapspec(mapspeclist, businessrulelist);
                    UpdateBusinessRuleformappingspecification(querylist, brMap, sqlparser, dbvender, columnLineageMap);
                } else if (stmnt instanceof TUpdateSqlStatement) {
                    String Insertxml = DataFlowAnalyzerv1.getanalyzeXmlfromString(sqltext, dbvender);
                    getJavaObjectfromxmls(Insertxml);
                    Map<String, String> columnIdMap = getColumnIdMap(Insertxml);
                    Map<String, String> sourceandtarget = analyzeSourceandtarget(Insertxml, columnIdMap);
                    List<String> columnLineageMap = getlineageMap(columnIdMap, sourceandtarget);
                    Set<String> businessrulelist = getBusinessRuleList(querylist, sqlparser);
                    querylist = removequeryfromquerylist(businessrulelist, querylist);
                    Map<Integer, String> brMap = getBusinessRuleFromMapspec(mapspeclist, businessrulelist);
                    UpdateBusinessRuleformappingspecification(querylist, brMap, sqlparser, dbvender, columnLineageMap);
                } else if (stmnt instanceof TDeleteSqlStatement) {
                    String lastselectqueryXml = DataFlowAnalyzerv1.getanalyzeXmlfromString(sqltext, dbvender);
                    getJavaObjectfromxmls(lastselectqueryXml);
                    if (sqltext.contains("union") || sqltext.contains("UNION")) {
                        getLineageFordeleteunion(lastSubselectQuery, sqltext, dbvender);
                    } else {
                        getLineageForDelete(lastSubselectQuery, stmnt.toString(), dbvender);
                    }
                    Set<String> businessrulelist = getBusinessRuleList(querylist, sqlparser);
                    querylist = removequeryfromquerylist(businessrulelist, querylist);
                    getMapfromSelectquery(querylist, dbvender);
                } else if (stmnt instanceof TTruncateStatement) {
                    String queryXml = DataFlowAnalyzerv1.getanalyzeXmlfromString(sqltext, dbvender);
                    getJavaObjectfromxmls(queryXml);
                    getMapfromSelectquery(querylist, dbvender);
                    Set<String> businessrulelist = getBusinessRuleList(querylist, sqlparser);
                    querylist = removequeryfromquerylist(businessrulelist, querylist);
                } else if (stmnt instanceof TMssqlCreateProcedure) {
                    String Insertxml = DataFlowAnalyzerv1.getanalyzeXmlfromString(sqltext, dbvender);
                    getJavaObjectfromxmls(Insertxml);
                    Map<String, String> columnIdMap = getColumnIdMap(Insertxml);
                    Map<String, String> sourceandtarget = analyzeSourceandtarget(Insertxml, columnIdMap);
                    List<String> columnLineageMap = getlineageMap(columnIdMap, sourceandtarget);

                    Set<String> businessrulelist = getBusinessRuleList(querylist, sqlparser);
                    querylist = removequeryfromquerylist(businessrulelist, querylist);
                    Map<Integer, String> brMap = getBusinessRuleFromMapspec(mapspeclist, businessrulelist);
                    UpdateBusinessRuleformappingspecification(querylist, brMap, sqlparser, dbvender, columnLineageMap);
                } else if (stmnt instanceof TCreateTableSqlStatement || stmnt instanceof TAlterTableStatement || stmnt instanceof TCreateIndexSqlStatement || stmnt instanceof TDb2CreateProcedure || stmnt instanceof TCreateViewSqlStatement) {
                    String Insertxml = DataFlowAnalyzerv1.getanalyzeXmlfromString(sqltext, dbvender);
                    getJavaObjectfromxmls(Insertxml);
                    Map<String, String> columnIdMap = getColumnIdMap(Insertxml);
                    Map<String, String> sourceandtarget = analyzeSourceandtarget(Insertxml, columnIdMap);
                    List<String> columnLineageMap = getlineageMap(columnIdMap, sourceandtarget);
                    Set<String> businessrulelist = getBusinessRuleList(querylist, sqlparser);
                    //  Set<String> businessrulelist = getBusinessRuleList(querylist, sqlparser);
                    querylist = removequeryfromquerylist(businessrulelist, querylist);
                    Set<TExpression> brlist = getExpressionList(querylist, sqlparser);
                    Map<Integer, String> brMap = getBusinessRuleFromMapspec(mapspeclist, businessrulelist);
                    UpdateBusinessRuleformappingspecification(querylist, brMap, sqlparser, dbvender, columnLineageMap);
                } else {

                    String selectxml = DataFlowAnalyzerv1.getanalyzeXmlfromString(sqltext, dbvender);
                    //   Map<String, List<String>> getresultquerymap = getresultquerymap(sqltext, dbvender);
                    getJavaObjectfromxmls(selectxml);
                    Map<String, String> columnIdMap = getColumnIdMap(selectxml);
                    Map<String, String> sourceandtarget = analyzeSourceandtarget(selectxml, columnIdMap);
                    List<String> columnLineageMap = getlineageMap(columnIdMap, sourceandtarget);
                    Set<String> businessrulelist = getBusinessRuleList(querylist, sqlparser);
                    columnLineageMap.toString();
                    //   Set<String> businessrulelist = getBusinessRuleList(querylist, sqlparser);
                    querylist = removequeryfromquerylist(businessrulelist, querylist);
                    Set<TExpression> brlist = getExpressionList(querylist, sqlparser);
                    Map<Integer, String> brMap = getBusinessRuleFromMapspec(mapspeclist, businessrulelist);
                    UpdateBusinessRuleformappingspecification(querylist, brMap, sqlparser, dbvender, columnLineageMap);

                }
            }

        } catch (Exception e) {
            e.printStackTrace();
            sqlparser.sqlstatements.get(0).getClass().getName();
        }
    }

    public static void deleteduplicaterow(ArrayList<MappingSpecificationRow> mapspeclist, Map<String, List<String>> tabcollist, String targettablename, String targetcolumnName) {

        for (Entry<String, List<String>> entry : tabcollist.entrySet()) {
            String tablename = entry.getKey();
            List<String> columnlist = entry.getValue();
            for (String sourcecolumn : columnlist) {
                Iterator<MappingSpecificationRow> iter = mapspeclist.iterator();
                while (iter.hasNext()) {
                    MappingSpecificationRow row = iter.next();
                    if (row.getTargetTableName().equalsIgnoreCase(targettablename) && row.getSourceTableName().equalsIgnoreCase(tablename) && row.getSourceColumnName().equalsIgnoreCase(sourcecolumn) && row.getTargetColumnName().equalsIgnoreCase(targetcolumnName)) {
                        iter.remove();
                    }
                }
            }

        }

    }

    public static void getLineageforUnionInsert(String unionQuery, String dbvendor) {
        String targetTablename = "";
        String targetColumnName = "";
        String sourceTableName = "";
        String sourceColumnName = "";
        String sourceSide = "";
        String targetSide = "";
        Set<String> insertcolumns = new LinkedHashSet();
        String insertselecttablename = "";
        String insertselectInput = "";
        String insertselect = "";
        String middlecomp = "";
        Map<String, String> insertunionmap = new LinkedHashMap<>();
        Dlineage resultofselectQuery = getDataflowObject(unionQuery, dbvendor);
        int i = 0;
        int j = 0;
        int k = 0;
        for (Object Dlineageobject : resultofselectQuery.getColumnOrTableOrResultset()) {
            if (Dlineageobject instanceof Dlineage.Relation) {
                if (((Dlineage.Relation) Dlineageobject).getType().equals("dataflow")) {
                    for (Dlineage.Relation.Target subselecttarget : ((Dlineage.Relation) Dlineageobject).getTarget()) {
                        if (subselecttarget.getParentName().equals("RESULT_OF_UNION")) {
                            targetTablename = subselecttarget.getParentName();
                            targetColumnName = subselecttarget.getColumn();
                            for (Dlineage.Relation.Source subselectsource : ((Dlineage.Relation) Dlineageobject).getSource()) {
                                sourceTableName = subselectsource.getParentName();
                                sourceColumnName = subselectsource.getColumn();
                                if (i == 0) {
                                    sourceSide = sourceTableName + "#" + sourceColumnName;
                                    targetSide = targetTablename + "#" + targetColumnName;
                                } else {
                                    sourceSide = sourceSide + "$" + sourceTableName + "#" + sourceColumnName;
                                    targetSide = targetSide + "$" + targetTablename + "#" + targetColumnName;
                                }
                                i++;
                            }
                        }

                    }
                    for (Dlineage.Relation.Source subselectsource : ((Dlineage.Relation) Dlineageobject).getSource()) {
                        if (subselectsource.getParentName().equals("RESULT_OF_UNION")) {
                            for (Dlineage.Relation.Target subselecttarget : ((Dlineage.Relation) Dlineageobject).getTarget()) {

                                if (k == 0) {
                                    middlecomp = subselecttarget.getParentName() + "#" + subselecttarget.getColumn();

                                } else {

                                    middlecomp = middlecomp + "$" + subselecttarget.getParentName() + "#" + subselecttarget.getColumn();

                                }
                                k++;
                                String targetTableName = subselecttarget.getParentName();

                            }

                        }
                        targetTablename = subselectsource.getParentName();
                        targetColumnName = subselectsource.getColumn();

                    }

                }

                for (Dlineage.Relation.Target subselecttarget : ((Dlineage.Relation) Dlineageobject).getTarget()) {
                    if (subselecttarget.getParentName().equals("INSERT-SELECT")) {
                        for (Dlineage.Relation.Source outputtarget : ((Dlineage.Relation) Dlineageobject).getSource()) {
                            insertselecttablename = outputtarget.getParentName();
                            break;
                        }

                        for (Dlineage.Relation.Target outputtarget : ((Dlineage.Relation) Dlineageobject).getTarget()) {

                            if (j == 0) {
                                insertselectInput = insertselecttablename + "#" + outputtarget.getColumn();
                                insertselect = subselecttarget.getParentName() + "#" + outputtarget.getColumn();

                            } else {
                                insertselectInput = insertselectInput + "$" + insertselecttablename + "#" + outputtarget.getColumn();
                                insertselect = insertselect + "$" + subselecttarget.getParentName() + "#" + outputtarget.getColumn();
                            }

                            j++;

                        }
                    }
                }
                for (Dlineage.Relation.Source subselectsource : ((Dlineage.Relation) Dlineageobject).getSource()) {
                    if (subselectsource.getParentName().equals("INSERT-SELECT")) {
                        for (Dlineage.Relation.Source outputtarget : ((Dlineage.Relation) Dlineageobject).getSource()) {
                            String insertselecttablename1 = outputtarget.getParentName();
                            String insertcolumns1 = outputtarget.getColumn();
                            if (insertselecttablename1 != null && insertcolumns1 != null) {

                                insertcolumns.add(insertselecttablename1 + "#" + insertcolumns1);
                            }

                            break;
                        }

                    }
                }

            }
        }

        updatespecrow(mapspeclist, "INSERT-SELECT");
        // insertunionmap.put(sourceSide, targetSide);
        insertunionmap.put(targetSide, middlecomp);
        insertunionmap.put(middlecomp, insertselect);

        addUpdatemapspecrow(insertunionmap, insertcolumns);

    }

    public static Map<String, List<String>> getbusinessrule(TExpression businessRule, TCustomSqlStatement query) {
        long starttime = System.currentTimeMillis();
        TExpression expression = (TExpression) businessRule;
//        System.out.println("------" + query.toString());
        columnInClause colclause = new columnInClause();
        colclause.printColumns(businessRule, query);
        List<String> businessrulelist = new LinkedList(Columnlist.ColumnList);
        businessrulelist = getcolumnlist(businessrulelist);
        if (Columnlist.ColumnList != null) {
            Columnlist.ColumnList.clear();
        }

        Map<String, List<String>> tableCol = getMap(businessrulelist);
        long endtime = System.currentTimeMillis();
        long stat = endtime - starttime;
        Long statsecond = TimeUnit.MILLISECONDS.toSeconds(stat);
        // System.out.println("----time taken in businessrule-----" + statsecond);
        return tableCol;

    }

    public static Map<String, List<String>> getMap(List<String> columndetailsfromlist) {
        Map<String, List<String>> tablecollist = new LinkedHashMap<>();
        List<String> collist = null;
        for (String columnname : columndetailsfromlist) {
            int size = columnname.split("\\.").length;
            String tablename = columnname.split("\\.")[0].toUpperCase();
            String columnName = columnname.split("\\.")[size - 1].toUpperCase();
            String tabcol[] = columnname.split("\\.");
            StringBuilder sb = new StringBuilder();
            List<String> tablelist = new LinkedList<>();
            for (int i = 0; i < tabcol.length - 1; i++) {
                tablelist.add(tabcol[i]);
            }

            tablename = StringUtils.join(tablelist, ".").toUpperCase();
            tablename = tablename.replace("[", "").replace("]", "");
            if (!tablecollist.containsKey(tablename)) {
                collist = new LinkedList<>();
                collist.add(columnName.toUpperCase());
                tablecollist.put(tablename.toUpperCase(), collist);

            } else {
                tablecollist.get(tablename.toUpperCase()).add(columnName);
//    tablecollist.put(tablename,colname+","+columnName);
            }

        }
        return tablecollist;
    }

    public static boolean checktableNameforsource(ArrayList<MappingSpecificationRow> mapspeclist, String tablename) {
        boolean flag = false;
        Iterator<MappingSpecificationRow> iter = mapspeclist.iterator();
        String tabName = "RESULT_OF_" + tablename;
        while (iter.hasNext()) {
            MappingSpecificationRow row = iter.next();
            //   System.out.println(row.getSourceTableName() + "_____" + row.getSourceTableName().equalsIgnoreCase(tablename) + " " + tablename);
            if (row.getSourceTableName().equalsIgnoreCase(tabName) || row.getTargetTableName().equalsIgnoreCase(tabName)) {
                flag = true;
                break;

            }

        }
        return flag;
    }

    public static boolean checkForUpdateUnionLineage(ArrayList<MappingSpecificationRow> mapspeclist) {
        boolean flag = false;
        Iterator<MappingSpecificationRow> iter = mapspeclist.iterator();
        String tabName = "UPDATE-SET";
        while (iter.hasNext()) {
            MappingSpecificationRow row = iter.next();
            if (row.getTargetTableName().equalsIgnoreCase(tabName)) {
                flag = true;
                break;

            }

        }
        return flag;
    }

    public static void checkForResultOfLineage(ArrayList<MappingSpecificationRow> mapspeclist) {
        boolean flag = false;
        Set<String> resultOfColSet = new LinkedHashSet();
        Map<String, String> updateSetColMap = new LinkedHashMap();
        Iterator<MappingSpecificationRow> iter = mapspeclist.iterator();
        String updateSet = "UPDATE-SET";
        String resultOfSelect = checkTargettableNameforupdate(mapspeclist);

        while (iter.hasNext()) {
            MappingSpecificationRow row = iter.next();
            if (row.getTargetTableName().equalsIgnoreCase(resultOfSelect)) {
                if (!row.getTargetColumnName().equals("")) {
                    resultOfColSet.add(row.getTargetTableName() + "#" + row.getTargetColumnName());
                }

            } else if (row.getSourceTableName().equalsIgnoreCase(resultOfSelect)) {
                if (!row.getSourceColumnName().equals("")) {
                    resultOfColSet.add(row.getSourceTableName() + "#" + row.getSourceColumnName());
                }

            } else if (row.getSourceTableName().equalsIgnoreCase(updateSet)) {
                updateSetColMap.put(row.getSourceColumnName(), row.getSourceTableName());

            } else if (row.getSourceTableName().equalsIgnoreCase(updateSet)) {
                updateSetColMap.put(row.getTargetColumnName(), row.getTargetTableName());

            }

        }
        updateResultOfLineagespecs(resultOfColSet, updateSetColMap);
    }

    public static void updateResultOfLineagespecs(Set<String> resultOfColSet, Map<String, String> updateSetColMap) {
        try {

            boolean flag = false;
            MappingSpecificationRow newSpec = null;

            String updateSet = "UPDATE-SET";
            //  String resultOfSelect = "RESULT_OF_SELECT-QUERY";
            String resultOfSelect = checkTargettableNameforupdate(mapspeclist);

            for (String string : resultOfColSet) {
                String sourcetabName = string.split("#")[0];
                String sourcecolName = string.split("#")[1];
                if (checkForUpdateUnionLineage(mapspeclist, sourcetabName, sourcecolName)) {
                    continue;
                } else {
                    newSpec = new MappingSpecificationRow();
                    newSpec.setSourceSystemEnvironmentName(sourceEnvironmentNamegl);
                    newSpec.setTargetSystemEnvironmentName(targetEnvironmentNamegl);
                    newSpec.setSourceSystemName(sourceSystemNamegl);
                    newSpec.setTargetSystemName(targetSystemNamegl);
                    newSpec.setSourceTableName(sourcetabName);
                    newSpec.setSourceColumnName(sourcecolName);
                    newSpec.setTargetTableName(updateSet);
                    if (updateSetColMap.get(sourcecolName.toUpperCase()) == null) {
                        continue;
                    }
                    if (updateSetColMap.get(sourcecolName.toUpperCase()).equalsIgnoreCase(updateSet)) {
                        newSpec.setTargetColumnName(sourcecolName);
                    }
                }

                mapspeclist.add(newSpec);
            }

        } catch (Exception e) {
            e.printStackTrace();

        }

    }

    public static boolean checkForUpdateUnionLineage(ArrayList<MappingSpecificationRow> mapspeclist, String srcTblName, String SourceColName) {
        boolean flag = false;
        Iterator<MappingSpecificationRow> iter = mapspeclist.iterator();
        String tabName = "UPDATE-SET";
        while (iter.hasNext()) {
            MappingSpecificationRow row = iter.next();
            if (row.getSourceTableName().equalsIgnoreCase(srcTblName) && row.getSourceColumnName().equalsIgnoreCase(SourceColName)) {
                flag = true;
                break;

            }

        }
        return flag;
    }

    public static String checkTargettableNameforupdate(ArrayList<MappingSpecificationRow> mapspeclist) {
        boolean flag = false;
        String srctabName = "";
        Iterator<MappingSpecificationRow> iter = mapspeclist.iterator();

        while (iter.hasNext()) {
            MappingSpecificationRow row = iter.next();

            if (row.getTargetTableName().equalsIgnoreCase("UPDATE-SET")) {
                srctabName = row.getSourceTableName();

                break;

            }

        }
        return srctabName;
    }

    //sukhendu
    public static void createMapSpecForOnly() {
        MappingSpecificationRow mapspec = new MappingSpecificationRow();
        for (Map.Entry<String, List<String>> entry : tableColRel.entrySet()) {
            String key = entry.getKey();
            List<String> valuesList = entry.getValue();
            for (String values : valuesList) {
                mapspec = new MappingSpecificationRow();
                mapspec.setSourceSystemEnvironmentName(sourceEnvironmentNamegl);
                mapspec.setTargetSystemEnvironmentName(targetEnvironmentNamegl);
                mapspec.setSourceSystemName(sourceSystemNamegl);
                mapspec.setTargetSystemName(targetSystemNamegl);

                mapspec.setSourceColumnName(values);
                mapspec.setSourceTableName(key);

                mapspeclist.add(mapspec);
            }
        }

    }

    public static String querynoinType(String query, String dbvender) {

        dbVendor = getEDbVendorType(dbvender);

        TCustomSqlStatement stmt2 = null;
        sqlparser = new TGSqlParser(dbVendor);
        sqlparser.sqltext = query;
        int ret = sqlparser.parse();
        try {
            if (ret == 0) {
                TCustomSqlStatement stmnt = (TCustomSqlStatement) sqlparser.sqlstatements.get(0);
                TJoin joincond = stmnt.getJoins().getJoin(0);
                TJoinItem joinitem = joincond.getJoinItems().getJoinItem(0);
                EJoinType jointype = joinitem.getJoinType();
                return jointype.toString();
            }

        } catch (Exception e) {

        }
        return null;

    }

    public static Map<String, List<String>> gettablecolumns(Set<String> tablecolumnset) {
        Map<String, List<String>> tableColumnMap = new LinkedHashMap<>();

        for (String tabcol : tablecolumnset) {
            List<String> columnlist = new LinkedList<>();
            String tablename = tabcol.split("#")[0];

            String columnName = tabcol.split("#")[1];
            if (tableColumnMap.containsKey(tablename)) {
                tableColumnMap.get(tablename).add(columnName);
            } else {
                columnlist.add(columnName);
                tableColumnMap.put(tablename, columnlist);
            }

        }
        return tableColumnMap;
    }

    public static void makemapfromBusinessrule(String query, String dbvender, Map<String, List<String>> tablecolmap) {

        dbVendor = getEDbVendorType(dbvender);
        sqlparser = new TGSqlParser(dbVendor);
        sqlparser.sqltext = query;
        int ret = sqlparser.parse();
        if (ret == 0) {
            TCustomSqlStatement stmnt = sqlparser.sqlstatements.get(0);
            TResultColumnList rsltstatement = stmnt.getResultColumnList();

            for (int j = 0; rsltstatement != null && j < rsltstatement.size(); j++) {
                TResultColumn column = rsltstatement.getResultColumn(j);
                TExpression expr = column.getExpr();
                String columnaliasName = column.getColumnAlias();
                String targetcolumnName = column.getColumnNameOnly();
                EExpressionType type = expr.getExpressionType();
                if (type == type.simple_object_name_t) {
                    continue;
                }

                String expression = column.getExpr().toString();
                if (expression.contains("~")) {
                    expression = expression.replace("~", "tild");
                }
                //   System.out.println("expression" + "::" + expression);

                Map<String, List<String>> mapinfo = new LinkedHashMap(getbusinessrule(expr, stmnt));
                if (mapinfo.size() != 0) {
                    for (Entry<String, List<String>> entry : mapinfo.entrySet()) {
                        String key = entry.getKey();

                        if (!"".equals(key)) {
                            if (tablecolmap.get(key) != null) {
                                List<String> valueoftablecol = tablecolmap.get(key);
                                if (!entry.getValue().isEmpty()) {
                                    valueoftablecol.addAll(entry.getValue());
                                }

                            }

                        }
                    }

                }

            }
        }

    }

    public static Map<String, Map<String, List<String>>> makemapfromBusinessrule(String query, String dbvender) {

        dbVendor = getEDbVendorType(dbvender);
        sqlparser = new TGSqlParser(dbVendor);
        sqlparser.sqltext = query;
        int ret = sqlparser.parse();
        Map<String, Map<String, List<String>>> columnfromBusinessrule = null;
        if (ret == 0) {
            TCustomSqlStatement stmnt = sqlparser.sqlstatements.get(0);
            TResultColumnList rsltstatement = stmnt.getResultColumnList();
            columnfromBusinessrule = new LinkedHashMap();
            for (int j = 0; rsltstatement != null && j < rsltstatement.size(); j++) {
                TResultColumn column = rsltstatement.getResultColumn(j);
                TExpression expr = column.getExpr();
                String columnaliasName = column.getColumnAlias();
                String targetcolumnName = column.getColumnNameOnly();
                EExpressionType type = expr.getExpressionType();
                if (type == type.simple_object_name_t) {
                    continue;
                }

                String expression = column.getExpr().toString();
                if (expression.contains("~")) {
                    expression = expression.replace("~", "tild");
                }
                //       System.out.println("expression" + "::" + expression);

                Map<String, List<String>> mapinfo = new LinkedHashMap(getbusinessrule(expr, stmnt));

                columnfromBusinessrule.put(expression + "$$" + columnaliasName, mapinfo);
            }
        }
        return columnfromBusinessrule;
    }

    public static void removeBlankSourceTableandColumn(ArrayList<MappingSpecificationRow> mapspeclist) {
        Iterator<MappingSpecificationRow> iter = mapspeclist.iterator();

        while (iter.hasNext()) {
            MappingSpecificationRow row = iter.next();
            if (row.getSourceColumnName().equals("") && row.getSourceTableName().equals("") && ("").equalsIgnoreCase(row.getBusinessRule())) {

                iter.remove();
            }

        }
    }

    public static void removeBlankTarget(ArrayList<MappingSpecificationRow> mapspeclist) {
        Iterator<MappingSpecificationRow> iter = mapspeclist.iterator();

        while (iter.hasNext()) {
            // for removing blank target
            MappingSpecificationRow row = iter.next();
//            System.out.println("targetTableName----"+row.getTargetColumnName().toString()+"-------"+row.getTargetTableName().toString());
            if (row.getTargetColumnName().equals("") && row.getTargetTableName().equals("") && "".equalsIgnoreCase(row.getBusinessRule())) {
//                 System.out.println("------------------method is working");
                iter.remove();
            }
            if (row.getTargetColumnName().toUpperCase().trim().startsWith("THEN") || row.getTargetColumnName().toUpperCase().trim().startsWith("CASE") || row.getTargetTableName().toUpperCase().trim().startsWith("THEN") || row.getTargetTableName().toUpperCase().trim().startsWith("CASE")) {
//                 System.out.println("------------------method is working");
                iter.remove();
            }

        }
    }

    public static void removederivedTarget(ArrayList<MappingSpecificationRow> mapspeclist) {
        Iterator<MappingSpecificationRow> iter = mapspeclist.iterator();

        while (iter.hasNext()) {
            MappingSpecificationRow row = iter.next();

            if (row.getTargetColumnName().contains("(COLUMN IN DERIVED TABLE)")) {
                // System.out.println("------------------");
                row.setTargetColumnName(row.getTargetColumnName().replace("(COLUMN IN DERIVED TABLE)", ""));
            }
            if (row.getSourceColumnName().contains("(COLUMN IN DERIVED TABLE)")) {
                // System.out.println("------------------");
                row.setSourceColumnName(row.getSourceColumnName().replace("(COLUMN IN DERIVED TABLE)", ""));
            }

        }
    }

    public static void removecommas(ArrayList<MappingSpecificationRow> mapspeclist) {
        Iterator<MappingSpecificationRow> iter = mapspeclist.iterator();

        while (iter.hasNext()) {
            MappingSpecificationRow row = iter.next();

            if (row.getTargetColumnName().contains("\"")) {
                // System.out.println("------------------");
                row.setTargetColumnName(row.getTargetColumnName().replace("\"", ""));
            }
            if (row.getSourceColumnName().contains("\"")) {
                // System.out.println("------------------");
                row.setSourceColumnName(row.getSourceColumnName().replace("\"", ""));
            }

        }
    }

    public static void removeHshTarget(ArrayList<MappingSpecificationRow> mapspeclist) {
        Iterator<MappingSpecificationRow> iter = mapspeclist.iterator();

        while (iter.hasNext()) {
            MappingSpecificationRow row = iter.next();

            if (row.getTargetTableName().contains("#")) {
                row.setTargetTableName(row.getTargetTableName().replace("#", ""));
            }
            if (row.getSourceTableName().contains("#")) {
                row.setSourceTableName(row.getSourceTableName().replace("#", ""));
            }
        }
    }

    public static void rePlaceMiddleComponentWithMapName(ArrayList<MappingSpecificationRow> mapspeclist, String mapName) {
        Iterator<MappingSpecificationRow> iter = mapspeclist.iterator();

        while (iter.hasNext()) {
            MappingSpecificationRow row = iter.next();
            String targetname = row.getTargetTableName() + "_" + mapName;
            row.setTargetTableName(targetname);
            String sourceName = row.getSourceTableName() + "_" + mapName;
            row.setSourceTableName(sourceName);

        }
    }

    public static void updateMetadataInformation(ArrayList<MappingSpecificationRow> mapspeclist, Map<String, String> metadataMap) {
        try {

            for (MappingSpecificationRow mappingSpecificationRow : mapspeclist) {

                String sourcetableName = mappingSpecificationRow.getSourceTableName();

                if (metadataMap.get(sourcetableName) != null) {

                    String sourceenv = metadataMap.get(sourcetableName);
                    String systemName = sourceenv.split("##")[0];
                    String envName = sourceenv.split("##")[0];
                    mappingSpecificationRow.setSourceSystemName(systemName);
                    mappingSpecificationRow.setSourceSystemEnvironmentName(envName);
                }

                String targetTableName = mappingSpecificationRow.getTargetTableName();
                if (metadataMap.get(targetTableName) != null) {
                    String targetenv = metadataMap.get(sourcetableName);
                    String systemName = targetenv.split("##")[0];
                    String envName = targetenv.split("##")[0];
                    mappingSpecificationRow.setTargetSystemName(systemName);
                    mappingSpecificationRow.setTargetSystemEnvironmentName(envName);
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static Map<String, String> getColumnIdMap(String xmlfile) {
        Map<String, String> columnwithIdMap = new LinkedHashMap();
        try {
            InputStream in = IOUtils.toInputStream(xmlfile, "UTF-8");
            JAXBContext jaxbContext
                    = JAXBContext.newInstance("com.sqlToJson.BindingPojo");
            Unmarshaller unmarshaller
                    = jaxbContext.createUnmarshaller();
            Dlineage dj = (Dlineage) unmarshaller.unmarshal(in);
            int i = 0;
            for (Object dataflowobj : dj.getColumnOrTableOrResultset()) {
                LinkedHashMap<String, String> maps = new LinkedHashMap<>();
                List<String> columnsNameList = new LinkedList();
                if (dataflowobj instanceof Dlineage.Table) {                         //Dlineage.Table is instance of dataobj
                    String tableName = ((Dlineage.Table) dataflowobj).getName();
                    String SchemaName = ((Dlineage.Table) dataflowobj).getSchema();
                    String database = ((Dlineage.Table) dataflowobj).getdatabase();
                    List<Column> columnList = ((Dlineage.Table) dataflowobj).getColumn();
                    String tablealias = ((Dlineage.Table) dataflowobj).getAlias();
                    for (Column column : columnList) {
                        columnsNameList.add(column.getName());
                        if (StringUtils.isNotBlank(SchemaName) && StringUtils.isNotBlank(database)) {
                            String tabletoken = column.getName() + "#" + database + "." + SchemaName + "." + tableName.replace("[", "").replace("]", "");
                            columnwithIdMap.put(column.getId(), tabletoken);
                        } else if (StringUtils.isNotBlank(SchemaName)) {
                            String tabletoken = column.getName() + "#" + SchemaName + "." + tableName.replace("[", "").replace("]", "");
                            columnwithIdMap.put(column.getId(), tabletoken);

                        } else {
                            String tabletoken = column.getName() + "#" + tableName.replace("[", "").replace("]", "");
                            columnwithIdMap.put(column.getId(), column.getName() + "#" + tableName);
                        }
                    }
                }
                if (dataflowobj instanceof Dlineage.Resultset) {
                    String rsultsetTableName = ((Dlineage.Resultset) dataflowobj).getName();
                    List<Column> resultcolumnList = ((Dlineage.Resultset) dataflowobj).getColumn();
                    List<String> resultcolumnsNameList = new LinkedList();
                    for (Column column : resultcolumnList) {
                        columnwithIdMap.put(column.getId(), column.getName() + "#" + rsultsetTableName);
                    }
                }
                if (dataflowobj instanceof Dlineage.View) {
                    String rsultsetTableName = ((Dlineage.View) dataflowobj).getName();
                    List<Column> resultcolumnList = ((Dlineage.View) dataflowobj).getColumn();
                    List<String> resultcolumnsNameList = new LinkedList();
                    for (Column column : resultcolumnList) {
                        columnwithIdMap.put(column.getId(), column.getName() + "#" + rsultsetTableName);
                    }

                }

            }
            int tesr = 0;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return columnwithIdMap;
    }

    public static Map<String, String> analyzeSourceandtarget(String xmlfile, Map<String, String> columnIdMap) {
        Map<String, String> sourceandtargetMap = new LinkedHashMap();
        try {
            InputStream in = IOUtils.toInputStream(xmlfile, "UTF-8");
            JAXBContext jaxbContext
                    = JAXBContext.newInstance("com.sqlToJson.BindingPojo");
            Unmarshaller unmarshaller
                    = jaxbContext.createUnmarshaller();
            Dlineage dj = (Dlineage) unmarshaller.unmarshal(in);
            int i = 0;
            for (Entry<String, String> entry : columnIdMap.entrySet()) {
                String key = entry.getKey();
                String value = entry.getValue();
                for (Object analyzerobject : dj.getColumnOrTableOrResultset()) {
                    LinkedHashMap<String, String> maps = new LinkedHashMap<>();
                    List<String> columnsNameList = new LinkedList();
                    if (analyzerobject instanceof Dlineage.Relation) {
                        String sourcetableName = "";
                        String targetTableName = "";
                        String sourceColumnName = "";
                        String targetColumnName = "";
                        String sourceinfomore = "";
                        if (((Dlineage.Relation) analyzerobject).getType().equals("fdd") || ((Dlineage.Relation) analyzerobject).getType().equals("fddi") || ((Dlineage.Relation) analyzerobject).getType().equals("fdr") || ((Dlineage.Relation) analyzerobject).getType().equals("frd")) {
                            for (Dlineage.Relation.Source sourceobj : ((Dlineage.Relation) analyzerobject).getSource()) {
                                if (((Dlineage.Relation) analyzerobject).getSource().size() > 1) {
                                    if (sourceobj.getId().equals(key)) {

                                        for (Dlineage.Relation.Target target : ((Dlineage.Relation) analyzerobject).getTarget()) {
                                            if (target.getColumn() != null) {
                                                if (sourceandtargetMap.containsKey(sourceobj.getId())) {

                                                    sourceandtargetMap.put(sourceobj.getId(), sourceandtargetMap.get(sourceobj.getId()) + "#" + target.getId());

                                                } else {

                                                    sourceandtargetMap.put(sourceobj.getId(), target.getId());

                                                }

                                            }

                                        }

                                    }

                                } else {
                                    if (StringUtils.isNotBlank(sourceobj.getId())) {
                                        if (sourceobj.getId().equals(key)) {

                                            for (Dlineage.Relation.Target target : ((Dlineage.Relation) analyzerobject).getTarget()) {
                                                if (target.getColumn() != null) {
                                                    if (sourceandtargetMap.containsKey(sourceobj.getId())) {

                                                        sourceandtargetMap.put(sourceobj.getId(), sourceandtargetMap.get(sourceobj.getId()) + "#" + target.getId());

                                                    } else {

                                                        sourceandtargetMap.put(sourceobj.getId(), target.getId());

                                                    }

                                                }

                                            }

                                        }
                                    }
                                }
                            }

                        }

                        i++;
                    }

                }
            }

            int tesr = 0;
        } catch (Exception e) {
            e.printStackTrace();
        }

        return sourceandtargetMap;

    }

    public static List<String> getlineageMap(Map<String, String> columnIdMap, Map<String, String> srcTgtMap) {
        List<String> lineagelist = new LinkedList();
        List<String> lineageString = null;
        Map<String, String> columnMap = new LinkedHashMap();
        try {
            Map<Integer, Set<String>> lineagemap = new ConcurrentHashMap();
            int i = 0;
            Iterator lineageiterator = srcTgtMap.entrySet().iterator();
            Set<String> globalList = new HashSet();
            while (lineageiterator.hasNext()) {
                Map.Entry<String, String> mapElement = (Map.Entry) lineageiterator.next();
                String key = mapElement.getKey();
                String value = mapElement.getValue();
                Set<String> lineageflowlist = new LinkedHashSet();
                lineageflowlist.add(key);
                key = value;
                if (key.contains("#")) {
                    lineageflowlist.addAll(getLineageList(key, srcTgtMap));
                } else {
                    while (srcTgtMap.containsKey(key)) {
                        lineageflowlist.add(key);
                        key = srcTgtMap.get(key);
                    }
                }

                if (key.contains("#")) {
                    lineageflowlist.addAll(getLineageList(key, srcTgtMap));
                } else {
                    lineageflowlist.add(key);
                }

                lineagemap.put(i, lineageflowlist);
                i++;
            }

            //    System.out.println("lineagefile----" + lineagemap);
            lineageString = new LinkedList();
            for (Entry<Integer, Set<String>> entry : lineagemap.entrySet()) {
                Integer key = entry.getKey();
                Set<String> value = entry.getValue();
                StringBuilder sb = new StringBuilder();
                for (String lineageset : value) {

                    sb.append(columnIdMap.get(lineageset)).append("$$");
                }
                lineageString.add(sb.toString());

            }

            //  System.out.println("--------" + lineageString);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return lineageString;
    }

    public static List<String> getLineageList(String value, Map<String, String> srcTgtMap) {
        List<String> lineageflowlist = new ArrayList();
        try {
            // while(srcTgtMap.containsKey(value) && !globalList.contains(value)){  
            String key = value;
            if (key.contains("#")) {
                String str[] = key.split("#");
                for (int j = 0; j < str.length; j++) {
                    key = str[j];
                    while (srcTgtMap.containsKey(key)) {
                        value = srcTgtMap.get(key);
                        lineageflowlist.add(key);

                        key = value;
                    }
                    lineageflowlist.add(key);
                }
            }
            // lineageflowlist.add(key);
            //}
        } catch (Exception e) {

        }

        return lineageflowlist;
    }

    private static void UpdateBusinessRuleformappingspecification(List<String> querylist, Map<Integer, String> brMap, TGSqlParser sqlparser, String dbvender, List<String> columnLineageMap) {
        long starttime = System.currentTimeMillis();
        Map<List<Map<String, List<String>>>, String> brInfoMap = new LinkedHashMap<>();
        Set<String> uniquequery = new LinkedHashSet<>(querylist);
        List<String> uniquequerylist = new LinkedList(uniquequery);
        List<Map<String, List<String>>> tableMap = null;
        List< List<Map<String, List<String>>>> tablemaptest = null;

        tablemaptest = new LinkedList<>();
        for (String query : uniquequerylist) {

            try {
                String parentquery = "";
                if (XmlVisitorv1.childParentQuery.get(query) != null) {
                    parentquery = XmlVisitorv1.childParentQuery.get(query);
                    if (parentquery.startsWith("(") && parentquery.endsWith(")")) {
                        parentquery = query.substring(1, query.length() - 1);

                    }
                }
                List<String> tableList = null;
                if (!"".equalsIgnoreCase(parentquery)) {
                    //System.out.println("----parentquery------" + parentquery);
                    // Map<String, List<String>> Tablecolmap = tableColumnInformationFromQuery(parentquery, dbvender);
//                    if (Tablecolmap != null) {
//                        tableList = new LinkedList<>(Tablecolmap.keySet());
//                    }

                }
                if (tableList == null) {
                    tableList = new LinkedList<>();
                }

                if (query.startsWith("(") && query.endsWith(")")) {
                    query = query.substring(1, query.length() - 1);
                }

                sqlparser.sqltext = query;
                int ret = sqlparser.parse();
                if (ret == 0) {
                    TCustomSqlStatement stmnt = sqlparser.sqlstatements.get(0);

                    TResultColumnList rsltstatement = stmnt.getResultColumnList();

                    TCustomSqlStatement targetStatement = getselectstatement(parentquery, dbvender);
                    if (targetStatement instanceof TCreateTableSqlStatement) {
                        tableList = new LinkedList<>();
                        TCreateTableSqlStatement createtable = (TCreateTableSqlStatement) targetStatement;
                        TObjectName objName = createtable.getTableName();
                        String tableName = objName.toString();
                        tableList.add(tableName);
                    }
                    if (targetStatement instanceof TInsertSqlStatement) {
                        tableList = new LinkedList<>();
                        TInsertSqlStatement createtable = (TInsertSqlStatement) targetStatement;
                        TObjectName objName = createtable.getTargetTable().getTableName();
                        String tableName = objName.toString();
                        tableList.add(tableName);
                    }
                    for (int j = 0; rsltstatement != null && j < rsltstatement.size(); j++) {
                        TResultColumn column = rsltstatement.getResultColumn(j);
                        TExpression expr = column.getExpr();
                        EExpressionType type = expr.getExpressionType();
                        if (type == type.simple_object_name_t) {
                            continue;
                        }
                        String columnaliasName = column.getColumnAlias();
                        columnaliasName = columnaliasName.replace("[", "").replace("]", "");
                        String targetColumn = "";
                        if (getBrFromMap(brMap, expr.toString()) != null) {

                            targetColumn = getBrFromMap(brMap, expr.toString());
                        }
                        if ("".equals(columnaliasName) && !"".equals(targetColumn)) {
                            columnaliasName = targetColumn;
                        }

                        long columnno = column.getColumnNo();

                        String expression = column.getExpr().toString();
                        if (expression.contains("~")) {
                            expression = expression.replace("~", "tild");
                        }

                        tableMap = new LinkedList<>();
                        // source
                        Map<String, List<String>> mapinfo = new LinkedHashMap(getbusinessrule(expr, stmnt));
                        //target
                        if (mapinfo.isEmpty()) {
                            mapinfo = new LinkedHashMap(getBusinessRule(expr.toString()));
                        }

                        if (mapinfo.isEmpty()) {
                            mapinfo = new LinkedHashMap(getBusinessRulefromMap(expr.toString()));
                        }
                        mapinfo = changeSourceMap(mapinfo, columnLineageMap);

                        columnLineageMap.toString();
                        List<String> sourcetables = new LinkedList(mapinfo.keySet());
                        //   if(sourcetables.size()==0)
                        //  {
                        // mapinfo =  changeSourceMap(mapinfo,columnLineageMap);
                        // sourcetables = new LinkedList(mapinfo.keySet());
                        //    }
                        List<String> targettablename = getTragetTableName(sourcetables);
                        targettablename.remove(null);
                        List<String> uniquetableName = targettablename.stream().filter(x -> x != null).collect(Collectors.toList());
                        List<String> Tgtinfolist = gettgtinfoforLineage(mapinfo, columnLineageMap, columnaliasName);
                        Tgtinfolist.clear();
                        String tagetTableName = "";
                        if (uniquetableName.size() > 0) {
                            tagetTableName = uniquetableName.get(0);
                        }

                        if (!"".equals(columnaliasName) && !"".equals(tagetTableName)) {
                            Tgtinfolist.add(columnaliasName + "#" + tagetTableName);
                        }

                        // expression
                        if (Tgtinfolist.isEmpty()) {
                            Tgtinfolist = gettgtinfoforLineage(mapinfo, columnLineageMap);

                        }
                        List<String> expressionlist = new LinkedList();
                        if (!expressionlist.contains(j)) {
                            addlineagemappingspecification(mapinfo, Tgtinfolist, expr.toString(), columnaliasName);
                            expressionlist.add(expr.toString());
                        }

                        brInfoMap.clear();
                        // System.out.println("-----" + tableMap);
                    }

                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        //  System.out.println("-----" + tablemaptest);

        long endtime = System.currentTimeMillis();
        long stat = endtime - starttime;
        long statsec = TimeUnit.MILLISECONDS.toSeconds(stat);
//        System.out.println("--parsing for businessrule---" + statsec);

    }

    public static List<String> gettgtinfoforLineage(Map<String, List<String>> sourcemap, List<String> columnlineageMap) {
        List<String> targetinfo = new LinkedList();
        try {

            for (Entry<String, List<String>> entry : sourcemap.entrySet()) {
                String tableName = entry.getKey();
                List<String> value = entry.getValue();
                for (String sourcecolumn : value) {
                    sourcecolumn = sourcecolumn.replace("(COLUMN IN DERIVED TABLE)", "");
                    String lineagekey = sourcecolumn + "#" + tableName.toUpperCase();

                    String target = gettargetinfo(lineagekey, columnlineageMap);
                    if (target == null) {
                        tableName = "RESULT_OF_" + tableName;
                        lineagekey = sourcecolumn + "#" + tableName.toUpperCase();
                        target = gettargetinfo(lineagekey, columnlineageMap);
                    }
                    if (target == null) {

                        target = getTargetInfofromCOlumn(columnlineageMap, sourcecolumn);
                    }

                    if (target != null) {
                        targetinfo.add(target);
                    }
                    if (target != null) {
                        targetinfo.add(target);
                    }

                }

            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return targetinfo;
    }

    public static List<String> gettgtinfoforLineage(Map<String, List<String>> sourcemap, List<String> columnlineageMap, String columnAliasName) {
        List<String> targetinfo = new LinkedList();
        try {
            columnlineageMap.toString();
            for (Entry<String, List<String>> entry : sourcemap.entrySet()) {
                String tableName = entry.getKey();
                List<String> value = entry.getValue();
                for (String sourcecolumn : value) {

                    String lineagekey = sourcecolumn + "#" + tableName.toUpperCase();
                    lineagekey = lineagekey.replace("(COLUMN IN DERIVED TABLE)", "");
                    String target = getTargetInfoForcolumn(lineagekey, columnlineageMap, columnAliasName);
                    if (target != null) {
                        targetinfo.add(target);
                    }

                }

            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return targetinfo;
    }

    public static String gettargetinfo(String sourcetabname, List<String> targetstr) {
        try {
            targetstr.toString();
            for (String lineagestr : targetstr) {
                sourcetabname = sourcetabname.replace("(COLUMN IN DERIVED TABLE)", "");
                String sourcetabfromlineage = lineagestr.split("\\$\\$")[0];
                if (sourcetabfromlineage.equalsIgnoreCase(sourcetabname)) {
                    return lineagestr.split("\\$\\$")[lineagestr.split("\\$\\$").length - 1];

                }

            }

        } catch (Exception e) {

            e.printStackTrace();
        }
        return null;
    }

    public static String getTargetInfoForcolumn(String sourcetabname, List<String> targetstr, String columnaliasName) {
        try {
            for (String lineagestr : targetstr) {
                String columnName = "";
                String[] sourcetabfromlineage = lineagestr.split("\\$\\$");
                for (String tablecolumnrelationship : sourcetabfromlineage) {
                    if (tablecolumnrelationship.split("##").length > 1) {
                        columnName = tablecolumnrelationship.split("##")[0];
                    } else {
                        columnName = tablecolumnrelationship.split("#")[0];

                    }

                    if (columnName.equalsIgnoreCase(columnaliasName)) {
                        return tablecolumnrelationship;
                    }
                }

            }

        } catch (Exception e) {

            e.printStackTrace();
        }
        return null;
    }

    public static void addlineagemappingspecification(Map<String, List<String>> sourceInfo, List<String> targetInfo, String businessExpression, String columnaliasname) {
        String sourceTableName = "";
        String columnName = "";
        String targetColumnName = "";
        String businessRule = "";
        String targetTableName = "";
        String sourcecolumnName = "";

        try {
            StringBuilder sbuidersourcetab = new StringBuilder();
            StringBuilder sbuidersourcecol = new StringBuilder();
            StringBuilder sbuidertargettab = new StringBuilder();
            StringBuilder sbuidertargetcol = new StringBuilder();
            MappingSpecificationRow mapspecRow = new MappingSpecificationRow();
            Set<String> sourceTables = sourceInfo.keySet();
            Map<String, String> modifydeclarealismap = modifytablealiasmap();
            for (String sourceTable : sourceTables) {
                sourceTableName = sourceTable;
                sourceTableName = sourceTableName.replace("[", "").replace("]", "");
                if (tableColRel.containsKey("RESULT_OF_" + sourceTableName)) {
                    sourceTableName = "RESULT_OF_" + sourceTableName;
                }
                if (tableColRel.containsKey("CTE-" + sourceTableName)) {
                    sourceTableName = "CTE-" + sourceTableName;
                }
                modifydeclarealismap.toString();
                if (modifydeclarealismap.containsKey(sourceTable.toUpperCase())) {
                    sourceTableName = modifydeclarealismap.get(sourceTable.toUpperCase());
                }
                List<String> sourcetab = new LinkedList();
                List<String> columncollection = new LinkedList();
                Set<String> sourcecolumns = new LinkedHashSet();
                if (sourceInfo.get(sourceTable.toUpperCase()) != null) {
                    columncollection = sourceInfo.get(sourceTable.toUpperCase());
                    sourcecolumns = new LinkedHashSet(columncollection);
                }

                for (int i = 0; i < sourcecolumns.size(); i++) {
                    sourcetab.add(sourceTableName);
                }

                Set<String> targettable = new LinkedHashSet(gettargetTableName(targetInfo));
                Set<String> targetcolumn = new LinkedHashSet(gettargetcolumnName(targetInfo));
                List<String> targettablelist = new ArrayList(targettable);
                List<String> targetcolumncolumnlist = new ArrayList(targetcolumn);
                String targetTableNam = "";
                String targetColumnNam = "";
                if (targettablelist.size() > 0) {
                    targetTableNam = targettablelist.get(0);
                }
                if (targetcolumncolumnlist.size() > 0) {
                    targetColumnNam = targetcolumncolumnlist.get(0);
                }
                ListIterator<String> sourcetabiterator = sourcetab.listIterator();
                while (sourcetabiterator.hasNext()) {
                    removespec(sourcetabiterator.next(), sourcecolumns, targetTableNam, targetColumnNam);
                }
                String sourceTabt = (sourcetab.size() > 1) ? StringUtils.join(sourcetab, "\n") : StringUtils.join(sourcetab, "");
                sbuidersourcetab.append(sourceTabt).append("\n");
                String sourcecolumn = (sourcecolumns.size() > 1) ? StringUtils.join(sourcecolumns, "\n") : StringUtils.join(sourcecolumns, "");
                sbuidersourcecol.append(sourcecolumn).append("\n");
                String targettab = (targettable.size() > 1) ? StringUtils.join(targettable, "\n") : StringUtils.join(targettable, "");
                sbuidertargettab.append(targettab).append("\n");
                String targetcol = (targetcolumn.size() > 1) ? StringUtils.join(targetcolumn, "\n") : StringUtils.join(targetcolumn, "");
                sbuidertargetcol.append(targetcol).append("\n");

            }
            mapspecRow.setSourceSystemEnvironmentName(sourceEnvironmentNamegl);
            mapspecRow.setTargetSystemEnvironmentName(targetEnvironmentNamegl);
            mapspecRow.setSourceSystemName(sourceSystemNamegl);
            mapspecRow.setTargetSystemName(targetSystemNamegl);
            mapspecRow.setSourceTableName(sbuidersourcetab.toString().trim().replace("[", "").replace("]", ""));
            sourcecolumnName = sbuidersourcecol.toString().trim().replace("[", "").replace("]", "").replace("\"", "");
            String[] sourcecolumns = sourcecolumnName.split("\n");
            Set<String> sourcecolumnset = new LinkedHashSet(Arrays.asList(sourcecolumns));
            String distinctsourcecolumn = StringUtils.join(sourcecolumnset, "\n");
            mapspecRow.setSourceColumnName(sourcecolumnName.trim().replace("[", "").replace("]", "").replace("\"", ""));
            String[] targetcolumns = sbuidertargetcol.toString().split("\n");
            Set<String> targetcolumnset = new LinkedHashSet(Arrays.asList(targetcolumns));
            String distincttargetcolumn = StringUtils.join(targetcolumnset, "\n");
            String[] targettabs = sbuidertargettab.toString().split("\n");
            Set<String> targettabset = new LinkedHashSet(Arrays.asList(targettabs));
            String distincttargettable = StringUtils.join(targettabset, "\n");
            mapspecRow.setTargetTableName(distincttargettable.trim());
            if ("".equals(columnaliasname)) {
                mapspecRow.setTargetColumnName(distincttargetcolumn.trim().replace("\"", ""));
            } else {
                mapspecRow.setTargetColumnName(columnaliasname.replace("\"", ""));
                //  if (!StringUtils.isNotBlank(distincttargettable.trim())) {
                if (StringUtils.isBlank(distincttargettable)) {
                    String tgtTab = "";
                    if (tableColMapWhenWeNotgettingAliasTable.containsKey(columnaliasname.toUpperCase())) {
                        tgtTab = tableColMapWhenWeNotgettingAliasTable.get(columnaliasname.toUpperCase());
                        mapspecRow.setTargetTableName(tgtTab.trim());
                    }
                    if (StringUtils.isBlank(tgtTab.trim())) {
                        if (tableColMapWhenWeNotgettingAliasTablefdd.containsKey(columnaliasname.toUpperCase())) {
                            tgtTab = tableColMapWhenWeNotgettingAliasTablefdd.get(columnaliasname.toUpperCase());
                            mapspecRow.setTargetTableName(tgtTab.trim());
                        }
                    }
                }
            }
            mapspecRow.setBusinessRule(businessExpression);

            mapspeclist.add(mapspecRow);

        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    public static String getBrFromMap(Map<Integer, String> brMap, String expression) {
        try {
            for (Entry<Integer, String> entry : brMap.entrySet()) {
                Integer key = entry.getKey();
                String value = entry.getValue();
                String expr = value.split("#")[1];
                if (expression.equalsIgnoreCase(expr)) {

                    return value.split("#")[0];

                }

            }

        } catch (Exception e) {

        }
        return "";
    }

    public static void addsourceandtarget(Map<String, String> lineageMap) {
        String trget = "";
        String key = "";
        String value = "";
        try {
            lineageMap.toString();

            for (Entry<String, String> entry : lineageMap.entrySet()) {
                key = entry.getKey();
                value = entry.getValue();

                trget = value.split("_map")[1];
                MappingSpecificationRow mapspecRow = new MappingSpecificationRow();
                mapspecRow.setSourceSystemEnvironmentName(sourceEnvironmentNamegl);
                mapspecRow.setTargetSystemEnvironmentName(targetEnvironmentNamegl);
                mapspecRow.setSourceSystemName(sourceSystemNamegl);
                mapspecRow.setTargetSystemName(targetSystemNamegl);
                mapspecRow.setSourceTableName(key.split("#")[1]);
                mapspecRow.setSourceColumnName(key.split("#")[0]);
                mapspecRow.setTargetTableName(trget.split("##")[1]);

                mapspecRow.setTargetColumnName(trget.split("##")[0]);

                mapspeclist.add(mapspecRow);

            }

        } catch (Exception e) {
            // System.out.println("targettttt" + key + "------>" + value + "----->" + trget);
            e.printStackTrace();
        }
    }

    public static List<Mapping> createmapfromrowForOverView(ArrayList<MappingSpecificationRow> specrowlist, String mapfileName, String query, List<String> subselectquery) {
        List<Mapping> mappinglist = new LinkedList();
        Mapping m = new Mapping();
        List<String> subselectQuery = new LinkedList<>(subselectquery);
        String subSelectQuery = org.apache.commons.lang3.StringUtils.join(subselectQuery, "---------------------\n");
        m.setSourceExtractDescription(subSelectQuery);
        m.setMappingName(mapfileName);
        UpdateSpecsForSourceAndTarget_91EDF updateSpecsForSourceAndTarget_91 = new UpdateSpecsForSourceAndTarget_91EDF();
        ArrayList<MappingSpecificationRow> updatedoverviewrow = updateSpecsForSourceAndTarget_91.updateSpecList(specrowlist);
//        OverviewMapping overViewSpecObj = new OverviewMapping();
//        ArrayList<MappingSpecificationRow> updatedoverviewrow = overViewSpecObj.generateOverViewMappings(specrowlist);
        // ArrayList<MappingSpecificationRow> updatedspecs = getspecificationdetails(updatedoverviewrow);
        // System.out.println("size of overview " + updatedspecs.size());
        m.setMappingSpecifications(specrowlist);
        m.setSourceExtractQuery(query);

        mappinglist.add(m);
        return mappinglist;
    }

    private static Set<String> getBusinessRuleList(List<String> querylist, TGSqlParser sqlparser) {

        Set<String> uniquequery = new LinkedHashSet<>(querylist);
        Set<String> businessrules = new LinkedHashSet<>();
        List<String> uniquequerylist = new LinkedList(uniquequery);

        for (String query : uniquequerylist) {

            try {
                if (query.startsWith("(") && query.endsWith(")")) {
                    query = query.substring(1, query.length() - 1);
                }

                sqlparser.sqltext = query;
                int ret = sqlparser.parse();
                if (ret == 0) {
                    TResultColumnList rsltstatement1 = sqlparser.sqlstatements.get(0).getResultColumnList();
                    TCustomSqlStatement stmnt = sqlparser.sqlstatements.get(0);
                    TResultColumnList rsltstatement = stmnt.getResultColumnList();

                    for (int j = 0; rsltstatement != null && j < rsltstatement.size(); j++) {
                        TResultColumn column = rsltstatement.getResultColumn(j);
                        TExpression expr = column.getExpr();
                        EExpressionType type = expr.getExpressionType();
                        if (type == type.simple_object_name_t) {
                            continue;
                        }
                        businessrules.add(expr.toString());

                    }
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return businessrules;

    }

    private static Set<TExpression> getExpressionList(List<String> querylist, TGSqlParser sqlparser) {

        Set<String> uniquequery = new LinkedHashSet<>(querylist);
        Set<String> businessrules = new LinkedHashSet<>();
        List<String> uniquequerylist = new LinkedList(uniquequery);
        Set<TExpression> brlist = new LinkedHashSet<>();
        for (String query : uniquequerylist) {

            try {
                if (query.startsWith("(") && query.endsWith(")")) {
                    query = query.substring(1, query.length() - 1);
                }

                sqlparser.sqltext = query;
                int ret = sqlparser.parse();
                if (ret == 0) {
                    TCustomSqlStatement stmnt = sqlparser.sqlstatements.get(0);
                    TResultColumnList rsltstatement = stmnt.getResultColumnList();

                    for (int j = 0; rsltstatement != null && j < rsltstatement.size(); j++) {
                        TResultColumn column = rsltstatement.getResultColumn(j);
                        TExpression expr = column.getExpr();
                        EExpressionType type = expr.getExpressionType();
                        if (type == type.simple_object_name_t) {
                            continue;
                        }
                        brlist.add(expr);

                    }
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return brlist;

    }

    public static Map<Integer, String> getBusinessRuleFromMapspec(ArrayList<MappingSpecificationRow> mapspeclist, Set<String> businessrules) {
        Map<Integer, String> brMap = new LinkedHashMap<>();
        try {

            int i = 0;
            for (MappingSpecificationRow mappingSpecificationRow : mapspeclist) {

                String sourceColumnName = mappingSpecificationRow.getSourceColumnName();
                String targetColumnName = mappingSpecificationRow.getTargetColumnName();
                String targetTableName = mappingSpecificationRow.getTargetTableName();

                if (checkweatherthismethodisBr(businessrules, sourceColumnName) && !"".equals(targetColumnName)) {
                    brMap.put(i, targetTableName + "." + targetColumnName + "#" + sourceColumnName);
                }
                i++;
            }

        } catch (Exception e) {

        }
        return brMap;
    }

    public static boolean checkweatherthismethodisBr(Set<String> brlist, String columnName) {
        boolean flag = false;
        try {
            for (String br : brlist) {
                if (br.equalsIgnoreCase(columnName)) {
                    return true;
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
        return flag;

    }

    private static Map<String, List<String>> getBusinessRule(String businessRule) {
        Map<String, List<String>> tableColMap = new HashMap();
        try {
            int j = 1;
            Matcher m = Pattern.compile("\\(([^)]+)\\)").matcher(businessRule);
            if (!"".equals(businessRule) && businessRule != null) {
                while (m.find()) {

                    if (!m.group(j).isEmpty()) {
                        String tableCOlNameList = m.group(j++);
                        String[] lines = tableCOlNameList.split(",");
                        for (String line : lines) {
                            line = line.trim();
                            String strArr[] = line.split(" ");
                            for (String string : strArr) {
                                line = string;
                                if (line.contains(".")) {
                                    String str[] = line.split("\\.");
                                    if (str.length > 1) {
                                        String tableName = str[0].replace("(", "").replace("SUM", "").replace("-", "").replace("CAST", "").replace("ISNULL", "");
                                        String colName = str[1];
                                        List<String> colNameList = new ArrayList<String>();
                                        colNameList.add(colName.toUpperCase());
                                        if (tableColMap.containsKey(tableName)) {
                                            tableColMap.get(tableName).addAll(colNameList);
                                            //mappingSpec.get(trgtTblName).addAll(rowList);
                                        } else {
                                            tableColMap.put(tableName.toUpperCase(), colNameList);
                                        }
                                    }
                                } else {
                                    String colName = line;
                                    List<String> colNameList = new ArrayList<String>();
                                    colNameList.add(colName);

                                }
                            }
                        }
                    }

                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        return tableColMap;
    }

    private static Map<String, List<String>> getBusinessRulefromMap(String businessRule) {
        Map<String, List<String>> tableColMap = new HashMap();
        try {
            int j = 1;
            Matcher m = Pattern.compile("\\(([^)]+)\\)").matcher(businessRule);
            if (!"".equals(businessRule) && businessRule != null) {
                while (m.find()) {
                    if (!m.group(j).isEmpty()) {
                        String tableCOlNameList = m.group(j++);
                        String[] lines = tableCOlNameList.split(",");
                        for (String line : lines) {
                            line = line.trim();
                            String strArr[] = line.split(" ");
                            for (String string : strArr) {
                                line = string;
                                String tableName = getTableName(line);

                                if (checktargetTableName(tableName)) {
                                    tableName = getTableName(line, tableName);
                                }
                                if (!"".equals(tableName) && tableName != null) {
                                    List<String> colNameList = new ArrayList<String>();
                                    colNameList.add(line.toUpperCase());
                                    if (tableColMap.containsKey(tableName)) {
                                        tableColMap.get(tableName).addAll(colNameList);
                                        //mappingSpec.get(trgtTblName).addAll(rowList);
                                    } else {
                                        tableColMap.put(tableName.toUpperCase(), colNameList);
                                    }

                                }

                            }
                        }
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        return tableColMap;
    }

    public static String getTableName(String columnName) {
        try {
            for (Entry<String, List<String>> entry : tableColRel.entrySet()) {
                String key = entry.getKey();
                List<String> columnValue = entry.getValue();
                for (String columns : columnValue) {

                    if (columns.trim().toUpperCase().equalsIgnoreCase(columnName.trim().toUpperCase())) {

                        return key;

                    }

                }

            }

        } catch (Exception e) {

        }

        return "";
    }

    public static List<String> gettargetTableName(List<String> targetInfo) {
        List<String> targetTables = new LinkedList();

        try {

            for (String targetTable : targetInfo) {
                if (targetTable != null) {
                    if (targetTable.split("##").length > 1) {
                        targetTables.add(targetTable.split("##")[1]);
                    } else {
                        targetTables.add(targetTable.split("#")[1]);

                    }

                }
            }

        } catch (Exception e) {

        }
        return targetTables;
    }

    public static List<String> gettargetcolumnName(List<String> targetInfo) {
        List<String> targetColumn = new LinkedList();

        try {
            for (String targetTable : targetInfo) {
                targetColumn.add(targetTable.split("#")[0]);
            }

        } catch (Exception e) {

        }
        return targetColumn;
    }

    public static void removespec(String tableName, Set<String> srccolumns, String tgtTabName, String tgtcolumns) {

        for (String srccolumn : srccolumns) {
            removesrctab(srccolumn, tableName, tgtTabName, tgtcolumns);
        }

    }

    public static void removesrctab(String columnName, String sourceTabName) {
        Iterator<MappingSpecificationRow> iter = mapspeclist.iterator();

        while (iter.hasNext()) {
            MappingSpecificationRow mappingSpecificationRow = iter.next();
            String sourcetabName = mappingSpecificationRow.getSourceTableName();

            String sourceColumnName = mappingSpecificationRow.getSourceColumnName();

            if (sourcetabName.equalsIgnoreCase(sourceTabName) && sourceColumnName.equalsIgnoreCase(columnName)) {
                iter.remove();

            }

        }

    }

    public static void removesrctab(String columnName, String sourceTabName, String tgtTabName, String tgtcolumn) {
        Iterator<MappingSpecificationRow> iter = mapspeclist.iterator();
        int i = 0;
        while (iter.hasNext()) {

            MappingSpecificationRow mappingSpecificationRow = iter.next();
            String sourcetabName = mappingSpecificationRow.getSourceTableName();
            if (i == 83) {
                int k = 56;
            }
            String sourceColumnName = mappingSpecificationRow.getSourceColumnName();
            String targetTableName = mappingSpecificationRow.getTargetTableName();
            String targetColumnName = mappingSpecificationRow.getTargetColumnName();

            if (sourcetabName.equalsIgnoreCase(sourceTabName) && sourceColumnName.equalsIgnoreCase(columnName) && targetTableName.equalsIgnoreCase(tgtTabName) && targetColumnName.equalsIgnoreCase(tgtcolumn)) {
                iter.remove();
            }
            i++;
        }

    }

    public static void targetcolumnNamekeptAsempty(ArrayList<MappingSpecificationRow> mapspeclist) {
        Iterator<MappingSpecificationRow> iter = mapspeclist.iterator();
        while (iter.hasNext()) {
            MappingSpecificationRow row = iter.next();
            if (row.getTargetTableName().equals("") && row.getBusinessRule().equals("")) {
                row.setTargetColumnName("");
            }
        }
    }

    public static Map<String, String> modifytablealiasmap() {
        Map<String, String> modifymap = new LinkedHashMap<>();
        String secondkey = "";
        try {
            for (Entry<String, String> entry : tableAliasMap.entrySet()) {
                String key = entry.getKey();
                if (key == null) {
                    continue;
                }
//                if (key.contains(",")) {
//                    key = key.split(",")[0];
//                    secondkey=key.split(",")[1];
//                }
//                String value = entry.getValue();
//                modifymap.put(key, value);
//                if(secondkey!="")
//                {
//                    modifymap.put(secondkey, value);
//                }
                String value = entry.getValue();
                if (key.contains(",")) {

                    if (value.toUpperCase().startsWith("NULL.") || value.toUpperCase().startsWith("NULL")) {
                        value = value.replace("NULL.", "").replace("NULL", "");
                    }
                    String keys[] = key.split(",");
                    for (String key1 : keys) {
                        modifymap.put(key1.toUpperCase(), value.toUpperCase());
                    }
                } else {
                    modifymap.put(key.toUpperCase(), value.toUpperCase());
                }

            }

        } catch (Exception e) {

            e.printStackTrace();
        }

        return modifymap;
    }

    public static boolean checktargetTableName(String tableName) {
        try {
            for (MappingSpecificationRow mappingSpecificationRow : mapspeclist) {

                String targetTablename = mappingSpecificationRow.getTargetTableName();

                if (targetTablename.equalsIgnoreCase(tableName)) {
                    return true;
                }
            }

        } catch (Exception e) {

            e.printStackTrace();

        }

        return false;

    }

    public static String getTableName(String columnName, String tableName) {
        try {
            for (Entry<String, List<String>> entry : tableColRel.entrySet()) {
                String key = entry.getKey();
                if (key.equalsIgnoreCase(tableName)) {

                    continue;
                }
                List<String> columnValue = entry.getValue();
                for (String columns : columnValue) {

                    if (columns.trim().toUpperCase().equalsIgnoreCase(columnName.trim().toUpperCase())) {

                        return key;

                    }

                }

            }

        } catch (Exception e) {

        }

        return "";
    }

    public static String getTargetInfofromCOlumn(List<String> targetstr, String columnaliasName) {
        try {
            for (String lineagestr : targetstr) {
                String columnName = "";
                String sourcetabfromlineage = lineagestr.split("\\$\\$")[0];
                if (sourcetabfromlineage.split("#")[0].equalsIgnoreCase(columnaliasName)) {
                    return lineagestr.split("\\$\\$")[lineagestr.split("\\$\\$").length - 1];
                }

            }

        } catch (Exception e) {

            e.printStackTrace();
        }
        return null;
    }

    public static Map<String, List<String>> tableColumnInformationFromQuerybyxml(String query, String dbvender) {

        try {

            Map<String, String> tablecolMap = null;
            dbVendor = getEDbVendorType(dbvender);
            ColumnAnalyze cl = new ColumnAnalyze(query);
            // ColumnAnalyze.getcolumnanalyze(query, dbvender); 

            return tableColRel;
        } catch (Exception e) {

            e.printStackTrace();
        }

        return null;
    }

    public static Map<String, List<String>> tableColumnInformationFromQuery(String query, String dbvender) {

        try {

            Map<String, String> tablecolMap = null;
            dbVendor = getEDbVendorType(dbvender);
            ColumnAnalyze cl = new ColumnAnalyze(query);
            // ColumnAnalyze.getcolumnanalyze(query, dbvender); 

            tablecolMap = new LinkedHashMap(ColumnAnalyze.tablecolumnMap);
            Map<String, List<String>> tablecolumns = gettablecolumns(ColumnAnalyze.columns);
            // System.out.println();

            // makemapfromBusinessrule(query, dbvender, tablecolumns);
            return tablecolumns;
        } catch (Exception e) {

            e.printStackTrace();
        }

        return null;
    }

    public static void getExtremeSourceremoveNullTable(ArrayList<MappingSpecificationRow> mapspeclist) {
        Iterator<MappingSpecificationRow> iter = mapspeclist.iterator();

        while (iter.hasNext()) {
            MappingSpecificationRow row = iter.next();
            if (row.getSourceTableName().equalsIgnoreCase("NULL")) {
                iter.remove();
            }
            if (row.getSourceTableName().equalsIgnoreCase("") && row.getBusinessRule().equalsIgnoreCase("")) {
                iter.remove();
            }
        }
    }

    public static void appendHashforTable(ArrayList<MappingSpecificationRow> mapspeclist) {
        for (MappingSpecificationRow mappingSpecificationRow : mapspeclist) {
            if (mappingSpecificationRow.getSourceTableName().startsWith("#")) {
                String ashsrctabName = mappingSpecificationRow.getSourceTableName();
                String srctabName = ashsrctabName.split("#")[1];

                for (MappingSpecificationRow srcmappingSpecificationRow : mapspeclist) {
                    if (srctabName.equalsIgnoreCase(srcmappingSpecificationRow.getSourceTableName())) {
                        srcmappingSpecificationRow.setSourceTableName(ashsrctabName);
                    }
                    if (srctabName.equalsIgnoreCase(srcmappingSpecificationRow.getTargetTableName())) {
                        srcmappingSpecificationRow.setTargetTableName(ashsrctabName);
                    }
                }
            }
            if (mappingSpecificationRow.getTargetTableName().startsWith("#")) {
                String ashtgttabName = mappingSpecificationRow.getTargetTableName();
                String tgttabName = ashtgttabName.split("#")[1];
                for (MappingSpecificationRow tgtMappingspecificationRow : mapspeclist) {
                    if (tgttabName.equalsIgnoreCase(tgtMappingspecificationRow.getTargetTableName())) {
                        tgtMappingspecificationRow.setTargetTableName(ashtgttabName);
                    }
                    if (tgttabName.equalsIgnoreCase(tgtMappingspecificationRow.getSourceTableName())) {
                        tgtMappingspecificationRow.setSourceTableName(ashtgttabName);
                    }
                }
            }

        }
    }

    public static List<String> removequeryfromquerylist(Set<String> businessrulelist, List<String> querylist) {
        List<String> localquerylist = new LinkedList();
        try {
            for (String query : querylist) {
                if (!linearchanges(businessrulelist, query)) {
                    localquerylist.add(query);
                }
            }

        } catch (Exception e) {

        }

        return localquerylist;
    }

    public static boolean linearchanges(Set<String> businessrulest, String query) {

        try {
            for (String businessrule : businessrulest) {

                if (businessrule.contains(query)) {

                    return true;
                }

            }

        } catch (Exception e) {

        }

        return false;

    }

    public static void removeTheStringWithinBraces(ArrayList<MappingSpecificationRow> mapspeclist) {
        for (MappingSpecificationRow mappingSpecificationRow : mapspeclist) {
            String srctabName = mappingSpecificationRow.getSourceTableName();
            if (srctabName.contains("(") && srctabName.contains(")")) {
                String subsrcstring = srctabName.substring(srctabName.indexOf("("), srctabName.indexOf(")") + 1);
                srctabName = srctabName.replace(subsrcstring, "");
                mappingSpecificationRow.setSourceTableName("");
                mappingSpecificationRow.setTargetTableName("");
            }
            String targettabName = mappingSpecificationRow.getTargetTableName();
            if (targettabName.contains("(") && targettabName.contains(")")) {
                String subtgtstring = targettabName.substring(targettabName.indexOf("("), targettabName.indexOf(")") + 1);
                targettabName = targettabName.replace(subtgtstring, "");
                mappingSpecificationRow.setTargetTableName("");
            }
        }
    }

    public static void removeTheColumnsIfitisgoingMultipletimes(ArrayList<MappingSpecificationRow> mapspeclist) {
        Iterator<MappingSpecificationRow> iter = mapspeclist.iterator();
        while (iter.hasNext()) {
            MappingSpecificationRow mappingSpecificationRow = iter.next();
            String srctabName = mappingSpecificationRow.getSourceTableName();
            String srccolName = mappingSpecificationRow.getSourceColumnName();
            srccolName = srccolName.replace("[", "").replace("]", "").toUpperCase().trim();
            String tgtTabName = mappingSpecificationRow.getTargetTableName();
            String tgtColName = mappingSpecificationRow.getTargetColumnName();
            tgtColName = tgtColName.replace("[", "").replace("]", "").toUpperCase().trim();
            String brrule = mappingSpecificationRow.getBusinessRule().trim();
            if (!(srccolName.equalsIgnoreCase(tgtColName)) && StringUtils.isBlank(brrule)) {
                iter.remove();
            }
        }
    }

    public static List<String> getTragetTableName(List<String> sourcetables) {
        String sourceTableName = "";
        String targetTableName = "";
        List<String> targettab = new LinkedList();
        try {
            Map<String, String> modifydeclarealismap = modifytablealiasmap();
            for (String sourceTable : sourcetables) {
                sourceTableName = sourceTable;
                if (sourceTableName.equalsIgnoreCase("[BPI_DW].org.DimStaff")) {
                    int q = 4;
                }
                sourceTableName = sourceTableName.replace("[", "").replace("]", "");
                if (tableColRel.containsKey("RESULT_OF_" + sourceTableName)) {
                    sourceTableName = "RESULT_OF_" + sourceTableName;
                }
                if (tableColRel.containsKey("CTE-" + sourceTableName)) {
                    sourceTableName = "CTE-" + sourceTableName;
                }
                if (modifydeclarealismap.containsKey(sourceTable.toUpperCase())) {
                    sourceTableName = modifydeclarealismap.get(sourceTable.toUpperCase());
                }
                sourceTargetMap.toString();
                targetTableName = sourceTargetMap.get(sourceTableName);
                targettab.add(targetTableName);
            }
        } catch (Exception e) {

        }

        return targettab;
    }

    public static Map<String, List<String>> changeSourceMap(Map<String, List<String>> mapinfo, List<String> columnlineageMap) {
        Map<String, List<String>> modifyMap = new LinkedHashMap();
        Map<String, String> colKeytblMap = new LinkedHashMap();
        try {
            for (Entry<String, List<String>> entry : mapinfo.entrySet()) {
                String key = entry.getKey();
                List<String> value = entry.getValue();
                Set<String> uniquevalue = new LinkedHashSet(value);
                String columnName = "";
                if ("".equals(key)) {
                    for (String columns : uniquevalue) {
                        columns = columns.replace("[", "").replace("]", "");
                        if (forMapinfogettingsourcetableMapfdd.containsKey(columns.toUpperCase().trim())) {
                            String srctab = forMapinfogettingsourcetableMapfdd.get(columns.toUpperCase().trim());
                            if (!colKeytblMap.containsKey(columnName)) {
                                modifyMap.put(srctab.toUpperCase().trim().toUpperCase().trim(), value);
                                colKeytblMap.put(columns.toUpperCase().trim(), srctab.toUpperCase().trim());
                            }
                        } else {
                            for (String lineagestring : columnlineageMap) {
                                String[] sourcetabfromlineage = lineagestring.split("\\$\\$");
                                for (String tablecolumnrelationship : sourcetabfromlineage) {
                                    columnName = tablecolumnrelationship.split("#")[0];
                                    columnName = columnName.replace("[", "").replace("]", "");
                                    if (columnName.equalsIgnoreCase(columns)) {
                                        if (!colKeytblMap.containsKey(columnName)) {
                                            if (!tablecolumnrelationship.split("#")[1].toUpperCase().startsWith("RS-") && !tablecolumnrelationship.split("#")[1].toUpperCase().contains("RESULT_OF") && !tablecolumnrelationship.split("#")[1].toUpperCase().contains("INSERT-SELECT") && !tablecolumnrelationship.split("#")[1].toUpperCase().contains("UPDATE-SELECT")) {
                                                if (StringUtils.isNotBlank(tablecolumnrelationship.split("#")[1].toUpperCase())) {
                                                    modifyMap.put(tablecolumnrelationship.split("#")[1].toUpperCase(), value);
                                                    colKeytblMap.put(columnName, tablecolumnrelationship.split("#")[1].toUpperCase());
                                                } else {
                                                    //for Temp table String have two ##
                                                    if (tablecolumnrelationship.contains("##")) {
                                                        modifyMap.put("#" + tablecolumnrelationship.split("#")[2].toUpperCase(), value);
                                                        colKeytblMap.put(columnName, "#" + tablecolumnrelationship.split("#")[2].toUpperCase());
                                                    }

                                                }

                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                    //   return modifyMap;
                } else {
                    modifyMap.put(key, value);
                }

            }

        } catch (Exception e) {

            e.printStackTrace();
        }
        return modifyMap;
    }

    public static void addSchemaNameforOrphantables(List<MappingSpecificationRow> mapspeclist) {

        for (MappingSpecificationRow mappingSpecificationRow : mapspeclist) {
            StringBuilder srcbuilder = new StringBuilder();
            StringBuilder tgtbuilder = new StringBuilder();
            String srcschemaName = "";
            String tgtschemaName = "";
            String sourcetabName = mappingSpecificationRow.getSourceTableName().trim();
            String srctabNames[] = sourcetabName.split("\n");
            for (String srctabName : srctabNames) {
                if (!srctabName.trim().contains(".") && !srctabName.toUpperCase().contains("INSERT-SELECT") && !srctabName.toUpperCase().contains("UPDATE-SELECT") && !srctabName.toUpperCase().contains("RESULT_OF") && !srctabName.toUpperCase().startsWith("#") && !srctabName.trim().toUpperCase().startsWith("RS-") && !srctabName.toUpperCase().contains("UPDATE-SET")) {
                    Boolean srcboolen = true;
                    for (MappingSpecificationRow mappingSpecificationRow1 : mapspeclist) {
                        Boolean srcdot1 = false;
                        Boolean srcdot2 = false;
                        String dotsourcetabName = mappingSpecificationRow1.getSourceTableName().trim();
                        String dotsourcetabNames[] = dotsourcetabName.split("\n");
                        for (String dotsrctabName : dotsourcetabNames) {
                            //c200..temp this condition for at a time two dots coming we need to handle
                            if (dotsrctabName.contains("..")) {
                                dotsrctabName = dotsrctabName.replace("..", ".");
                                srcdot1 = true;
                            }
                            if (dotsrctabName.split("\\.").length >= 2) {
                                String srcTabName = dotsrctabName.split("\\.")[dotsrctabName.split("\\.").length - 1];
                                if (srctabName.equalsIgnoreCase(srcTabName) && srcboolen) {
                                    srcschemaName = dotsrctabName.split("\\.")[dotsrctabName.split("\\.").length - 2];
                                    if (srcdot1) {
                                        srcbuilder.append(srcschemaName + "." + srctabName).append("\n");
                                    } else {
                                        if (StringUtils.isNotBlank(srcschemaName)) {
                                            srcbuilder.append(srcschemaName + "." + srctabName).append("\n");
                                        }
                                    }
                                    srcboolen = false;
                                    break;
                                }
                            }

                        }
                        if (srcboolen) {
                            String dottargetabName = mappingSpecificationRow1.getTargetTableName().trim();
                            String dottargetabNames[] = dottargetabName.split("\n");
                            for (String dottgtabName : dottargetabNames) {
                                if (dottgtabName.contains("..")) {
                                    dottgtabName = dottgtabName.replace("..", ".");
                                    srcdot2 = true;
                                }
                                if (dottgtabName.split("\\.").length >= 2) {
                                    String tgtTabName = dottgtabName.split("\\.")[dottgtabName.split("\\.").length - 1];
                                    if (srctabName.equalsIgnoreCase(tgtTabName) && srcboolen) {
                                        srcschemaName = dottgtabName.split("\\.")[dottgtabName.split("\\.").length - 2];
                                        if (srcdot2) {
                                            srcbuilder.append(srcschemaName + ".." + srctabName).append("\n");
                                        } else {
                                            srcbuilder.append(srcschemaName + ".." + srctabName).append("\n");
                                        }
                                        srcboolen = false;

                                        break;
                                    }
                                }
                            }
                        }
                    }
                    if (srcboolen) {
                        srcbuilder.append(srctabName).append("\n");
                    }
                } else {
                    srcbuilder.append(srctabName).append("\n");
                }
            }
            if (StringUtils.isNotBlank(srcbuilder.toString().trim())) {
                mappingSpecificationRow.setSourceTableName(srcbuilder.toString().trim());
            }
            String targetTableName = mappingSpecificationRow.getTargetTableName().trim();
            String tgttabNames[] = targetTableName.split("\n");
            for (String tgttabName : tgttabNames) {
                if (!tgttabName.trim().contains(".") && !tgttabName.trim().toUpperCase().contains("INSERT-SELECT") && !tgttabName.trim().toUpperCase().contains("UPDATE-SELECT") && !tgttabName.trim().toUpperCase().contains("RESULT_OF") && !tgttabName.toUpperCase().startsWith("#") && !tgttabName.trim().toUpperCase().startsWith("RS-") && !tgttabName.trim().toUpperCase().contains("UPDATE-SET")) {
                    Boolean tgtboolen = true;
                    for (MappingSpecificationRow tgtmappingSpecificationRow1 : mapspeclist) {
                        boolean doubledot1 = false;
                        boolean doubledot2 = false;
                        String dotsrctabNam = tgtmappingSpecificationRow1.getSourceTableName().trim();
                        String dotsourcetabNames[] = dotsrctabNam.split("\n");
                        for (String dotsrctabName : dotsourcetabNames) {
                            if (dotsrctabName.contains("..")) {
                                dotsrctabName = dotsrctabName.replace("..", ".");
                                doubledot1 = true;
                            }
                            if (dotsrctabName.split("\\.").length >= 2) {
                                String srcTabName = dotsrctabName.split("\\.")[dotsrctabName.split("\\.").length - 1];
                                if (tgttabName.equalsIgnoreCase(srcTabName) && tgtboolen) {
                                    tgtschemaName = dotsrctabName.split("\\.")[dotsrctabName.split("\\.").length - 2];
                                    if (doubledot1) {
                                        tgtbuilder.append(tgtschemaName + ".." + tgttabName).append("\n");
                                    } else {
                                        tgtbuilder.append(tgtschemaName + "." + tgttabName).append("\n");
                                    }
                                    tgtboolen = false;
                                    break;
                                }
                            }
                        }
                        if (tgtboolen) {
                            String dotTgttabNam = tgtmappingSpecificationRow1.getTargetTableName().trim();
                            String dottargettabNames[] = dotTgttabNam.split("\n");
                            for (String dotTgttabName : dottargettabNames) {
                                if (dotTgttabName.contains("..")) {
                                    dotTgttabName = dotTgttabName.replace("..", ".");
                                    doubledot2 = true;
                                }
                                if (dotTgttabName.split("\\.").length >= 2) {
                                    String tgtTabName = dotTgttabName.split("\\.")[dotTgttabName.split("\\.").length - 1];
                                    if (tgttabName.equalsIgnoreCase(tgtTabName) && tgtboolen) {
                                        tgtschemaName = dotTgttabName.split("\\.")[dotTgttabName.split("\\.").length - 2];
                                        if (doubledot2) {
                                            tgtbuilder.append(tgtschemaName + ".." + tgttabName).append("\n");
                                        } else {
                                            tgtbuilder.append(tgtschemaName + "." + tgttabName).append("\n");
                                        }
                                        tgtboolen = false;
                                        break;
                                    }
                                }
                            }
                        }
                    }
                    if (tgtboolen) {
                        tgtbuilder.append(tgttabName).append("\n");
                    }
                } else {
                    tgtbuilder.append(tgttabName).append("\n");
                }

            }
            if (StringUtils.isNotBlank(tgtbuilder.toString().trim())) {
                mappingSpecificationRow.setTargetTableName(tgtbuilder.toString().trim());
            }

        }
    }

    public static Set<String> getAllStatementsForMSSQL(String query) {
        try {
            xmlVisitor.createquery.clear();
            xmlVisitor.subselectquery.clear();
            xmlVisitor.ifelse.clear();
            xmlVisitor.selectIntoQueries.clear();
            xmlVisitor.oraclefunctionlist.clear();
            xmlVisitor.mssqlQuerieslist.clear();
            toXml.getdbvenderforsqltext(query);
            //  return new LinkedHashSet(xmlVisitor.mssqlQuerieslist);
            return new LinkedHashSet(xmlVisitor.mssqlQuerieslist);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    public static void removebraces(ArrayList<MappingSpecificationRow> mappingspec) {

        try {
            Iterator<MappingSpecificationRow> iter = mappingspec.iterator();
            while (iter.hasNext()) {
                MappingSpecificationRow row = iter.next();

                if (row.getSourceTableName().contains("[") || row.getSourceTableName().contains("]") || row.getSourceTableName().contains("'") || row.getSourceTableName().contains(":")) {

                    row.setSourceTableName(row.getSourceTableName().replace("[", "").replace("]", "").replace("'", "").replace(":", "").trim());
                }
                if (row.getSourceColumnName().contains("[") || row.getSourceColumnName().contains("]") || row.getSourceColumnName().contains("'") || row.getSourceColumnName().contains(":")) {

                    row.setSourceColumnName(row.getSourceColumnName().replace("[", "").replace("]", "").replace("'", "").replace(":", "").trim());
                }
                if (row.getTargetTableName().contains("[") || row.getTargetTableName().contains("]") || row.getTargetTableName().contains("'") || row.getTargetTableName().contains(":")) {

                    row.setTargetTableName(row.getTargetTableName().replace("[", "").replace("]", "").replace("'", "").replace(":", "").trim());
                }
                if (row.getTargetColumnName().contains("[") || row.getTargetColumnName().contains("]") || row.getTargetColumnName().contains("'") || row.getTargetColumnName().contains(":")) {

                    row.setTargetColumnName(row.getTargetColumnName().replace("[", "").replace("]", "").replace("'", "").replace(":", "").trim());
                }
                if (row.getTargetColumnName().contains("\"")) {
                    // System.out.println("------------------");
                    row.setTargetColumnName(row.getTargetColumnName().replace("\"", ""));
                }
                if (row.getSourceColumnName().contains("\"")) {
                    // System.out.println("------------------");
                    row.setSourceColumnName(row.getSourceColumnName().replace("\"", ""));
                }
                if (row.getBusinessRule().contains("''")) {
                    row.setBusinessRule(row.getBusinessRule().replace("''", ""));
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    public static List<String> getcolumnlist(List<String> businessrulelist) {
        List<String> columnslist = new LinkedList();
        try {

            for (String columns : businessrulelist) {
                String columnName = getChangedcolumn(businessrulelist, columns);
                //  System.out.println("columnName---" + columnName);
                if (!"".equals(columnName)) {
                    columnslist.add(columnName);

                } else {
                    columnslist.add(columns);
                }
            }

            //columnslist.forEach((l->{System.out.println("listvalue---"+l);}));
        } catch (Exception e) {
        }
        return columnslist;
    }
    public static String getChangedcolumn(List<String> column, String columnName) {
        try {

            for (String columnNa : column) {
                if (columnNa.contains(".") && columnNa.contains(columnName) && !columnNa.equalsIgnoreCase(columnName)) {
                    String tableNa = columnNa.split("\\.")[0];
                    String col = columnNa.split("\\.")[1];
                    if (columnName.equalsIgnoreCase(col)) {
                        return tableNa + "." + col;
                    }

                }

            }

        } catch (Exception e) {
        }
        return "";
    }

   

    public static String modifysqlquery(String query) {
        String queryline = "";
        int spaceIndex = 0;
        String intoTableName = "";
        String addedQuery = "INSERT INTO";
        String replaceline="";
        StringBuilder returnQuery = new StringBuilder();
        try {
            int i = 0;
            String[] linearr = query.split("\n");
            for (String line : linearr) {
                 line=line.replaceAll("\\ + ", "\\ ");
                
                if(i<linearr.length-1)
                {
                linearr[i + 1] = linearr[i + 1].replaceAll("\\ + ", "\\ ");
                }
                Boolean addingline = true;
                Boolean incrementofi = false;
                if (!line.startsWith("--") && !line.startsWith("---") && !line.contains("SELECT * FROM") && line.contains("SELECT * ")) {
                    if (linearr[i + 1].toUpperCase().contains("INTO ")&& i<linearr.length-1) {
                        intoTableName = getintotable(linearr[i + 1]);
                        linearr[i + 1] = linearr[i + 1].replace("INTO "+intoTableName,"");
                        if(line.startsWith("SELECT * "))
                        {
                        line = addedQuery + " " + intoTableName +" "+ line;
                        }
                        else
                        {
                         String  modifyli=line.split("SELECT \\* ")[0];
                         line=modifyli+" "+addedQuery + " " + intoTableName +" "+"SELECT * "+line.split("SELECT \\* ")[1];
                        }
                        returnQuery.append(line.trim()).append("\n").append(linearr[i + 1].trim()).append("\n");
                        addingline = false;
                        incrementofi = true;
                    }
                     else if (line.contains("* INTO ")) {
                        intoTableName = getintotable(line);
                        if(line.startsWith("SELECT * INTO"))
                        {
                        line = line.replace("SELECT * INTO " + intoTableName, "SELECT * ");
                        replaceline = addedQuery + " " + intoTableName +" "+line;
                        }
                        else
                        {
                          line = line.replace("SELECT * INTO " + intoTableName, "SELECT * ");
                          String  modifyline=line.split("SELECT \\* ")[0];
                          replaceline = modifyline+" "+addedQuery + " " + intoTableName +" "+"SELECT * "+line.split("SELECT \\* ")[1];
                        }
                        returnQuery.append(replaceline.trim()).append("\n");
                        addingline = false;
                    } else {
                        if (addingline) {
                            returnQuery.append(line.trim()).append("\n");
                        }
                    }
                } else {
                    returnQuery.append(line.trim()).append("\n");
                }
                if (incrementofi) {
                    i = i + 2;
                } else {
                    i++;
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return returnQuery.toString();
    }

    public static String getintotable(String line) {
        int spaceIndex = 0;
        String intoTableName = "";

        try {
            String table = line.split("INTO ")[1].trim();
            spaceIndex = table.indexOf(" ");
            if (spaceIndex != -1) {
                intoTableName = table.substring(0, spaceIndex).trim();
            } else {
                intoTableName = table.substring(0, table.length());
            }
            if (intoTableName.contains("\n")) {
                intoTableName = intoTableName.split("\n")[0].trim();
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return intoTableName;
    }
}
