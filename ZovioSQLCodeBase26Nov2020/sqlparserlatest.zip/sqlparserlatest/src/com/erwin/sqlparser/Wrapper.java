/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.erwin.sqlparser;

import org.apache.commons.lang3.StringUtils;

/**
 *
 * @author InkolluReddy
 */
public class Wrapper {
    
    public static String selectintowrapper(String selectintostr)
     {
       StringBuilder querysb=new StringBuilder();
      try
      {
       String addedQuery = "INSERT INTO ";
       String intoTable = "";
       int spaceIndex = 0;
       selectintostr=selectintostr.toUpperCase();
       String originalquery=selectintostr;
       selectintostr=selectintostr.replace("SELECT * ","#ERWININDIA# ");
       String queries[]=selectintostr.split("SELECT ");
       for (int i=1;i<queries.length;i++) {
             queries[i]="SELECT "+queries[i];
       }
       for (String query : queries) {
           
        if(query.contains("INTO ") && !query.contains("INSERT INTO ")){
        query=query.replace("#ERWININDIA# ","SELECT * ");
        int intoStartIndex =query.indexOf("INTO ");
            int intoEndIndex = intoStartIndex +4;
            String intoSubString = query.substring(intoStartIndex, intoEndIndex).trim();
            String table = query.split(intoSubString+" ")[1].trim();
            spaceIndex = table.indexOf(" ");
            if (spaceIndex != -1) {
                intoTable = table.substring(0, spaceIndex).trim();
            } else {
                intoTable = table.substring(0, table.length());
            }
            if (intoTable.contains("\n")) {
                intoTable = intoTable.split("\n")[0].trim();
            }
            query=query.replace("INTO "+intoTable,"");
            query=addedQuery+intoTable+" "+"\n"+query;
            querysb.append(query).append("\n");
          }
         else
        {
          query=query.replace("#ERWININDIA# ","SELECT * ");
          querysb.append(query).append("\n");  
        }
     }
       if(StringUtils.isBlank(querysb.toString()))
       {
         querysb.append(originalquery);
       }
    }
     catch(Exception e)
     {
       e.printStackTrace();
     }
       return querysb.toString();
   }
    
}
