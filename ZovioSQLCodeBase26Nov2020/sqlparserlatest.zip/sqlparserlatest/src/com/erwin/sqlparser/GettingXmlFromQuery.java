package com.erwin.sqlparser;

import com.ads.api.beans.mm.Mapping;
import com.ads.api.beans.mm.MappingSpecificationRow;
import com.ads.edf.overview.updateforsource.v4.UpdateSpecsForSourceAndTarget_91EDF;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.sqlToJson.BindingPojo.Column;
import com.sqlToJson.BindingPojo.Dlineage;
import demos.*;
import demos.columnAnalyze.ColumnAnalyze;
import demos.dlineage.DataFlowAnalyzerv1;
import demos.visitors.XmlVisitorv1;
import demos.visitors.toXml;
import demos.visitors.xmlVisitor;
import gudusoft.gsqlparser.EDbVendor;
import gudusoft.gsqlparser.EExpressionType;
import gudusoft.gsqlparser.EJoinType;
import gudusoft.gsqlparser.TCustomSqlStatement;
import gudusoft.gsqlparser.TGSqlParser;
import gudusoft.gsqlparser.nodes.TExpression;
import gudusoft.gsqlparser.nodes.TJoin;
import gudusoft.gsqlparser.nodes.TJoinItem;
import gudusoft.gsqlparser.nodes.TObjectName;
import gudusoft.gsqlparser.nodes.TResultColumn;
import gudusoft.gsqlparser.nodes.TResultColumnList;
import gudusoft.gsqlparser.nodes.TTable;
import gudusoft.gsqlparser.nodes.TTableList;
import gudusoft.gsqlparser.nodes.TWhereClause;
import gudusoft.gsqlparser.stmt.TAlterTableStatement;
import gudusoft.gsqlparser.stmt.TCreateIndexSqlStatement;
import gudusoft.gsqlparser.stmt.TCreateTableSqlStatement;
import gudusoft.gsqlparser.stmt.TCreateViewSqlStatement;
import gudusoft.gsqlparser.stmt.TDeleteSqlStatement;
import gudusoft.gsqlparser.stmt.TInsertSqlStatement;
import gudusoft.gsqlparser.stmt.TSelectSqlStatement;
import gudusoft.gsqlparser.stmt.TTruncateStatement;
import gudusoft.gsqlparser.stmt.TUpdateSqlStatement;
import gudusoft.gsqlparser.stmt.db2.TDb2CreateProcedure;
import gudusoft.gsqlparser.stmt.mssql.TMssqlCreateProcedure;
import gudusoft.gsqlparser.stmt.teradata.TTeradataLock;
import java.io.File;
import java.io.FileReader;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.ListIterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Objects;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.TimeUnit;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.Unmarshaller;
import org.apache.commons.io.FileUtils;
import org.apache.commons.io.IOUtils;
import org.apache.commons.lang3.StringUtils;

/**
 * Sy
 *
 * @author shashikanta
 */
public class GettingXmlFromQuery {
    public static TGSqlParser sqlparser = null;
    public static EDbVendor dbVendor = null;
     public  String xmlFormation(String sqltext, String dbvender) {
         String selectxml="";
//        dbVendor = getEDbVendorType(dbvender);
//        sqlparser = new TGSqlParser(EDbVendor.dbvmssql);
//        sqlparser.sqltext = sqltext;
//        int ret = sqlparser.parse();
//        if (ret != 0) {
//            sqlparser.sqlfilename = sqltext;
//            ret = sqlparser.parse();
//        }
         try {
//            if (ret == 0) {
                selectxml = DataFlowAnalyzerv1.getanalyzeXmlfromString(sqltext, dbvender);
//            }
//            else
//            {
              if(StringUtils.isBlank(selectxml))
              {
              selectxml="This Sql was not Parsing due to Syntax error";
              }
//            }

        } catch (Exception e) {
            e.printStackTrace();
            selectxml="This Sql was not Parsing due to Syntax error";
          }
        return selectxml;
    }
      public static EDbVendor getEDbVendorType(String dbVender) {
        EDbVendor dbVendor = EDbVendor.dbvpostgresql;

        if (dbVender != null) {
            if (dbVender.equalsIgnoreCase("mssql")) {
                dbVendor = EDbVendor.dbvmssql;
            } else if (dbVender.equalsIgnoreCase("sybase")) {
                dbVendor = EDbVendor.dbvsybase;
            } else if (dbVender.equalsIgnoreCase("mysql")) {
                dbVendor = EDbVendor.dbvmysql;
            } else if (dbVender.equalsIgnoreCase("postgresql")) {
                dbVendor = EDbVendor.dbvpostgresql;
            } else if (dbVender.equalsIgnoreCase("oracle")) {
                dbVendor = EDbVendor.dbvoracle;
            } else if (dbVender.equalsIgnoreCase("db2")) {
                dbVendor = EDbVendor.dbvdb2;
            } else if (dbVender.equalsIgnoreCase("teradata")) {
                dbVendor = EDbVendor.dbvteradata;
            }
        }
        return dbVendor;
    }

  
}
