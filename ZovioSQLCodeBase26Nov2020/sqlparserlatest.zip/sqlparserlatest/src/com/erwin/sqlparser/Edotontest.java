/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.erwin.sqlparser;

import java.io.File;
import java.util.Map;
import org.apache.commons.io.FileUtils;

/**
 *
 * @author ads
 */
public class Edotontest {

    public static void main(String[] args) throws Exception {
//          String query = "SELECT KEY_NAME FROM ADS_KEY_VALUE where OBJECT_TYPE_ID IN (11,12);";
//       String filequeryquery = FileUtils.readFileToString(new File("C:\\Users\\ShashikantaDandasena\\Downloads\\usp_Policy_Master.sql"));
//       
//    
//      Map<String,Map<String,List<String>>> tablecol = ErwinSQLParserprotectivelife.makemapfromBusinessrule(filequeryquery, "mssql");       
//           System.out.println("tablecolumnquery"+tablecol);
        getJson();
    }
    public static void getJson() {
        try {
            //"E:\\JsonFile",
            long starttime = System.currentTimeMillis();
            File sqlfiles = new File("E:\\Clients\\zovio\\zoviosql\\XML");  
            if (sqlfiles.isDirectory()) {
                long timetaken = System.currentTimeMillis();
                File[] listfiles = sqlfiles.listFiles();
               //ErwinSqlparserNatOtherdb sqlparser = new ErwinSqlparserNatOtherdb();
               GettingXmlFromQuery sqlparser=new GettingXmlFromQuery();
                for (File listfile : listfiles) {
                    String sql = FileUtils.readFileToString(listfile,"UTF-8");
                 //   String jsonn1 = ErwinSqlParser_teradata.getJsonfromSqlstring(sql,"teradata",listfile.getName(),"E:\\Clients\\Hcl\\param\\par\\Parameter_File.txt");
                   String xml=sqlparser.xmlFormation(sql,"mssql");
                    
                  String jsonn1 = ErwinSqlParserNat.getJsonfromSqlstring(sql,"mssql",listfile.getName());
                    File jsonfile = new File(listfile.getParent() + File.separator + "json\\" + listfile.getName());
           //         FileUtils.writeStringToFile(jsonfile, jsonn1, "UTF-8");
                      
                  // String jsonn1 = sqlparser.sqlToDataflow(sql, "Redshift", "EDFenv", "Redshift", "EdfEnv", "mssql",listfile.getName());
           //        System.out.println("------------" + jsonn1);
          //          Map<String, String> joinqueries = sqlparser.getKeyvalueJson();
          //          joinqueries.forEach((k, v) -> {
                //        System.out.println("key---" + k + "value--" + v);
           //         });
            //        sqlparser.getClear();
                }
                long endtime = System.currentTimeMillis();

                long totaltime = endtime - starttime;
                System.out.println("-----------" + totaltime);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

    }
}
