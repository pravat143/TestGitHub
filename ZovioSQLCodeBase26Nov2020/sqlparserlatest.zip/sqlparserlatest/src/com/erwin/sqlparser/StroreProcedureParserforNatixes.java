package com.erwin.sqlparser;

import demos.getstatement.getstatement;
import demos.visitors.toXml;
import demos.visitors.xmlVisitor;

import java.io.*;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import org.apache.commons.io.FileUtils;
import org.apache.commons.io.FilenameUtils;
import org.apache.commons.lang3.StringUtils;

/**
 *
 * @author sashikant D
 */
public class StroreProcedureParserforNatixes {

    public static void main(String[] args) throws Exception {
        // List<String> storeproclist=   getstatement.getallstatement("C:\\Users\\sashikant D\\Desktop\\teststoreprocedure.sql","mssql");
        // StroreProcedureParser p1 = new StroreProcedureParser();
      String s = StroreProcedureParserforNatixes.parseStoreprocintomultiplefile("C:\\Users\\VinithChalla\\Desktop\\test", "mssql");
        
    }

    public static String parseStoreprocintomultiplefile(String storeProcFilePath, String dbVender) throws Exception {
        Set<String> storeproclist = null;
        File storeProcFile = null;
        File directory = null;
        FileWriter writer = null;
        FileOutputStream foutstream = null;
        String inputFileName = "";
        StringBuilder sb = new StringBuilder();
          File sqlfilepath = null;
         Pattern commentPattern = Pattern.compile("/\\*.*?\\*/", Pattern.DOTALL);  //remove /* pattern in sql 
        try {
            storeProcFile = new File(storeProcFilePath);
            if (storeProcFile.isDirectory()) {
                File outputDirectory = new File(storeProcFile.getAbsolutePath() + File.separator + "output");
                if (outputDirectory.exists()) {
                    FileUtils.deleteDirectory(outputDirectory);
                }
                File[] listofstoreprocFiles = storeProcFile.listFiles();
                for (File listofstoreprocFile : listofstoreprocFiles) {
                    String fileextension = FilenameUtils.getExtension(listofstoreprocFile.getName());

                    inputFileName = listofstoreprocFile.getName();
                     String query = FileUtils.readFileToString(listofstoreprocFile);
                     query = commentPattern.matcher(query).replaceAll("");
                     query=removeComments(query);
                   //  query = removecommentline(query);
                    //if(inputFileName.equals("[dbo].[ZVD_A501_KONP_PR]1598")){
                    System.out.println(inputFileName);
                    //}
                    //change by vinith
                    storeproclist = getstatement.getallstatement(query, dbVender);
                    
                    if (storeproclist.size() == 1) {
                        String sqlfile = FileUtils.readFileToString(listofstoreprocFile);
                        sqlfile = WrapperForAddEnd.QueryFilterationAddingEnd(sqlfile);
                        //Another wraper
                        // sqlfile = WrapperForIncludeSelectStartInUpdate.QueryFilterationAddingEnd(sqlfile);
                        //  String file = readSQLFile(sqlfile);
                        storeproclist = getstatement.getallstatementforstring(sqlfile, dbVender);
                    }
                    int i = 1;
                    Set<String> storeprocedures = new LinkedHashSet<>();
                    StringBuilder storeprocbuilder =new StringBuilder();;
                    for (String storeproc : storeproclist) {
                        storeproc=storeproc.toUpperCase();
                         sqlfilepath = new File(listofstoreprocFile.getAbsolutePath());
                        String parentpath = sqlfilepath.getAbsoluteFile().getParent();
                        
                         sqlfilepath = new File(parentpath);
                        Set<String> selectIntoQueries = ErwinSqlParserExtererFinancev1.getSelectIntoQueries(storeproc);
                        for (String selectIntoQuerie : selectIntoQueries) {
                            String notreplace=selectIntoQuerie;
                             String insertintoQuerie= "";
                           // if(selectIntoQuerie.contains("DISTINCT"))
                           // {
                           //    insertintoQuerie =  selectIntoQuerie;
                          //  }
                      //  else{
                            
                             insertintoQuerie=modifySelectQueries(selectIntoQuerie);
                      //      }
                            if(insertintoQuerie!="")
                            {
                            storeproc = storeproc.replace(notreplace,insertintoQuerie);
                            }
                            else
                            {
                               storeproc=storeproc.replace(selectIntoQuerie,notreplace);
                            }
                            
                        }
                        storeprocbuilder.append(storeproc).append("\n");
                        directory = new File(parentpath + "/output/");
                        if (!directory.exists()) {
                            directory.mkdir();
                        }
                        String path = null;
                        if (storeproclist.size() == 1) {
                            path=parentpath+ File.separator + "output" + File.separator+ inputFileName.replace("\r", "").replace(".sql", "") + ".sql";
                            
                        } else {
                           path= parentpath+ File.separator + "output" + File.separator+ inputFileName.replace("\r", "").replace(".sql", "") + ".sql";
                           // sqlfile = new File();

                        }
                        sqlfilepath = new File(path);
                        if(!sqlfilepath.exists()){
                            sqlfilepath.createNewFile();
                        }
                       // FileUtils.writeStringToFile(sqlfile, storeproc, "UTF-8");
                        }
                         String changestoreproc = StringUtils.join(storeprocedures,"\n");
                        FileUtils.writeStringToFile(sqlfilepath, storeprocbuilder.toString(),"UTF-8");
                }
                    
                  
          
                
            }

        } catch (Exception e) {
            StringWriter sw = new StringWriter();
            e.printStackTrace(new PrintWriter(sw));
            String exceptionAsString = sw.toString();
            sb.append(exceptionAsString);
            e.printStackTrace();
        } finally {
            if (writer != null) {
                writer.close();
            }

        }

        return sb.toString();
    }

    private static String getFileName(String storeProcedurFile) {
        String inputFileName = "";
        String[] procName = new String[0];
        try {
            //storeProcedurFile.toString();
            String file[] = storeProcedurFile.split("\n");
            String str = file[0];
            if (str.contains("procedure")) {
                procName = str.split("procedure");
            } else if (str.contains("PROCEDURE")) {
                procName = str.split("PROCEDURE");
            } else if (str.contains("TABLE")) {
                procName = str.split("TABLE");
            } else if (str.contains("VIEW")) {
                procName = str.split("VIEW");
            } else if (str.contains("view")) {
                procName = str.split("view");
            } else if (str.contains("Procedure")) {
                procName = str.split("Procedure");
            } else if (str.contains("PROC")) {
                procName = str.split("PROC");
            } else if (str.contains("proc")) {
                procName = str.split("proc");
            }
            if (procName.length > 1 && procName[1].contains("(")) {
                if (procName[1].contains(".") && procName[1].split("\\.").length > 1) {
                    procName[1] = procName[1].split("\\.")[1];
                    String procedureName = procName[1].replace("(", "").replace(")", "").replace("[", "").replace("]", "");
                    inputFileName = procedureName.replace("()", "").replace("`", "");
                } else {
                    String procedureName = procName[1].substring(0, procName[1].indexOf("("));
                    inputFileName = procedureName.replace("()", "").replace("`", "");
                }
            } else if (procName.length > 1 && procName[1].contains("[")) {
                if (procName[1].contains(".") && procName[1].split("\\.").length > 1) {
                    procName[1] = procName[1].split("\\.")[1];
                    String procedureName = procName[1].replace("[", "").replace("]", "").replace("(", "").replace(")", "");
                    inputFileName = procedureName.replace("()", "").replace("`", "");
                } else {
                    String procedureName = procName[1].substring(0, procName[1].indexOf("("));
                    inputFileName = procedureName.replace("()", "").replace("`", "");
                }
            }
            if (inputFileName.contains("/")) {
                inputFileName = inputFileName.replace("/", "");
            }
            if (inputFileName.contains(" ")) {
                //str = str.replaceAll("\\s","")
                inputFileName = inputFileName.replaceAll("\\s", "");
            }
            if (inputFileName.contains("*")) {
                //str = str.replaceAll("\\s","")
                inputFileName = inputFileName.replace("*", "");
            }

        } catch (Exception e) {

        }
        return inputFileName;
    }

    public static String createSubFolderInOutput(File query) {
        Set<String> folderFilesset = new LinkedHashSet();
        try {
            //   File queryPath=new File(query);
            String filename = query.getName();
            String extension = FilenameUtils.getExtension(filename);
            File queryFolder = new File(query.getParent() + File.separator + query.getName().replace(extension, ""));
            if (!queryFolder.exists()) {
                queryFolder.mkdir();
            }
            String sql = FileUtils.readFileToString(query);
            folderFilesset = getStarSelectQuery(sql);
            Iterator value = folderFilesset.iterator();
            while (value.hasNext()) {
                String file = value.next().toString();
                FileUtils.writeStringToFile(queryFolder, file);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    public static void createSubFoldersofOutput(File outputdirectory, String parentpath) {
        Set<String> folderFilesset = new LinkedHashSet();
        try {
            //   File queryPath=new File(query);
            if (outputdirectory.exists()) {
                File[] files = outputdirectory.listFiles();
                for (File query : files) {
                    String filename = query.getName();
                    String extension = FilenameUtils.getExtension(filename);
                    File queryFolder = new File(parentpath + "/query/");
                    if (!queryFolder.exists()) {
                        queryFolder.mkdir();
                    }
                    File querys = new File(queryFolder.getAbsolutePath() + File.separator + query.getName().replace(extension, ""));
                    if (!querys.exists()) {
                        querys.mkdir();
                    }
                    String sql = FileUtils.readFileToString(query);

                    folderFilesset = getStarSelectQuery(sql);

                    Iterator value = folderFilesset.iterator();
                    int count = 1;
                    while (value.hasNext()) {
                        String file = value.next().toString();
                        File file1 = new File(queryFolder + File.separator + query.getName().replace("." + extension, "") + File.separator + query.getName().replace("." + extension, "") + "-" + count + ".sql");
                        FileUtils.writeStringToFile(file1, file);
                        count++;

                    }
                    /*Writing Update Queries :: Added on 20/12/2019 by Narsimulu*/
                    Set<String> updateQueryies = getUpdateQuery(sql);
                    if (updateQueryies != null && !updateQueryies.isEmpty()) {
                        for (String updateQuery : updateQueryies) {
                            String formattedUpdateQuery = WrapperForIncludeSelectStartInUpdate.updateSelectStarForUpdateQuery(updateQuery);
                            File file1 = new File(queryFolder + File.separator + query.getName().replace("." + extension, "") + File.separator + query.getName().replace("." + extension, "") + "-" + (count++) + ".sql");
                            FileUtils.writeStringToFile(file1, formattedUpdateQuery);
                        }
                    }

                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    public static Set<String> getStarSelectQuery(String query) {
        Set<String> queryList = null;
        try {
            xmlVisitor.subselectquery.clear();
            toXml.getdbvenderforsqltext(query);
            queryList = new LinkedHashSet<>(xmlVisitor.subselectquery);

            return queryList;
        } catch (Exception e) {
            e.printStackTrace();
        }

        return null;
    }
    /*Added by Narsimulu*/
    public static Set<String> getUpdateQuery(String query) {
        Set<String> queryList = null;
        try {
            xmlVisitor.updateQueryList.clear();
            toXml.getdbvenderforsqltext(query);
            queryList = new LinkedHashSet<>(xmlVisitor.updateQueryList);

            return queryList;
        } catch (Exception e) {
            e.printStackTrace();
        }

        return null;
    }

    public static String modifySelectQueries(String sql) {
        String addedQuery = "INSERT INTO ";
        String intoTable = "";
        int spaceIndex = 0;
        String returnQuery = "";
        try {
            if (sql.startsWith("(") && sql.endsWith(")")) {
                sql = sql.substring(1, sql.length() - 1);
//                sql.equalsIgnoreCase(intoTable)
            }
            if(sql.contains("INTO"))
            {
            String table = sql.split("INTO")[1].trim();
            spaceIndex = table.indexOf(" ");
            if (spaceIndex != -1) {
                intoTable = table.substring(0, spaceIndex).trim();
            } else {
                intoTable = table.substring(0, table.length());
            }
            if (intoTable.contains("\n")) {
                intoTable = intoTable.split("\n")[0].trim();
            }
            if (sql.startsWith("SELECT")) {
                sql = sql.replaceAll("INTO", "").replaceAll(intoTable,"");
                returnQuery = addedQuery + " " + intoTable + "\n " + sql;
                
            } else {
                String modifiedQuery = sql.split("INTO")[0];
                int selectStartLastIndex = modifiedQuery.lastIndexOf("SELECT");
                if(selectStartLastIndex!=-1){
               String  insertQuery = modifiedQuery.substring(selectStartLastIndex, modifiedQuery.length()) + "INTO" + sql.split("INTO")[1];
                String replaceQuery = addedQuery + " " + intoTable + "\n" + insertQuery;
                returnQuery = sql.replace(insertQuery, replaceQuery);
                }
               else
                {
                    returnQuery = sql;
                }
                

            }
            }
            //get the select index and add INSERT INTO before to that
            //get the select 
        } catch (Exception e) {
            e.printStackTrace();
        }
          return returnQuery;
    }
    public static String intosql(String sql)
    {
        try
        {
          int count = 0,i=0;
        String data = "INTO #AppInList";
        File file = new File("C:\\Users\\VinithChalla\\Desktop\\New Text Document.txt");
        File temp = new File("C:\\Users\\VinithChalla\\Desktop\\temp.txt");
       if(temp.exists()){
          System.out.println("delete and create");
          temp.delete();
          temp.createNewFile();
        }
        else{
            System.out.println("create new file");
            temp.createNewFile();
        }
        temp.createNewFile();
        BufferedReader br = new BufferedReader(new FileReader(file));
        PrintWriter pw = new PrintWriter(temp);
        String st;
        while ((st = br.readLine()) != null) { 
            if(st.trim().equalsIgnoreCase(data)){
                count++;
            }
            else{
                pw.println(st);
                pw.flush();
            }  
        }
        br.close();
        pw.close();
        
        System.out.println(count);
        System.out.println(file.delete());
        System.out.println(file.createNewFile());
        PrintWriter pwr = new PrintWriter(file);
        BufferedReader tempReader = new BufferedReader(new FileReader(temp));
        while(i<count){
            pwr.println("INSERT "+data);
            pwr.flush();
            i++;
        }
        while ((st = tempReader.readLine()) != null) { 
            pwr.println(st);
            pwr.flush();
        }
        pwr.close();
        tempReader.close();
        temp.delete(); 
    }
    
    catch(Exception e)
    {
        e.printStackTrace();
    }
        return "";
    }
   public static String removecommentline(String query){
        StringBuilder sb = new StringBuilder();
    try{
    String [] quryline = query.split("\n");
        for (String queryline : quryline) {
            if(queryline.startsWith("--")){
            continue;
            }
            sb.append(queryline).append("\n");
        }
    
    }catch(Exception e){
    e.printStackTrace();
    
    }
    
    return sb.toString();
    }
public  static String removeComments(String data){
        Pattern pattern = Pattern.compile("/\\*(.|\\n)*?\\*/");
        Matcher matcher = pattern.matcher(data);
         return matcher.replaceAll("");
    }



}
    
