/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.erwin.sqlparser;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.Scanner;
import org.apache.commons.io.FileUtils;

/**
 *
 * @author InkolluReddy
 */
public class WrapperForAddEnd {

    public static String QueryFilterationAddingEnd(String storeproc) throws FileNotFoundException {
        Scanner scanner = null;
        int begincount = 0;
        int endcount = 0;
        StringBuffer sb = new StringBuffer();

        try {

            String query[] = storeproc.split("\n");
            for (String queryLine : query) {
                queryLine = queryLine.trim();
                if (queryLine.equalsIgnoreCase("BEGIN")) {
                    begincount++;
                } else if (queryLine.equalsIgnoreCase("END")) {
                    endcount++;
                }
                sb.append(queryLine + "\n");
            }

            int addcount = begincount - endcount;

            while (addcount != 0) {
                sb.append("\n" + "End");
                addcount--;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        return sb.toString();
    }

}
