/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.erwin.sqlparser;

/**
 *
 * @author InkolluReddy
 */
public class WrapperForIncludeSelectStartInUpdate {

    public static String updateSelectStarForUpdateQuery(String rawQuery) {
        StringBuffer strBuffer = new StringBuffer();
        try {

            String tableName = null;
            String selectStarAlias = null;
            String[] linesArr = rawQuery.split("\n");
            int i = 0;
            boolean isToAddSelectStar = false;
            for (String line : linesArr) {
                strBuffer.append(line).append("\n");
                if (isToAddSelectStar) {
                    strBuffer.append(selectStarAlias).append("\n");
                }
                isToAddSelectStar = false;
                selectStarAlias = "";
                if (i + 2 < linesArr.length) {
                    line = line.toUpperCase();
                    if (line.contains("UPDATE")) {
                        tableName = line.split("\\s+")[1];
                        
                        String[] fromTableDetArr = linesArr[i + 2].split("\\s+");
                        if ("FROM".equalsIgnoreCase(fromTableDetArr[0]) 
                                && tableName.equalsIgnoreCase(fromTableDetArr[1])) {
                            
                            isToAddSelectStar = true;
                            selectStarAlias = "SELECT ";
                            if(fromTableDetArr.length>=3){
                                //means alias exists
                                selectStarAlias +=fromTableDetArr[2]+".";
                            }
                            selectStarAlias +="*";
                            
                        }
                    }
                }
                i++;
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
        return strBuffer.toString();
    }

}
