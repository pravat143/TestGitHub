## Description
Check how fast this SQL parser library can process SQL in a single thread or in the multi-thread mode.

## Usage
`java benchmark`
