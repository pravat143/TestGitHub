/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package demos;

import java.util.LinkedList;
import java.util.List;

/**
 *
 * @author sashikant D
 */
public class Columnlist {
    
    public static List<String> ColumnList = new LinkedList();
    
    
    public  static void makecolumnlist(String token){
    
    ColumnList.add(token);
    
    }
    
}
