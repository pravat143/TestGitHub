
package demos.dlineage.dataflow.model;

public interface RelationElement<T> {

    public T getElement();
}
