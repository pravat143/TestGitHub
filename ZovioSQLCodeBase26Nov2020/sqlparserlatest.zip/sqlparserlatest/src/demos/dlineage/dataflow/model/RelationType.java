
package demos.dlineage.dataflow.model;

public enum RelationType {
    fdd, fddi, fdr, frd, join
}
