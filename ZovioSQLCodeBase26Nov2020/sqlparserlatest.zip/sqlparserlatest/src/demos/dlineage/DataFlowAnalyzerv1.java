/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package demos.dlineage;

import static demos.dlineage.SQLFlow.analyzeSQLFlow;
import gudusoft.gsqlparser.EDbVendor;

/**
 *
 * @author ShashikantaDandasena
 */
public class DataFlowAnalyzerv1 {

    public static String getanalyzeXmlfromString(String sqltext, String dbvender) {
        String xml = "";
        try {
            EDbVendor dbVendor = EDbVendor.dbvteradata;
            if (dbvender.equalsIgnoreCase("mssql")) {
                dbVendor = EDbVendor.dbvmssql;
                xml = SQLFlow.analyzeSQLFlowforsqltext(sqltext, EDbVendor.dbvmssql, false, false, "fdd");
            }
            if (dbvender.equalsIgnoreCase("sybase")) {
                dbVendor = EDbVendor.dbvsybase;
                xml = SQLFlow.analyzeSQLFlowforsqltext(sqltext, EDbVendor.dbvsybase, false, false, "fdd");
            }
            if (dbvender.equalsIgnoreCase("oracle")) {
                dbVendor = EDbVendor.dbvoracle;
                xml = SQLFlow.analyzeSQLFlowforsqltext(sqltext, EDbVendor.dbvoracle, false, false, "fdd");
            }
             if (dbvender.equalsIgnoreCase("teradata")) {
                dbVendor = EDbVendor.dbvteradata;
                xml = SQLFlow.analyzeSQLFlowforsqltext(sqltext, EDbVendor.dbvteradata, false, false, "fdd");
            }
            
             

        } catch (Exception e) {

        }
        return xml;
    }
}
