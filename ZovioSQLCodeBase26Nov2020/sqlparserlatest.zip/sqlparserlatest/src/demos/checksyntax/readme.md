## Description
Checking the SQL syntax without connecting to a database server using the General 
SQL Parser library.

## Usage
`java checksyntax [/f <path_to_sql_file>] [/d <path_to_directory_includes_sql_files>] [/t <database type>]`

Only SQL filename ended with .sql extentsion will be processed.

