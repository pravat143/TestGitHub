package org.boris.expr.function.excel;

import org.boris.expr.function.AbstractVarianceFunction;

public class VARA extends AbstractVarianceFunction
{
    public VARA() {
        super(true, false);
    }
}
