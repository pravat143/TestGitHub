package org.boris.expr.function.excel;

public class NOW extends TODAY
{
}
