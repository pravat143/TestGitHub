
package org.boris.expr.function.excel;

import org.boris.expr.Expr;
import org.boris.expr.ExprArray;
import org.boris.expr.ExprDouble;
import org.boris.expr.ExprError;
import org.boris.expr.ExprException;
import org.boris.expr.ExprString;
import org.boris.expr.IEvaluationContext;
import org.boris.expr.function.AbstractFunction;

public class LEN extends AbstractFunction
{

	public Expr evaluate( IEvaluationContext context, Expr[] args )
			throws ExprException
	{
		assertArgCount( args, 1 );
		Expr a = evalArg( context, args[0] );
		if ( a instanceof ExprArray )
			return ExprError.VALUE;
		String str = null;
		if ( a instanceof ExprString )
			str = ( (ExprString) a ).str;
		else
			str = a.toString( );
		str = new RTRIM( ).rtrim( str, " " );
		return new ExprDouble( str.length( ) );
	}
}
