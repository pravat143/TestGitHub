package org.boris.expr.function.excel;

import org.boris.expr.function.AbstractVarianceFunction;

public class VARP extends AbstractVarianceFunction
{
    public VARP() {
        super(false, true);
    }
}
