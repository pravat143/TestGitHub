package org.boris.expr.function.excel;

import org.boris.expr.function.AbstractVarianceFunction;

public class VARPA extends AbstractVarianceFunction
{
    public VARPA() {
        super(true, true);
    }
}
