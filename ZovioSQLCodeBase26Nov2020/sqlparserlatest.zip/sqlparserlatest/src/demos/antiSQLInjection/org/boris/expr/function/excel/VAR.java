package org.boris.expr.function.excel;

import org.boris.expr.function.AbstractVarianceFunction;

public class VAR extends AbstractVarianceFunction
{
    public VAR() {
        super(false, false);
    }
}
