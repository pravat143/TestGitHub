package demos.antiSQLInjection;

/**
 * value returned when GEval can't evaluate a value from an expression.
 */
public class UnknownValue {
    public String toString(){
        return "unknown value";
    }
}